# /storage/emulated/0/a0_sb2_book_editors_suite/testing_function/test_runner.py
import sys
import os

# Додаємо шлях до кореня проекту та тестової папки
project_root = '/storage/emulated/0/a0_sb2_book_editors_suite'
testing_function_path = '/storage/emulated/0/a0_sb2_book_editors_suite/testing_function'

# Додаємо обидва шляхи
sys.path.insert(0, project_root)
sys.path.insert(0, testing_function_path)

def run_all_tests():
    """Запускає всі тести"""
    print("🚀 ЗАПУСК ТЕСТІВ CONFIG MANAGER")
    print("=" * 60)
    
    try:
        # Імпортуємо та запускаємо тести
        from test_config_manager import test_config_manager
        result = test_config_manager()
        
        if result:
            print("\n🎊 ВСІ ТЕСТИ ПРОЙДЕНІ УСПІШНО!")
        else:
            print("\n⚠️ Деякі тести не пройшли")
            
    except Exception as e:
        print(f"❌ ПОМИЛКА ПРИ ЗАПУСКУ ТЕСТІВ: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    run_all_tests()

# test_runner.py
#import sys
#import os

# Додаємо шлях до модулів
#sys.path.append('/storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite')



#def run_all_tests():
#    """Запускає всі тести"""
#    print("🚀 ЗАПУСК ТЕСТІВ CONFIG MANAGER")
#    print("=" * 60)
#    
#    try:
#        # Імпортуємо та запускаємо тести
#        from test_config_manager import test_config_manager
#        result = test_config_manager()
#        
#        if result:
#            print("\n🎊 ВСІ ТЕСТИ ПРОЙДЕНІ УСПІШНО!")
#        else:
#            print("\n⚠️ Деякі тести не пройшли")
#            
#    except Exception as e:
#        print(f"❌ ПОМИЛКА ПРИ ЗАПУСКУ ТЕСТІВ: {e}")
#        import traceback
#        traceback.print_exc()

#if __name__ == "__main__":
#    run_all_tests()