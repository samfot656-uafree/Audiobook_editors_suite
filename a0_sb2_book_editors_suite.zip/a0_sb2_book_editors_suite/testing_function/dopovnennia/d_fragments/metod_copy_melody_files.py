# -*- coding: utf-8 -*-
# /storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite/core/config_manager.py

"""
Менеджер конфігурації з автоматичним створенням проекту книги.
"""

import json
import re
import os
import logging
import shutil
from pathlib import Path
from typing import Dict, Any, List, Optional

class ProjectManager:
    """Менеджер для створення структури проекту книги"""
    
    # Словник джерельних файлів для мелодій та пауз
    MELODY_SOURCE_FILES = {
        "PAUSE_4_mp3": "/storage/emulated/0/Documents/Inp_mp3/silence_0.4s.mp3",
        "PAUSE_7_mp3": "/storage/emulated/0/Documents/Inp_mp3/silence_0.7s.mp3",
        "PAUSE_1_mp3": "/storage/emulated/0/Documents/Inp_mp3/silence_1.0s.mp3",
        "PAUSE_2_mp3": "/storage/emulated/0/Documents/Inp_mp3/Pause_s2.mp3",
        "PAUSE_4_wav": "/storage/emulated/0/Documents/Inp_mp3/silence__0.4s.wav",
        "PAUSE_7_wav": "/storage/emulated/0/Documents/Inp_mp3/silence__0.7s.wav",
        "PAUSE_1_wav": "/storage/emulated/0/Documents/Inp_mp3/silence__1.0s.wav",
        "PAUSE_2_wav": "/storage/emulated/0/Documents/Inp_mp3/Vr_mel_multispeakers2/MELODY_END.wav",
        "MELODY_START_mp3": "/storage/emulated/0/Documents/Inp_mp3/MELODY_START.mp3",
        "MELODY_END_mp3": "/storage/emulated/0/Documents/Inp_mp3/MELODY_END.mp3",
        "MELODY_START_wav": "/storage/emulated/0/Documents/Inp_mp3/Початок_глави.wav",
        "MELODY_END_wav": "/storage/emulated/0/Documents/Inp_mp3/Завершення_глави.wav",
        "TEST_wav": "/storage/emulated/0/Documents/Inp_mp3/part_097.wav",
    }

    @staticmethod
    def copy_melody_files(project_path: str) -> None:
        """
        Копіює файли мелодій та пауз в папку проекту зі стандартними назвами.
        
        Args:
            project_path (str): Шлях до проекту
        """
        target_dir = f"{project_path}/inputs/input_melodu"
        
        # Створюємо папку призначення, якщо вона не існує
        os.makedirs(target_dir, exist_ok=True)
        
        # Словник для перейменування файлів у стандартні назви
        file_mapping = {
            # Паузи
            "PAUSE_4_mp3": "PAUSE_4.mp3",
            "PAUSE_7_mp3": "PAUSE_7.mp3", 
            "PAUSE_1_mp3": "PAUSE_1.mp3",
            "PAUSE_2_mp3": "PAUSE_2.mp3",
            "PAUSE_4_wav": "PAUSE_4.wav",
            "PAUSE_7_wav": "PAUSE_7.wav",
            "PAUSE_1_wav": "PAUSE_1.wav",
            "PAUSE_2_wav": "PAUSE_2.wav",
            
            # Мелодії
            "MELODY_START_mp3": "MELODY_START.mp3",
            "MELODY_END_mp3": "MELODY_END.mp3",
            "MELODY_START_wav": "MELODY_START.wav",
            "MELODY_END_wav": "MELODY_END.wav",
            
            # Тестовий файл
            "TEST_wav": "TEST.wav"
        }
        
        copied_files = []
        
        for source_key, target_name in file_mapping.items():
            source_path = ProjectManager.MELODY_SOURCE_FILES.get(source_key)
            
            if not source_path:
                print(f"Попередження: Не знайдено шлях для ключа {source_key}")
                continue
                
            if not os.path.exists(source_path):
                print(f"Попередження: Файл не існує {source_path}")
                continue
                
            target_path = os.path.join(target_dir, target_name)
            
            try:
                shutil.copy2(source_path, target_path)
                copied_files.append(target_name)
                print(f"Скопійовано: {source_path} -> {target_path}")
            except Exception as e:
                print(f"Помилка при копіюванні {source_path}: {e}")
        
        print(f"Успішно скопійовано {len(copied_files)} файлів мелодій до {target_dir}")

#-----create_project_structure-----
    @staticmethod
    def create_project_structure(project_name: str, input_text_path: str = None, 
                               base_path: str = "/storage/emulated/0/book_projects") -> str:
        """
        Створює структуру проекту книги.
        
        Args:
            project_name (str): Назва проекту
            input_text_path (str, optional): Шлях до вихідного текстового файлу
            base_path (str): Базова папка для проектів
            
        Returns:
            str: Шлях до конфігураційного файлу проекту
        """
        # Основні шляхи проекту
        project_path = f"{base_path}/{project_name}"
        config_file_path = f"{project_path}/json/{project_name}_config.json"
        
        # Створюємо структуру папок
        folders = [
            f"{project_path}",
            f"{project_path}/json",
            f"{project_path}/inputs",
            f"{project_path}/inputs/book_text_file",
            f"{project_path}/inputs/input_melodu",
            f"{project_path}/inputs/input_sounds_effects",
            f"{project_path}/outputs",
            f"{project_path}/outputs/output_mp3",
            f"{project_path}/outputs/output_multispeakers",
            f"{project_path}/temp_folder",
            f"{project_path}/temp_folder/logs"
        ]
        
        for folder in folders:
            os.makedirs(folder, exist_ok=True)
            print(f"Створено папку: {folder}")
        
        # Копіюємо/створюємо текстовий файл
        text_file_path = f"{project_path}/inputs/book_text_file/{project_name}.txt"
        if input_text_path and os.path.exists(input_text_path):
            shutil.copy2(input_text_path, text_file_path)
            print(f"Скопійовано текстовий файл: {text_file_path}")
        else:
            # Створюємо порожній текстовий файл
            with open(text_file_path, 'w', encoding='utf-8') as f:
                f.write("# Вхідний текст проекту\n\n")
            print(f"Створено порожній текстовий файл: {text_file_path}")
        
        # Викликаємо метод для копіювання файлів мелодій
        ProjectManager.copy_melody_files(project_path)
        
        # Створюємо порожні базові JSON файли
        json_files = {
            f"{project_path}/json/accents_files.json": {"акцент": "на́голос"},
            f"{project_path}/json/sound_effects_list.json": {"scenarios": []},
            f"{project_path}/json/sound_effects_files.json": {"sounds": {}}
        }
        
        for json_path, default_data in json_files.items():
            with open(json_path, 'w', encoding='utf-8') as f:
                json.dump(default_data, f, ensure_ascii=False, indent=2)
            print(f"Створено JSON файл: {json_path}")
        
        # Створюємо конфігураційний файл проекту
        config = ProjectManager._create_project_config(project_path, project_name)
        
        with open(config_file_path, 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        
        print(f"Створено конфігураційний файл: {config_file_path}")
        print(f"Структура проекту '{project_name}' успішно створена!")
        
        return config_file_path

    @staticmethod
    def _create_project_config(project_path: str, project_name: str) -> Dict[str, Any]:
        """
        Створює базову конфігурацію проекту.
        
        Args:
            project_path (str): Шлях до проекту
            project_name (str): Назва проекту
            
        Returns:
            Dict[str, Any]: Словник з конфігурацією
        """
        return {
            "project_name": project_name,
            "project_path": project_path,
            "text_file": f"{project_path}/inputs/book_text_file/{project_name}.txt",
            "melody_files": {
                "MELODY_START": f"{project_path}/inputs/input_melodu/MELODY_START.wav",
                "MELODY_END": f"{project_path}/inputs/input_melodu/MELODY_END.wav",
                "PAUSE_1": f"{project_path}/inputs/input_melodu/PAUSE_1.wav",
                "PAUSE_2": f"{project_path}/inputs/input_melodu/PAUSE_2.wav",
                "PAUSE_4": f"{project_path}/inputs/input_melodu/PAUSE_4.wav",
                "PAUSE_7": f"{project_path}/inputs/input_melodu/PAUSE_7.wav",
                "TEST": f"{project_path}/inputs/input_melodu/TEST.wav"
            },
            "created_at": str(datetime.now().isoformat()) if 'datetime' in globals() else ""
        }