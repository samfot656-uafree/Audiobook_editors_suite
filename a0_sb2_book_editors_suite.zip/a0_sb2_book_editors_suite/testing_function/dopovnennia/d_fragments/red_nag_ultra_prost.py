#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Редактор наголосів для розумних людей
"""

import sys
from smart_config import open_book, get_book

def main():
    # Відкриваємо книгу (назва з аргументу або стандартна)
    book_name = sys.argv[1] if len(sys.argv) > 1 else "Чекаючий_1_1_Шлях_до_заснування"
    book = open_book(book_name)
    
    # Отримуємо конфіг для редактора
    config = book.get_editor_config("accent_editor")
    
    print(f"📖 Книга: {book.config['book_name']}")
    print(f"📄 Текст: {config['text_file']}")
    print(f"📍 Закладка: {config['bookmark']}")
    
    # Перевіряємо чи це наш черга
    if config['current_editor'] != "accent_editor":
        print(f"⚠️ Зараз працює: {config['current_editor']}")
        print("🔧 Але ви можете продовжити роботу з наголосами")
    
    # Тут починається ваша робота з текстом...
    # Наприклад, завантажуємо текст
    with open(config['text_file'], 'r', encoding='utf-8') as f:
        text = f.read()
    
    print(f"📝 Текст завантажено: {len(text)} символів")
    
    # Симуляція роботи
    input("\n🔧 Працюйте з текстом... (Enter для симуляції збереження)")
    
    # Зберігаємо прогрес
    book.update_bookmark("accent_editor", cursor=1500, paragraph=42)
    
    # Питаємо чи завершили
    if input("\nЗавершити роботу з наголосами? (y/n): ").lower() == 'y':
        book.next_editor()
        print("🎉 Переходимо до редактора голосів!")

if __name__ == '__main__':
    main()