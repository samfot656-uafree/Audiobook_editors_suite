#-------------------------------------------
    def update_bookmark(self, editor_name: str, cursor_pos: int, scroll_y: float, paragraph_index: int):
        """Оновлює закладку для конкретного редактора з новими полями."""
        updates = {
            'BOOKMARK': {
                'cursor': int(cursor_pos),
                'scroll': float(scroll_y),
                'paragraph_index': int(paragraph_index)
            }
        }
        self.save_from_editor(editor_name, updates)
        self.logger.info(f"update_bookmark: \nОновлено закладку для {editor_name}: \nparagraph={paragraph_index}, cursor={cursor_pos}, scroll={scroll_y}\n")

#-------------------------------------------       
    def get_bookmark(self, editor_name: str) -> Dict[str, Any]:
        """Отримує закладку для конкретного редактора з новими полями."""
        editor_config = self.load_for_editor(editor_name)
        bookmark = editor_config.get('BOOKMARK', {'cursor': 0, 'scroll': 0.0, 'paragraph_index': 0})
        return {
            'scroll_y': bookmark.get('scroll', 0.0),
            'cursor_pos': bookmark.get('cursor', 0),
            'paragraph_index': bookmark.get('paragraph_index', 0)
        }

#-------------------------------------------
    def get_common_param(self, param_name: str, default=None):
        """Отримує значення спільного параметра (тільки читання)"""
        common_param = f"COMMON_{param_name.upper()}"
        return self.data.get(common_param, default)

# ... інші методи без змін ...

#-------------------------------------------
# Синглтон для глобального доступу
_global_config_manager = None

#-------------------------------------------
def get_config_manager(config_path: str = None) -> ModularConfigManager:
    """Повертає глобальний екземпляр менеджера конфігурації"""
    global _global_config_manager
    if _global_config_manager is None and config_path:
        _global_config_manager = ModularConfigManager(config_path)
    return _global_config_manager

#-------------------------------------------
def reset_config_manager():
    """Скидає глобальний екземпляр менеджера конфігурації (для тестування)"""
    global _global_config_manager
    _global_config_manager = None
    logger = logging.getLogger('config_manager')
    logger.info("reset_config_manager: \nСинглтон конфіг менеджера скинуто\n")

# Експорт функцій та класів
__all__ = ['ModularConfigManager', 'get_config_manager', 'reset_config_manager']