# до утілс/букмарк_утілс

from core.config_manager import ConfigManager

def create_bookmark(editor_name, cursor_pos, scroll_y):
    """
    Утиліта для створення закладки (зворотна сумісність)
    """
    config_manager = ConfigManager()
    return config_manager.create_bookmark(editor_name, cursor_pos, scroll_y)

def get_bookmark(editor_name):
    """
    Утиліта для отримання закладки
    """
    config_manager = ConfigManager()
    return config_manager.get_bookmark(editor_name)

def init_bookmarks():
    """
    Утиліта для ініціалізації всіх закладок
    """
    config_manager = ConfigManager()
    return config_manager.init_all_bookmarks()