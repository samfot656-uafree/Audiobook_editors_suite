# /storage/emulated/0/Documents/debug_config.py

from book_editors_suite.core.config_manager import get_config_manager

def debug_config():
    config_manager = get_config_manager("Чекаючий_1_1", "/storage/emulated/0/Documents/Inp_txt/Чекаючий_1_1.txt")
    
    print("=== ІНФО ПРО ПРОЕКТ ===")
    print(config_manager.get_project_info())
    
    print("\n=== КОНФІГ ДЛЯ VOICE_TAGS_EDITOR ===")
    config = config_manager.load_for_editor('voice_tags_editor')
    for key, value in config.items():
        print(f"{key}: {value}")
    
    print("\n=== ЗАКЛАДКА ===")
    bookmark = config_manager.get_bookmark('voice_tags_editor')
    print(bookmark)

if __name__ == "__main__":
    debug_config()