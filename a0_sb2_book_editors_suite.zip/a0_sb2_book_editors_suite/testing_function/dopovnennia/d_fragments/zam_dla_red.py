# В __init__ методі КОЖНОГО редактора:

# ЗАМІСТЬ СТАРОГО КОДУ:
SHARED_CONFIG_PATH = "/storage/emulated/0/Documents/pidgotovka_knigi/jsons/config_migration2.json"
self.config_manager = ModularConfigManager(SHARED_CONFIG_PATH)

# НАПИШІТЬ:
from book_editors_suite.core.config_manager import get_config_manager
self.config_manager = get_config_manager(book_project_name, input_text_file)

# ЗАМІСТЬ:
self.config = self.config_manager.load_for_editor('editor_name')

# НАПИШІТЬ (якщо потрібно отримати спільні параметри):
self.config = self.config_manager.load_for_editor('editor_name')

# ЗАМІСТЬ СТАРИХ ШЛЯХІВ:
self.INPUT_FILE = "/storage/emulated/0/.../файл.txt"

# НАПИШІТЬ:
self.INPUT_FILE = self.config.get('INPUT_TEXT_FILE', '')

# ЗАМІСТЬ СТАРОЇ ЗАКЛАДКИ:
bookmark = self.config.get('BOOKMARK', {})
self.saved_scroll_y = bookmark.get('scroll', 0.0)

# НАПИШІТЬ:
bookmark = self.config_manager.get_bookmark('editor_name')
self.saved_scroll_y = bookmark['scroll_y']