копи 'defaults'[пар] 

        # Копіюємо/створюємо текстовий файл
                    f"{project_path}/inputs/input_melodu",
        _file_path = f"{project_path}/inputs/input_melodu/"{'defaults'[пар]}.txt"
        
        if input_text_path and os.path.exists(input_text_path):
            shutil.copy2(input_text_path, text_file_path)
            print(f"Скопійовано текстовий файл: {text_file_path}")