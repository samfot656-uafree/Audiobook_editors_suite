# -*- coding: utf-8 -*-
# Конвертер TXT в MP3
# Зберігає як: /storage/emulated/0/Documents/convert_txt_to_mp3.py

import os
from pathlib import Path
from gtts import gTTS
import sys

def convert_txt_to_mp3(input_txt, output_mp3=None):
    """
    Конвертує текстовий файл в MP3
    
    Args:
        input_txt: шлях до вхідного текстового файлу
        output_mp3: шлях для збереження MP3 (необов'язково)
    """
    try:
        # Перевіряємо чи існує вхідний файл
        if not os.path.exists(input_txt):
            print(f"❌ Файл не знайдено: {input_txt}")
            return False
        
        # Читаємо текст
        with open(input_txt, 'r', encoding='utf-8') as f:
            text = f.read().strip()
        
        if not text:
            print("❌ Текстовий файл порожній")
            return False
        
        # Створюємо назву для MP3 якщо не вказано
        if output_mp3 is None:
            input_name = Path(input_txt).stem  # назва без розширення
            output_dir = Path(input_txt).parent
            output_mp3 = output_dir / f"{input_name}.mp3"
        
        # Створюємо папку якщо потрібно
        os.makedirs(Path(output_mp3).parent, exist_ok=True)
        
        print(f"📖 Читаємо: {input_txt}")
        print(f"💾 Зберігаємо: {output_mp3}")
        print(f"📊 Текст: {len(text)} символів")
        
        # Конвертуємо в MP3
        print("🔄 Конвертація...")
        tts = gTTS(text=text, lang='uk', slow=False)
        tts.save(str(output_mp3))
        
        print(f"✅ Успішно збережено: {output_mp3}")
        return True
        
    except Exception as e:
        print(f"❌ Помилка: {e}")
        return False

# === ПРИКЛАДИ ВИКОРИСТАННЯ ===

if __name__ == "__main__":
    # СПОСІБ 1: Жорстко задані шляхи
    input_file = "/storage/emulated/0/Documents/Inp_txt/Чекаючий_1_1.txt"
    output_file = "/storage/emulated/0/Documents/Out_mp3/Чекаючий_1_1.mp3"
    
    convert_txt_to_mp3(input_file, output_file)
    
    # СПОСІБ 2: Тільки вхідний файл (MP3 збережеться поруч)
    # convert_txt_to_mp3(input_file)
    
    # СПОСІБ 3: Для інших файлів - змініть шляхи
    # convert_txt_to_mp3(
    #     "/storage/emulated/0/Documents/інший_файл.txt",
    #     "/storage/emulated/0/Documents/інший_файл.mp3"
    # )