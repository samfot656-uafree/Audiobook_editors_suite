"""
/storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite/core/smart_config.py

Ультра-простий менеджер конфігурації для розумних людей, які знають що роблять.
Один конфіг на книгу, ніякої зайвої складності.
"""

import json
import os
import shutil
from pathlib import Path
from datetime import datetime

class SmartBookConfig:
    """Просто книга. Просто конфіг. Ніякої магії."""
    
    @staticmethod
    def create_book(book_name: str, text_file: str = None):
        """Створює нову книгу - папку з конфігом і текстом"""
        book_path = Path(f"/storage/emulated/0/projects/{book_name}")
        book_path.mkdir(parents=True, exist_ok=True)
        
        # Основний текстовий файл
        if text_file and Path(text_file).exists():
            shutil.copy2(text_file, book_path / "text.txt")
        else:
            (book_path / "text.txt").write_text("# Початок книги\n\n", encoding="utf-8")
        
        # Простий конфіг
        config = {
            "book_name": book_name,
            "created": datetime.now().isoformat(),
            "current_editor": "accent_editor",  # Завжди починаємо з наголосів
            
            # Шляхи
            "text_file": str(book_path / "text.txt"),
            "audio_folder": str(book_path / "audio"),
            "project_folder": str(book_path),
            
            # Закладки для кожного редактора
            "bookmarks": {
                "accent_editor": {"cursor": 0, "paragraph": 0},
                "voice_tags_editor": {"cursor": 0, "paragraph": 0},
                "sound_effects_editor": {"cursor": 0, "paragraph": 0},
                "multispeaker_tts": {"cursor": 0, "paragraph": 0}
            },
            
            # Налаштування (можна змінити вручну якщо треба)
            "settings": {
                "font_size": 56,
                "accent_char": "́",
                "tts_mode": "TFile",
                "fragment_limit": 1000
            }
        }
        
        config_path = book_path / "config.json"
        with open(config_path, 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        
        print(f"✅ Книга '{book_name}' створена: {config_path}")
        return str(config_path)
    
    def __init__(self, config_path: str):
        self.config_path = Path(config_path)
        self.config = self._load_config()
    
    def _load_config(self):
        """Завантажує конфіг. Якщо немає - вимикаємо програму."""
        if not self.config_path.exists():
            print(f"❌ Конфіг не знайдено: {self.config_path}")
            print("💡 Створіть книгу спочатку!")
            exit(1)
        
        with open(self.config_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def save(self):
        """Зберігає конфіг. Не питаємо дозволу."""
        with open(self.config_path, 'w', encoding='utf-8') as f:
            json.dump(self.config, f, ensure_ascii=False, indent=2)
    
    def get_editor_config(self, editor_name: str):
        """Вертає все що потрібно редактору"""
        return {
            "text_file": self.config["text_file"],
            "bookmark": self.config["bookmarks"][editor_name],
            "settings": self.config["settings"],
            "current_editor": self.config["current_editor"]
        }
    
    def update_bookmark(self, editor_name: str, cursor: int, paragraph: int):
        """Оновлює закладку. Без питань."""
        self.config["bookmarks"][editor_name] = {"cursor": cursor, "paragraph": paragraph}
        self.save()
    
    def next_editor(self):
        """Переходить до наступного редактора. Автоматично."""
        editors = ["accent_editor", "voice_tags_editor", "sound_effects_editor", "multispeaker_tts"]
        current = self.config["current_editor"]
        
        if current in editors:
            idx = editors.index(current)
            if idx < len(editors) - 1:
                self.config["current_editor"] = editors[idx + 1]
                self.save()
                print(f"➡️ Переходимо до: {editors[idx + 1]}")
                return editors[idx + 1]
        
        print("✅ Всі етапи завершено!")
        return "done"


# Глобальна змінна для поточної книги
_current_book = None

def open_book(book_name: str = None, config_path: str = None):
    """Відкриває книгу для роботи. Просто і зрозуміло."""
    global _current_book
    
    if config_path:
        _current_book = SmartBookConfig(config_path)
    elif book_name:
        config_path = f"/storage/emulated/0/projects/{book_name}/config.json"
        _current_book = SmartBookConfig(config_path)
    else:
        print("❌ Треба вказати або назву книги, або шлях до конфігу")
        return None
    
    print(f"📖 Відкрито книгу: {_current_book.config['book_name']}")
    return _current_book

def get_book():
    """Вертає поточну книгу. Якщо немає - вимикаємо програму."""
    if _current_book is None:
        print("❌ Не вибрано жодної книги!")
        print("💡 Використовуйте open_book() спочатку")
        exit(1)
    return _current_book