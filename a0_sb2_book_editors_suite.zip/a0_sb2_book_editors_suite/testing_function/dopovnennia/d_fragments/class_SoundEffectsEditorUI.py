# Приклад використання в інтерфейсі SoundEffectsEditor
class SoundEffectsEditorUI(BoxLayout):
    def __init__(self, editor, **kwargs):
        super().__init__(**kwargs)
        self.editor = editor
        
        # Поля для введення
        self.tag_input = TextInput(text=self.editor.get_next_available_tag())
        self.description_input = TextInput()
        self.file_input = TextInput()
        
        # Кнопки
        self.select_file_btn = Button(text="Обрати файл")
        self.select_file_btn.bind(on_press=self.select_file)
        
        self.add_effect_btn = Button(text="Додати звуковий ефект")
        self.add_effect_btn.bind(on_press=self.add_sound_effect)
    
    def select_file(self, instance):
        # Логіка вибору файлу
        pass
    
    def add_sound_effect(self, instance):
        tag = self.tag_input.text.strip()
        description = self.description_input.text.strip()
        file_path = self.file_input.text.strip()
        
        if tag and description:
            success = self.editor.add_sound_effect_to_text(tag, description, file_path)
            if success:
                # Очистити поля після успішного додавання
                self.tag_input.text = self.editor.get_next_available_tag()
                self.description_input.text = ""
                self.file_input.text = ""