# Мінімальні зміни для VoiceTagsEditor

class VoiceTagsEditor(App):
    def __init__(self, book_project_name: str, input_text_file: str = None, **kwargs):
        super().__init__(**kwargs)
        self.book_project_name = book_project_name
        self.input_text_file = input_text_file
        
        # === ЗАМІНА - використання нового конфіг менеджера ===
        self.config_manager = get_config_manager(book_project_name, input_text_file)
        self.config = self.config_manager.load_for_editor('voice_tags_editor')
        
        # Решта менеджерів
        self.tts_manager = TTSManager()
        self.text_processor = TextProcessor()
        self.file_manager = FileManager(self.config_manager, 'voice_tags_editor')
        self.theme_manager = ThemeManager()
        
        # === ЗАМІНА - параметри з конфігу ===
        self.INPUT_FILE = self.config.get('INPUT_TEXT_FILE', '')
        self.OUTPUT_FOLDER = self.config.get('OUTPUT_FOLDER', '')
        self.voice_dict = self.config.get('VOICE_DICT', {})
        self.pause_dict = self.config.get('PAUSE_DICT', {})
        
        # === ЗАМІНА - закладка з конфігу ===
        bookmark = self.config_manager.get_bookmark('voice_tags_editor')
        self.saved_scroll_y = bookmark['scroll_y']
        self.saved_cursor_pos = bookmark['cursor_pos']
        
        # Решта коду залишається незмінною
        self.current_speed = "normal"
        self.selected_word = None
        # ... інші властивості