# -*- coding: utf-8 -*-
# /storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite/editors/accent_editor/main.py

"""
Головний модуль редактора наголосів з підтримкою проектів книг.
"""
#виправити  tts, gTTS, закладку, копіювання словника наголосів, копіювання мелодій та пауз, save_full_mp3
import sys
import os
from pathlib import Path

# Додаємо шляхи для імпортів
sys.path.insert(0, '/storage/emulated/0/a0_sb2_book_editors_suite')
sys.path.insert(0, '/storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite')

# Kivy imports
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.popup import Popup
from kivy.uix.label import Label
from kivy.core.window import Window
from kivy.clock import Clock

# Project imports
from book_editors_suite.core.config_manager import ModularConfigManager, get_config_manager
from book_editors_suite.core.tts_manager import TTSManager
from book_editors_suite.core.file_manager import FileManager
from book_editors_suite.core.text_processor import TextProcessor
from book_editors_suite.core.logging_manager import LoggingManager
from book_editors_suite.ui.popups.edit_word_popup import EditWordPopup
from book_editors_suite.ui.popups.extra_buttons_popup import ExtraButtonsPopup
from book_editors_suite.ui.themes import ThemeManager
from book_editors_suite.utils.helpers import WORD_RE


class AccentEditorApp(App):
    """Основний клас редактора наголосів з підтримкою проектів книг."""

#----__init__---------------------------------------        
    def __init__(self, book_project_name: str, input_text_file: str = None, **kwargs):
        super().__init__(**kwargs)
        
        self.book_project_name = book_project_name
        self.input_text_file = input_text_file
        self.app_name = "accent_editor"
        
        # Ініціалізація менеджерів
        self.config_manager = None
        self.config = {}
        self.accents = {}
        self.text_for_correction = []
        self.fixed_text = []
        self.current_idx = -1
        self.selected_word = None
        self.tts_manager = None
        self.file_manager = None
        self.text_processor = None
        self.logger = None
        self.theme_manager = None
        
        self.current_scroll_y = 0.0
        self.current_cursor_pos = 0
        self.current_paragraph_index = 0

#----build---------------------------------------
    def build(self):
        """Побудова інтерфейсу додатку."""
        # Ініціалізація менеджерів з підтримкою проекту
        self._init_managers()
        
        Window.softinput_mode = "below_target"
        return self._build_interface()

#----_init_managers---------------------------------------
    def _init_managers(self):
        """Ініціалізація всіх менеджерів з підтримкою проекту."""
        try:
            # Створюємо менеджер конфігурації для проекту
            self.config_manager = get_config_manager(
                book_project_name=self.book_project_name,
                input_text_file=self.input_text_file
            )
            
            # Завантажуємо конфіг для редактора
            self.config = self.config_manager.load_for_editor('accent_editor')
            
            # Отримуємо інформацію про проект
            project_info = self.config_manager.get_project_info()
            
            # Ініціалізація менеджерів
            self.logger = LoggingManager(
                log_dir=project_info['base_path'] + f"/{self.book_project_name}/temp_folder/logs",
                app_name="accent_editor"
            )
            self.file_manager = FileManager(self.config_manager, 'accent_editor', self.logger)
            self.text_processor = TextProcessor(self.logger)
            self.tts_manager = TTSManager()
            self.theme_manager = ThemeManager()
            
            # Завантаження даних
            self.accents = self.file_manager.load_accents()
            
            self.logger.info(f"\n_init_managers: 105 \nВсі менеджери ініціалізовані для проекту '{self.book_project_name}'")
            self.logger.info(f"_init_managers: 106 \nТекстовий файл: \n{self.config.get('INPUT_TEXT_FILE', 'Невідомо')}\n")
            
        except Exception as e:
            error_msg = f"\n_init_managers: 109 \nПомилка ініціалізації менеджерів: {e}"
            if self.logger:
                self.logger.error(error_msg)
            else:
                print(error_msg)
            self.show_popup("Помилка _init_managers: 114", f"Не вдалося ініціалізувати проект:\n{e}")

#----_build_interface--------------------------------
    def _build_interface(self):
        """Побудова інтерфейсу."""
        self.logger.info("\n_build_interface: 119 \nСтворення елементів інтерфейсу...\n")
        
        bbtn_font_size = self.config_manager.get_common_param('BBTN_FONT_SIZE', 38)
        text_widget_font_size = self.config_manager.get_common_param('TEXT_WIDGET_FONT_SIZE', 56)
        bbtn_height = self.config_manager.get_common_param('BBTN_HEIGHT', 120)
            
        root = BoxLayout(orientation='vertical', spacing=8, padding=22)

        # Верхній ряд кнопок
        top_row = BoxLayout(orientation='horizontal', size_hint_y=None, height=bbtn_height, spacing=8)
        self.btn_listen = Button(text="Слухати", font_size=bbtn_font_size)
        self.btn_pause = Button(text="Пауза", font_size=bbtn_font_size)
        self.btn_edit = Button(text="Правити", font_size=bbtn_font_size, disabled=True)
        self.btn_next = Button(text="Наступний", font_size=bbtn_font_size)
        self.btn_extra = Button(text="  . . .  ", font_size=bbtn_font_size)
        
        for btn in (self.btn_listen, self.btn_pause, self.btn_edit, self.btn_next, self.btn_extra):
            top_row.add_widget(btn)
            

        # Текстове поле
        self.text_input = TextInput(
            font_size=text_widget_font_size,
            multiline=True
        )
        self.text_input.bind(on_touch_down=self.on_text_touch)

        # Додавання віджетів та прив'язка подій
        root.add_widget(top_row)
        root.add_widget(self.text_input)
        self._bind_events()

        # Автоматичні дії
        Clock.schedule_once(lambda *_: self.open_and_prepare_text(), 0.1)
        Clock.schedule_once(lambda *_: self.apply_theme(), 0)
        Clock.schedule_once(lambda *_: self.restore_bookmark(), 0.2)

        self.logger.info("\n_build_interface: 156  \nІнтерфейс успішно побудовано\n")
        return root

#----_bind_events-------------------------------------
    def _bind_events(self):
        """Прив'язка подій до кнопок."""
        self.btn_listen.bind(on_press=lambda *_: self.listen_current_paragraph())
        self.btn_pause.bind(on_press=lambda *_: self.stop_tts())
        self.btn_edit.bind(on_press=self.open_edit_popup)
        self.btn_next.bind(on_press=lambda *_: self.go_next_paragraph())
        self.btn_extra.bind(on_press=lambda *_: ExtraButtonsPopup(main_app=self, editor_name=self.app_name).open())

    # === Основні методи ===

#----move_bookmark------------------------------
    def move_bookmark(self):
        """Перекладає закладку в поточну позицію без запису у конфіг проекту."""
#        if self.text_input:
#            try:
#                self.current_cursor_pos = self.text_input.cursor_index()
#                self.current_scroll_y = self.text_input.scroll_y
#                self.current_paragraph_index = self.current_idx
#             #   self.btn_extra.text = f"   . . .м177   \n{self.current_paragraph_index+1}/{len(paragraphs)}"
#                
#                self.logger.debug(f"\nsave_bookmark: 178 \nЗакладку перекладено: абзац {self.current_paragraph_index}, прокрутка {self.current_scroll_y}, позиція {self.current_cursor_pos}\n")
#            except Exception as e:
#                self.logger.error(f"\nsave_bookmark: 180 \nПомилка збереження закладки: {e}\n")

#----save_bookmark------------------------------
    def save_bookmark(self):
        """Зберігає поточну позицію у конфіг проекту."""
#        if self.text_input and hasattr(self, 'config_manager'):
#            try:
#                self.current_cursor_pos = self.text_input.cursor_index()
#                self.current_scroll_y = self.text_input.scroll_y
#                self.current_paragraph_index = self.current_idx
#                
#                self.config_manager.update_bookmark(
#                    'accent_editor', 
#                    self.current_cursor_pos, 
#                    self.current_scroll_y,
#                    self.current_paragraph_index
#                )
#                self.logger.debug(f"\nsave_bookmark: 184 \nЗакладку збережено: абзац {self.current_paragraph_index}, прокрутка {self.current_scroll_y}, позиція {self.current_cursor_pos}\n")
#            except Exception as e:
#                self.logger.error(f"\nsave_bookmark: 186 \nПомилка збереження закладки: {e}\n")

#----restore_bookmark--------------------------
    def restore_bookmark(self):
        """Відновлює позицію з конфігу проекту."""
#        try:
#            if hasattr(self, 'config_manager'):
#                bookmark = self.config_manager.get_bookmark('accent_editor')
#                if self.text_input and bookmark:
#                    # Встановлюємо позицію абзацу курсора і прокрутки з конфігу
#                    self.current_scroll_y = bookmark['scroll_y']
#                    self.current_cursor_pos = (bookmark['cursor_pos'], 0)
#                    self.current_paragraph_index = bookmark.get('paragraph_index', 0)
#                    
#                    # Встановлюємо позицію абзацу курсора і прокрутки для self.text_input
#                    self.text_input.scroll_y = self.current_scroll_y
#                    self.text_input.cursor = self.current_cursor_pos
#                    self.current_idx = self.current_paragraph_index
#                    self.move_bookmark()
#                    
#                                      
#                    self.logger.debug(f"\nrestore_bookmark: 206 \nЗакладку відновлено: абзац {self.current_paragraph_index}, прокрутка {self.current_scroll_y}, позиція {self.current_cursor_pos}\n")
#        except Exception as e:
#            self.logger.error(f"\nrestore_bookmark: 208 \nПомилка відновлення закладки: {e}")

#----open_and_prepare_text-------------------
    def open_and_prepare_text(self):
        """Завантажує текст з проекту та автоматично додає наголоси."""
#        try:
#            # Завантаження тексту через FileManager
#            raw_text = self.file_manager.load_input_text()
#            if raw_text is None:
#                self.logger.warning("\nopen_and_prepare_text: 217 \nТекст не знайдено.")
#                return

#            # Обробка тексту через TextProcessor
#            accented_text = self.text_processor.add_accents_to_text(raw_text, self.accents)
#            paragraphs = accented_text.split("\n")
#            
#            self.text_for_correction = paragraphs
#            self.fixed_text = []

#            # Відновлюємо закладку ДО встановлення поточного абзацу
#            self.restore_bookmark()
#            
#            # Встановлюємо початковий абзац на основі закладки
#            if 0 <= self.current_paragraph_index < len(paragraphs):
#                self.current_idx = self.current_paragraph_index
#                self.text_input.text = paragraphs[self.current_paragraph_index]
#             #   self.move_bookmark()
#                self.btn_extra.text = f"   . . .о251   \n{self.current_paragraph_index+1}/{len(paragraphs)}"
#                self.logger.info(f"\nopen_and_prepare_text: 235 \nВідкрито абзац {self.current_paragraph_index+1}/{len(paragraphs)} з закладки\n")
#            else:
#                # Якщо закладка некоректна, знаходимо перший непорожній абзац
#                i = 0
#                while i < len(paragraphs) and not paragraphs[i].strip():
#                    self.fixed_text.append("")
#                    i += 1
#                    
#                if i < len(paragraphs):
#                    self.current_paragraph_index = i
#                    self.text_input.text = paragraphs[i]
#                    self.btn_extra.text = f"   . . .o263   \n{self.current_paragraph_index+1}/{len(paragraphs)}"
#                    self.logger.info(f"\nopen_and_prepare_text: 247 \nВідкрито перший абзац {i+1}/{len(paragraphs)}\n")
#                else:
#                    self.current_paragraph_index = len(paragraphs)
#                    self.text_input.text = ""
#                    self.logger.warning("\nopen_and_prepare_text: 251 \nТекст порожній")
#                    self.show_popup("Готово", "Текст порожній.")

#            self.clear_selection_state()
#            
#        except Exception as e:
#            self.logger.error(f"\nopen_and_prepare_text: 257 \nПомилка підготовки тексту: \n{e}\n")
#            self.show_popup("Помилка", f"Не вдалося підготувати текст:\n{e}")

#sp
#    # === Робота з текстом ===
#        self.fixed_text = []
#        self.text_for_correction = paragraphs
#        self.fixed_text = []
#        self.current_idx = -1

#        # Знаходимо перший непорожній абзац
#        i = 0
#        while i < len(paragraphs) and not paragraphs[i].strip():
#            self.fixed_text.append("")
#            i += 1
#            
#        if i < len(paragraphs):
#            self.current_idx = i
#            self.text_input.text = paragraphs[i]
#            print(f" Відкрито абзац {i+1}/{len(paragraphs)}")
#        else:
#            self.current_idx = len(paragraphs)
#            self.text_input.text = ""
#            self.show_popup("Готово", "Текст порожній.")

#        self.clear_selection_state()

#sk


#----go_next_paragraph--------------------------
    def go_next_paragraph(self):
        """Переходить до наступного абзацу та зберігає позицію."""
#        self.logger.info("\ngo_next_paragraph: 263 \nПерехід до наступного абзацу\n")
#        self.stop_tts()
#        
#        if self.current_paragraph_index < 0 or self.current_paragraph_index >= len(self.text_for_correction):
#            self.logger.warning("\ngo_next_paragraph: 267 \nНеможливо перейти: некоректний поточний індекс")
#            return

#        # Зберігаємо поточний абзац
#        self.fixed_text.append(self.text_input.text)
#        self.current_paragraph_index += 1
#        
#        # Пропускаємо порожні абзаци
#        skipped_count = 0
#        while (self.current_paragraph_index < len(self.text_for_correction) and 
#               not self.text_for_correction[self.current_paragraph_index].strip()):
#            self.fixed_text.append("")
#            self.current_paragraph_index += 1
#            skipped_count += 1

#        if self.current_idx < len(self.text_for_correction):
#            self.text_input.text = self.text_for_correction[self.current_idx]
#            
#            # Оновлюємо поточну позицію
#            self.current_paragraph_index = self.current_idx
#            self.current_cursor_pos = 0
#            self.current_scroll_y = 0.0
#            
#            self.logger.info(f"\ngo_next_paragraph: 290 \nПерехід до абзацу {self.current_idx+1}/{len(self.text_for_correction)}\n")
#          #  self.move_bookmark()
#            self.btn_extra.text = (f". . .g309\n{self.current_idx+1}/{len(self.text_for_correction)}")
#        else:
#            self.text_input.text = ""
#            self.logger.info("\ngo_next_paragraph: 294 \nДосягнуто кінця тексту\n")
#            self.show_popup("Кінець", "Досягнуто кінця тексту.")

#        self.clear_selection_state()
#        
#        # Автоматично зберігаємо закладку при переході      
#        #self.save_bookmark()
#        
#        #перекладаємо закладку при переході        
#        self.move_bookmark()


#----listen_current_paragraph----------------
    def listen_current_paragraph(self):
        """Відтворює поточний абзац через TTS."""
        text = self.text_input.text.strip()
        if text:
            self.logger.info(f"\nlisten_current_paragraph: 307 \nВідтворення TTS: {len(text)} символів\n")
            self.tts_manager.safe_tts_speak(text)
        else:
            self.logger.warning("\nlisten_current_paragraph: 310 \nСпроба відтворення порожнього тексту\n")

#----stop_tts-----------------------------
    def stop_tts(self):
        """Зупиняє TTS відтворення."""
        if self.tts_manager:
            self.tts_manager.stop_tts()
            self.logger.info("\nstop_tts: 317 \nTTS зупинено\n")

    # === Робота з виділенням слів ===

#----on_text_touch-----------------------------    
    def on_text_touch(self, instance, touch):
        """Обробка торкання текстового поля для виділення слова."""
        if not instance.collide_point(*touch.pos):
            return False
        Clock.schedule_once(lambda *_: self.detect_word_at_cursor(), 0.01)
        return False

#----detect_word_at_cursor----------------
    def detect_word_at_cursor(self):
        """Визначає слово під курсором."""
        try:
            cursor_idx = self.text_input.cursor_index()
        except Exception as e:
            self.logger.debug(f"\ndetect_word_at_cursor: 335 \nПомилка отримання позиції курсору: \n{e}\n")
            self.clear_selection_state()
            return

        text = self.text_input.text
        if not text:
            self.clear_selection_state()
            return

        # Знаходимо межі слова
        start = cursor_idx
        while start > 0 and self.is_word_char(text[start - 1]):
            start -= 1

        end = cursor_idx
        while end < len(text) and self.is_word_char(text[end]):
            end += 1

        word = text[start:end]
        if WORD_RE.fullmatch(word):
            self.selected_word = word
            self.btn_edit.disabled = False
            self.logger.debug(f"\ndetect_word_at_cursor: 357 \nВиділено слово: '{word}'\n")
        else:
            self.clear_selection_state()

#----is_word_char-----------------------------
    def is_word_char(self, char: str) -> bool:
        """Перевіряє, чи символ є частиною слова."""
        return char.isalpha() or char == '\u0301' or char == "'"

#----save_accents-----------------------------
    def save_accents(self):
        """Зберігає словник наголосів у проект."""
        try:
            success = self.file_manager.save_accents(self.accents)
            if success:
                self.logger.info("\nsave_accents: 372 \nСловник наголосів збережено в проект\n")
            else:
                self.logger.error("\nsave_accents: 374 \nПомилка збереження словника наголосів\n")
        except Exception as e:
            self.logger.error(f"\nsave_accents: 376 \nПомилка збереження словника: \n{e}\n")

#----clear_selection_state----------------------
    def clear_selection_state(self):
        """Очищає стан виділення."""
        if self.selected_word:
            self.logger.debug("\nclear_selection_state: 382 \nОчищено виділення слова\n")
        self.selected_word = None
        self.btn_edit.disabled = True

#----open_edit_popup-----------------------------
    def open_edit_popup(self, *_):
        """Відкриває попап для редагування слова."""
        if self.selected_word:
            self.logger.info(f"\nopen_edit_popup: 390 \nВідкриття попапу редагування слова: '{self.selected_word}\n'")
            self.stop_tts()
            EditWordPopup(self, self.selected_word, self.app_name).open()

#----replace_word_in_current_paragraph-
    def replace_word_in_current_paragraph(self, old_word: str, new_word: str):
        """Замінює слово в поточному абзаці."""
        if self.current_idx < 0:
            return
            
        current_text = self.text_input.text
        replaced_text = current_text.replace(old_word, new_word, 1)
        self.text_input.text = replaced_text
        
        self.logger.info(f"\nreplace_word_in_current_paragraph: 404 \nЗамінено слово: '{old_word}' -> '{new_word}'\n")

    # === Збереження даних ===

#----save_full_text---------
    def save_full_text(self):
        """Зберігає весь текст у TXT файл проекту та оновлює закладку."""
        self.stop_tts()
        
        content = self.build_full_text()
        success = self.file_manager.save_output_text(content)
        
        # Автоматичне збереження закладки при збереженні тексту
        self.save_bookmark()
        
        if success:
            self.logger.info("\nsave_full_text: 420 \nТекст успішно збережено в проект\n")
        else:
            self.logger.error("\nsave_full_text: 422 \nПомилка збереження тексту\n")

#----build_full_text---------
    def build_full_text(self) -> str:
        """Побудова повного тексту з виправленими абзацами."""
        parts = list(self.fixed_text)
        if 0 <= self.current_idx < len(self.text_for_correction):
            parts.append(self.text_input.text)
            parts.extend(self.text_for_correction[self.current_idx + 1:])
        
        full_text = "\n".join(parts)
        self.logger.debug(f"\nbuild_full_text: 433 \nЗібрано повний текст: {len(parts)} абзаців, {len(full_text)} символів\n")
        return full_text
#-------------------------------------------------
#    def save_full_mp3(self):
#    	"""Зберігає весь текст у MP3 через gTTS"""
#    	self.stop_tts()
#    	content = self.build_full_text().strip()
#    	if not content:
#    		return
#    	# Переконаємося, що папка існує
#    os.makedirs(OUT_MP3_FOLDER, exist_ok=True)
   
#    out_f_path = f"{project_path}/outputs/output_mp3/{project_name}.mp3"
#         
#    try:
#        tts = gTTS(text=content, lang="uk")
#        tts.save(out_f_path)
#        Popup(title="MP3 збережено", content=Label(text=f"MP3 збережено:\n{OUT_MP3_FOLDER}\n {out_f_name}"),
#              size_hint=(0.9,0.35)).open()
#    except Exception as e:
#        Popup(title="Помилка gTTS", content=Label(text=str(e)), size_hint=(0.9,0.45)).open()

# Прив'язка функцій до класу
#AccentEditorApp.save_full_text = save_full_text
#AccentEditorApp.save_full_mp3 = save_full_mp3

    # === Тема інтерфейсу ===

#----get_theme_colors---------        
    def get_theme_colors(self):
        """Повертає кольори теми (для сумісності з попапами)."""
        return self.theme_manager.get_colors()

#----apply_theme---------    
    def apply_theme(self):
        """Застосовує поточну тему до інтерфейсу."""
        try:
            # Створюємо словник з віджетами для теми
            widgets_dict = {
                'buttons': [self.btn_listen, self.btn_pause, self.btn_edit, self.btn_next, self.btn_extra],
                'text_inputs': [self.text_input],
                'window': Window
            }
            
            # Використовуємо ThemeManager для застосування теми
            self.theme_manager.apply_theme_to_widgets(widgets_dict)
            self.logger.debug("\napply_theme: 482 \nТему застосовано\n")
        except Exception as e:
            self.logger.error(f"\napply_theme: 484 \nПомилка застосування теми: \n{e}\n")

#----toggle_theme---------
    def toggle_theme(self):
        """Перемикає тему день/ніч."""
        self.stop_tts()
        self.theme_manager.toggle_theme()
        self.apply_theme()
        self.logger.info(f"\ntoggle_theme: 492 \nПереключено тему: {self.theme_manager.current_theme}\n")

    # === Утиліти ===

#----show_popup---------
    def show_popup(self, title: str, message: str):
        """Показує спливаюче повідомлення."""
        popup = Popup(
            title=title,
            content=Label(text=message),
            size_hint=(0.8, 0.4)
        )
        popup.open()
        self.logger.debug(f"\nshow_popup: 505 \nПоказано попап: {title}: {message}\n")

#----on_stop---------
    def on_stop(self):
        """Викликається при закритті додатку - зберігає закладку, зупиняє ттс."""
        self.save_bookmark()
        self.stop_tts()
        self.logger.info("\non_stop: 512 \nРедактор наголосів закрито\n")
        self.logger.info('/=\+' * 10)

#===запуск=======
if __name__ == "__main__":
    # Новий спосіб запуску з підтримкою проектів
    input_text_file = "/storage/emulated/0/Documents/Inp_txt/Чекаючий_1_1.txt"
    book_project_name = "Чекаючий_1_1"
    
    app = AccentEditorApp(
        book_project_name=book_project_name,
        input_text_file=input_text_file
    )
    app.run()