#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Створення нової книги - одна команда
"""

import sys
from smart_config import SmartBookConfig

def create_new_book():
    """Створює нову книгу. Швидко і просто."""
    if len(sys.argv) > 1:
        book_name = sys.argv[1]
        text_file = sys.argv[2] if len(sys.argv) > 2 else None
    else:
        book_name = input("Назва книги: ")
        text_file = input("Шлях до тексту (Enter - пустий): ") or None
    
    SmartBookConfig.create_book(book_name, text_file)
    print(f"🎉 Книга '{book_name}' готова до роботи!")
    print("💡 Запустіть редактор наголосів: python accent_editor.py")

if __name__ == '__main__':
    create_new_book()