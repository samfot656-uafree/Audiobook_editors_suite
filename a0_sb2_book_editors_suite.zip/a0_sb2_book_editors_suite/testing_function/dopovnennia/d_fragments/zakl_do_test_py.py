#zakl do test.py

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from utils.bookmark_utils import create_bookmark, get_bookmark, init_bookmarks

def test_bookmarks():
    """Тестування функціоналу закладок"""
    print("=== ТЕСТ ЗАКЛАДОК ===")
    
    # Ініціалізація
    print("1. Ініціалізація закладок...")
    init_bookmarks()
    
    # Створення закладок
    print("2. Створення закладок...")
    create_bookmark('voice_tags_editor', 953, 1952.137108385563)
    create_bookmark('accent_editor', 150, 500.5)
    
    # Отримання закладок
    print("3. Отримання закладок...")
    vte_bookmark = get_bookmark('voice_tags_editor')
    ae_bookmark = get_bookmark('accent_editor')
    
    print(f"Voice Tags Editor: {vte_bookmark}")
    print(f"Accent Editor: {ae_bookmark}")
    
    print("=== ТЕСТ ЗАВЕРШЕНО ===")

if __name__ == "__main__":
    test_bookmarks()