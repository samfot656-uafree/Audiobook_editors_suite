# -*- coding: utf-8 -*-
"""
Попап для редагування слова.
"""
from kivy.uix.popup import Popup
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button


class EditWordPopup(Popup):
    """Попап для редагування виділеного слова."""
    
    def __init__(self, parent_app, word, **kwargs):
        super().__init__(**kwargs)
        self.parent_app = parent_app
        self.word = word
        
        self.title = f"Редагування слова: {word}"
        self.size_hint = (0.9, 0.6)
        
        self._build_interface()
        self.apply_theme()
        
    def _build_interface(self):
        """Побудова інтерфейсу попапу."""
        layout = BoxLayout(orientation='vertical', spacing=10, padding=10)
        
        # Початкове слово
        layout.add_widget(Label(text=f"Початкове слово: {self.word}"))
        
        # Поле для редагування
        self.input_original = TextInput(
            text=self.word,
            multiline=False,
            font_size=24
        )
        layout.add_widget(self.input_original)
        
        # Замінене слово
        layout.add_widget(Label(text="Замінити на:"))
        
        self.input_replacement = TextInput(
            text=self.word,
            multiline=False,
            font_size=24
        )
        layout.add_widget(self.input_replacement)
        
        # Кнопки
        buttons_layout = BoxLayout(orientation='horizontal', spacing=10, size_hint_y=0.3)
        
        self.btn_save = Button(text="Зберегти")
        self.btn_cancel = Button(text="Скасувати")
        
        self.btn_save.bind(on_press=self.save_changes)
        self.btn_cancel.bind(on_press=self.dismiss)
        
        buttons_layout.add_widget(self.btn_save)
        buttons_layout.add_widget(self.btn_cancel)
        
        layout.add_widget(buttons_layout)
        self.content = layout

def on_listen_word(self, *_):
    """Відтворює слово через TTS."""
    text = self.input_replacement.text.strip()
    if text:
        self.parent_app.tts_manager.safe_tts_speak(text)    
        
                
    def apply_theme(self):
        """Застосовує тему до попапу."""
        try:
            colors = self.parent_app.get_theme_colors()
            
            # Застосування кольорів до елементів попапу
            self.background = ''
            self.background_color = colors["input_bg"]
            
            # Застосування до кнопок
            buttons = [self.btn_save, self.btn_cancel]
            for btn in buttons:
                btn.background_normal = ""
                btn.background_color = colors["button_bg"]
                btn.color = colors["button_fg"]
                
            # Застосування до текстових полів
            text_inputs = [self.input_original, self.input_replacement]
            for text_input in text_inputs:
                text_input.background_color = colors["input_bg"]
                text_input.foreground_color = colors["input_fg"]
                text_input.cursor_color = colors.get("cursor_color", (0.03, 0.85, 0.53, 1))
                
        except Exception as e:
            print(f"Помилка застосування теми в попапі: {e}")
    
    def save_changes(self, instance):
        """Зберігає зміни та замінює слово в тексті."""
        old_word = self.word
        new_word = self.input_replacement.text.strip()
        
        if new_word and old_word != new_word:
            self.parent_app.replace_word_in_current_paragraph(old_word, new_word)
            self.parent_app.logger.info(f"💾 Збережено заміну: '{old_word}' -> '{new_word}'")
        
        self.dismiss()