from kivy.clock import Clock
import threading
try:
    from jnius import autoclass
    TextToSpeech = autoclass('android.speech.tts.TextToSpeech')
    Locale = autoclass('java.util.Locale')
    HashMap = autoclass('java.util.HashMap')
    PythonActivity = autoclass('org.kivy.android.PythonActivity')
except Exception:
    TextToSpeech = Locale = HashMap = PythonActivity = None

class TTSManager:
    def __init__(self):
        self.tts = None
        self.init_tts()
    
    def init_tts(self):
        if not TextToSpeech or not PythonActivity:
            return
        try:
            self.tts = TextToSpeech(PythonActivity.mActivity, None)
            try:
                self.tts.setLanguage(Locale.forLanguageTag("uk-UA"))
            except Exception:
                try:
                    self.tts.setLanguage(Locale("uk"))
                except Exception:
                    pass
        except Exception as e:
            print(f"Помилка ініціалізації TTS: {e}")
    
    def speak(self, text: str):
        if text and self.tts:
            try:
                params = HashMap()
                params.put("volume", "1.0")
                self.tts.speak(text, TextToSpeech.QUEUE_FLUSH, params)
            except Exception as e:
                print(f"Помилка озвучення: {e}")
    
    def stop(self):
        if self.tts:
            try:
                self.tts.stop()
            except Exception as e:
                print(f"Помилка зупинки TTS: {e}")
    
    def speak_async(self, text: str):
        threading.Thread(target=self.speak, args=(text,), daemon=True).start()