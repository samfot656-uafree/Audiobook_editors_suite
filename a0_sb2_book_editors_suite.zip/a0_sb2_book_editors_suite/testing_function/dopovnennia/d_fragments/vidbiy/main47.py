# -*- coding: utf-8 -*-
"""
Головний модуль редактора наголосів.
"""
import sys
import os
from pathlib import Path

# Додаємо шляхи для імпортів
sys.path.insert(0, '/storage/emulated/0/a0_sb2_book_editors_suite')
sys.path.insert(0, '/storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite')

# Kivy imports
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.popup import Popup
from kivy.uix.label import Label
from kivy.core.window import Window
from kivy.clock import Clock

# Project imports
from book_editors_suite.core.config_manager import get_config_manager
from book_editors_suite.core.tts_manager import TTSManager
from book_editors_suite.core.file_manager import FileManager
from book_editors_suite.core.text_processor import TextProcessor
from book_editors_suite.core.logging_manager import LoggingManager
from book_editors_suite.ui.popups.edit_word_popup import EditWordPopup
from book_editors_suite.ui.popups.extra_buttons_popup import ExtraButtonsPopup
from book_editors_suite.utils.helpers import WORD_RE


class ThemeManager:
    """Тимчасовий менеджер тем до створення окремого модуля."""
    
    def __init__(self):
        self.current_theme = "day"
        self.themes = {
            "day": {
                "button_bg": (0.5, 0.5, 0.5, 1),
                "button_fg": (1, 1, 1, 1),
                "input_bg": (1, 1, 1, 1),
                "input_fg": (0, 0, 0, 1),
                "cursor_color": (0.03, 0.85, 0.53, 1)
            },
            "night": {
                "button_bg": (0, 0, 0, 1),
                "button_fg": (0.6, 0.85, 1, 1),
                "input_bg": (0, 0, 0, 1),
                "input_fg": (0, 0, 1, 1),
                "cursor_color": (0.03, 0.85, 0.53, 1)
            }
        }
    
    def get_colors(self) -> dict:
        """Повертає кольори поточної теми."""
        return self.themes.get(self.current_theme, self.themes["day"])
    
    def toggle_theme(self):
        """Перемикає тему день/ніч."""
        self.current_theme = "night" if self.current_theme == "day" else "day"
    
    def set_theme(self, theme_name: str):
        """Встановлює конкретну тему."""
        if theme_name in self.themes:
            self.current_theme = theme_name
#dp
# === Тема інтерфейсу ===
    
    def get_theme_colors(self):
    	"""Повертає кольори теми (для сумісності з попапами)."""
    	return self.theme_manager.get_colors()
    
    def apply_theme(self):
    	"""Застосовує поточну тему до інтерфейсу."""
    	try:
    	   colors = self.theme_manager.get_colors()
    	   # Кнопки
    	   buttons = [self.btn_listen, self.btn_pause, self.btn_edit, self.btn_next, self.btn_extra]
    	   for btn in buttons:
    	       btn.background_normal = ""
    	       btn.background_color = colors["button_bg"]
    	       btn.color = colors["button_fg"]
    	   
    	   # Текстове поле
    	   self.text_input.background_color = colors["input_bg"]
    	   self.text_input.foreground_color = colors["input_fg"]
    	   self.text_input.cursor_color = colors.get("cursor_color", (0.03, 0.85, 0.53, 1))
    	   
    	   # Фон вікна
    	   Window.clearcolor = colors["input_bg"]
    	   
    	   self.logger.debug("🎨 Тема застосована")
    	except Exception as e:
    		self.logger.error(f"❌ Помилка застосування теми: {e}")
    
    def toggle_theme(self):
    	"""Перемикає тему день/ніч."""
    	self.stop_tts()
    	self.theme_manager.toggle_theme()
    	self.apply_theme()
    	self.logger.info(f"🎨 Переключено тему: {self.theme_manager.current_theme}")
#dk

class AccentEditorApp(App):
    """Основний клас редактора наголосів."""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.config_manager = None
        self.config = {}
        self.accents = {}
        self.text_for_correction = []
        self.fixed_text = []
        self.current_idx = -1
        self.selected_word = None
        self.tts_manager = None
        self.file_manager = None
        self.text_processor = None
        self.logger = None
        self.theme_manager = None

    def build(self):
        """Побудова інтерфейсу додатку."""
        # Ініціалізація менеджерів
        self._init_managers()
        
        Window.softinput_mode = "below_target"
        return self._build_interface()

    def _init_managers(self):
        """Ініціалізація всіх менеджерів."""
        try:
            config_path = "/storage/emulated/0/a0_sb2_book_editors_suite/config.json"
            self.config_manager = get_config_manager(config_path)
            self.config = self.config_manager.load_for_editor('accent_editor')
            
            # Ініціалізація менеджерів
            self.logger = LoggingManager(
                log_dir="/storage/emulated/0/a0_sb2_book_editors_suite/testing_function/logs",
                app_name="accent_editor"
            )
            self.file_manager = FileManager(self.config_manager, 'accent_editor', self.logger)
            self.text_processor = TextProcessor(self.logger)
            self.tts_manager = TTSManager()
            self.theme_manager = ThemeManager()
            
            # Завантаження даних
            self.accents = self.file_manager.load_accents()
            
            self.logger.info("✅ Всі менеджери ініціалізовані")
            
        except Exception as e:
            error_msg = f"❌ Помилка ініціалізації менеджерів: {e}"
            if self.logger:
                self.logger.error(error_msg)
            else:
                print(error_msg)

    def _build_interface(self):
        """Побудова інтерфейсу."""
        self.logger.info("🎨 Створення елементів інтерфейсу...")
            
        root = BoxLayout(orientation='vertical', spacing=28, padding=28)

        # Верхній ряд кнопок
        top_row = BoxLayout(orientation='horizontal', size_hint_y=None, height=150, spacing=8)
        self.btn_listen = Button(text="Слухати", font_size=42)
        self.btn_pause = Button(text="Пауза", font_size=42)
        self.btn_edit = Button(text="Правити", font_size=42, disabled=True)
        self.btn_next = Button(text="Наступний", font_size=42)
        self.btn_extra = Button(text="...", font_size=42)
        
        for btn in (self.btn_listen, self.btn_pause, self.btn_edit, self.btn_next, self.btn_extra):
            top_row.add_widget(btn)

        # Текстове поле
        self.text_input = TextInput(
            font_size=self.config.get('TEXT_WIDGET_FONT_SIZE', 56),
            multiline=True
        )
        self.text_input.bind(on_touch_down=self.on_text_touch)

        # Додавання віджетів та прив'язка подій
        root.add_widget(top_row)
        root.add_widget(self.text_input)
        self._bind_events()

        # Автоматичні дії
        Clock.schedule_once(lambda *_: self.open_and_prepare_text(), 0.1)
        Clock.schedule_once(lambda *_: self.apply_theme(), 0)
        Clock.schedule_once(lambda *_: self.restore_bookmark(), 0.2)

        self.logger.info("✅ Інтерфейс успішно побудовано")
        return root

    def _bind_events(self):
        """Прив'язка подій до кнопок."""
        self.btn_listen.bind(on_press=lambda *_: self.listen_current_paragraph())
        self.btn_pause.bind(on_press=lambda *_: self.stop_tts())
        self.btn_edit.bind(on_press=self.open_edit_popup)
        self.btn_next.bind(on_press=lambda *_: self.go_next_paragraph())
        self.btn_extra.bind(on_press=lambda *_: ExtraButtonsPopup(self).open())

    # === Основні методи ===
    
    def open_and_prepare_text(self):
        """Завантажує текст та автоматично додає наголоси з словника."""
        try:
            # Завантаження тексту через FileManager
            raw_text = self.file_manager.load_input_text()
            if raw_text is None:
                return

            # Обробка тексту через TextProcessor
            accented_text = self.text_processor.add_accents_to_text(raw_text, self.accents)
            paragraphs = accented_text.split("\n")
            
            self.text_for_correction = paragraphs
            self.fixed_text = []
            self.current_idx = -1

            # Знаходимо перший непорожній абзац
            i = 0
            while i < len(paragraphs) and not paragraphs[i].strip():
                self.fixed_text.append("")
                i += 1
                
            if i < len(paragraphs):
                self.current_idx = i
                self.text_input.text = paragraphs[i]
                self.logger.info(f"📖 Відкрито абзац {i+1}/{len(paragraphs)}: {len(paragraphs[i])} символів")
            else:
                self.current_idx = len(paragraphs)
                self.text_input.text = ""
                self.logger.warning("📖 Текст порожній")
                self.show_popup("Готово", "Текст порожній.")

            self.clear_selection_state()
            
        except Exception as e:
            self.logger.error(f"❌ Помилка підготовки тексту: {e}")
            self.show_popup("Помилка", f"Не вдалося підготувати текст:\n{e}")

    def go_next_paragraph(self):
        """Переходить до наступного абзацу."""
        self.logger.info("➡️ Перехід до наступного абзацу")
        self.stop_tts()
        self.save_bookmark()
        
        if self.current_idx < 0 or self.current_idx >= len(self.text_for_correction):
            self.logger.warning("⚠️ Неможливо перейти: некоректний поточний індекс")
            return

        self.fixed_text.append(self.text_input.text)
        self.current_idx += 1
        
        # Пропускаємо порожні абзаци
        skipped_count = 0
        while (self.current_idx < len(self.text_for_correction) and 
               not self.text_for_correction[self.current_idx].strip()):
            self.fixed_text.append("")
            self.current_idx += 1
            skipped_count += 1

        if self.current_idx < len(self.text_for_correction):
            self.text_input.text = self.text_for_correction[self.current_idx]
            self.logger.info(f"✅ Перехід до абзацу {self.current_idx+1}/{len(self.text_for_correction)} (пропущено {skipped_count} порожніх)")
        else:
            self.text_input.text = ""
            self.logger.info("🏁 Досягнуто кінця тексту")
            self.show_popup("Кінець", "Досягнуто кінця тексту.")

        self.clear_selection_state()

    def listen_current_paragraph(self):
        """Відтворює поточний абзац через TTS."""
        text = self.text_input.text.strip()
        if text:
            self.logger.info(f"🔊 Відтворення TTS: {len(text)} символів")
            self.safe_tts_speak(text)
        else:
            self.logger.warning("🔊 Спроба відтворення порожнього тексту")

    def stop_tts(self):
        """Зупиняє TTS відтворення."""
        if self.tts_manager:
            self.tts_manager.stop_tts()
            self.logger.info("⏹️ TTS зупинено")

    def safe_tts_speak(self, text: str):
        """Безпечне відтворення тексту через TTS."""
        if self.tts_manager:
            self.logger.debug(f"🔊 TTS: '{text[:50]}{'...' if len(text) > 50 else ''}'")
            self.tts_manager.safe_tts_speak(text)

    # === Робота з виділенням слів ===
    
    def on_text_touch(self, instance, touch):
        """Обробка торкання текстового поля для виділення слова."""
        if not instance.collide_point(*touch.pos):
            return False
        Clock.schedule_once(lambda *_: self.detect_word_at_cursor(), 0.01)
        return False

    def detect_word_at_cursor(self):
        """Визначає слово під курсором."""
        try:
            cursor_idx = self.text_input.cursor_index()
        except Exception as e:
            self.logger.debug(f"⚠️ Помилка отримання позиції курсора: {e}")
            self.clear_selection_state()
            return

        text = self.text_input.text
        if not text:
            self.clear_selection_state()
            return

        # Знаходимо межі слова
        start = cursor_idx
        while start > 0 and self.is_word_char(text[start - 1]):
            start -= 1

        end = cursor_idx
        while end < len(text) and self.is_word_char(text[end]):
            end += 1

        word = text[start:end]
        if WORD_RE.fullmatch(word):
            self.selected_word = word
            self.btn_edit.disabled = False
            self.logger.debug(f"🔍 Виділено слово: '{word}'")
        else:
            self.clear_selection_state()

    def is_word_char(self, char: str) -> bool:
        """Перевіряє, чи символ є частиною слова."""
        return char.isalpha() or char == '\u0301' or char == "'"

    def clear_selection_state(self):
        """Очищає стан виділення."""
        if self.selected_word:
            self.logger.debug("🧹 Очищено виділення слова")
        self.selected_word = None
        self.btn_edit.disabled = True

    def open_edit_popup(self, *_):
        """Відкриває попап для редагування слова."""
        if self.selected_word:
            self.logger.info(f"✏️ Відкриття попапу редагування слова: '{self.selected_word}'")
            self.stop_tts()
            EditWordPopup(self, self.selected_word).open()

    def replace_word_in_current_paragraph(self, old_word: str, new_word: str):
        """Замінює слово в поточному абзаці."""
        if self.current_idx < 0:
            return
            
        current_text = self.text_input.text
        replaced_text = current_text.replace(old_word, new_word, 1)
        self.text_input.text = replaced_text
        
        self.logger.info(f"🔄 Замінено слово: '{old_word}' -> '{new_word}'")

    # === Збереження даних ===
    
    def save_bookmark(self):
        """Зберігає поточну позицію у конфіг."""
        if self.text_input and hasattr(self, 'config_manager'):
            try:
                cursor_pos = self.text_input.cursor_index()
                scroll_y = self.text_input.scroll_y
                self.config_manager.update_bookmark('accent_editor', cursor_pos, scroll_y)
                self.logger.debug(f"🔖 Закладка збережена: позиція {cursor_pos}")
            except Exception as e:
                self.logger.error(f"Помилка збереження закладки: {e}")

    def restore_bookmark(self):
        """Відновлює позицію з конфігу."""
        try:
            if hasattr(self, 'config_manager'):
                bookmark = self.config_manager.get_bookmark('accent_editor')
                if self.text_input and bookmark:
                    self.text_input.cursor = (bookmark['cursor_pos'], 0)
                    self.text_input.scroll_y = bookmark['scroll_y']
                    self.logger.info(f"🔖 Закладку відновлено: позиція {bookmark['cursor_pos']}")
        except Exception as e:
            self.logger.error(f"Помилка відновлення закладки: {e}")

    def save_full_text(self):
        """Зберігає весь текст у TXT файл."""
        self.stop_tts()
        self.save_bookmark()
        
        content = self.build_full_text()
        success = self.file_manager.save_output_text(content)
        
        if success:
            self.logger.info("💾 Текст успішно збережено")
        else:
            self.logger.error("❌ Помилка збереження тексту")

    def build_full_text(self) -> str:
        """Побудова повного тексту з виправленими абзацами."""
        parts = list(self.fixed_text)
        if 0 <= self.current_idx < len(self.text_for_correction):
            parts.append(self.text_input.text)
            parts.extend(self.text_for_correction[self.current_idx + 1:])
        
        full_text = "\n".join(parts)
        self.logger.debug(f"📊 Зібрано повний текст: {len(parts)} абзаців, {len(full_text)} символів")
        return full_text

    # === Тема інтерфейсу ===
    
    def apply_theme(self):
        """Застосовує поточну тему до інтерфейсу."""
        try:
            colors = self.theme_manager.get_colors()
            
            # Кнопки
            buttons = [self.btn_listen, self.btn_pause, self.btn_edit, self.btn_next, self.btn_extra]
            for btn in buttons:
                btn.background_normal = ""
                btn.background_color = colors["button_bg"]
                btn.color = colors["button_fg"]

            # Текстове поле
            self.text_input.background_color = colors["input_bg"]
            self.text_input.foreground_color = colors["input_fg"]
            self.text_input.cursor_color = colors.get("cursor_color", (0.03, 0.85, 0.53, 1))
            
            # Фон вікна
            Window.clearcolor = colors["input_bg"]
            
            self.logger.debug("🎨 Тема застосована")
        except Exception as e:
            self.logger.error(f"❌ Помилка застосування теми: {e}")

    def toggle_theme(self):
        """Перемикає тему день/ніч."""
        self.stop_tts()
        self.theme_manager.toggle_theme()
        self.apply_theme()
        self.logger.info(f"🎨 Переключено тему: {self.theme_manager.current_theme}")

    # === Утиліти ===
    
    def show_popup(self, title: str, message: str):
        """Показує спливаюче повідомлення."""
        popup = Popup(
            title=title,
            content=Label(text=message),
            size_hint=(0.8, 0.4)
        )
        popup.open()
        self.logger.debug(f"📢 Показано попап: {title}")

    def on_stop(self):
        """Викликається при закритті додатку."""
        self.save_bookmark()
        self.stop_tts()
        self.logger.info("🔴 Редактор наголосів закрито")


if __name__ == "__main__":
    AccentEditorApp().run()