# -*- coding: utf-8 -*-

#a0_sb2_book_editors_suite
#/storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite/ui/popups/extra_buttons_popup.py
"""
Попап з додатковими кнопками для редактора наголосів.
"""
from kivy.uix.popup import Popup
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.clock import Clock


class ExtraButtonsPopup(Popup):
    """Попап з додатковими функціями редактора."""
    
    def __init__(self, main_app, **kwargs):
        super().__init__(**kwargs)
        self.main_app = main_app
        self.config = parent_app.config
        self.title = "Додаткові функції"
        self.size_hint = (0.8, 0.6)
        self.auto_dismiss = True
        
        self._build_interface()
        Clock.schedule_once(lambda *_: self.apply_theme_from_app(), 0)

    def _build_interface(self):
        """Побудова інтерфейсу попапу."""
        layout = BoxLayout(orientation='vertical', spacing=10, padding=20)
        
        # Кнопки функцій
        self.btn_save = Button(
            text="Зберегти текст", 
            size_hint_y=None, 
            height=100,
            font_size=32
        )
        self.btn_save.bind(on_press=self.save_text)
        
        self.btn_theme = Button(
            text="Змінити тему", 
            size_hint_y=None, 
            height=100,
            font_size=32
        )
        self.btn_theme.bind(on_press=self.toggle_theme)
        
        self.btn_bookmark = Button(
            text="Зберегти закладку", 
            size_hint_y=None, 
            height=100,
            font_size=32
        )
        self.btn_bookmark.bind(on_press=self.save_bookmark)
        
        self.btn_close = Button(
            text="Закрити", 
            size_hint_y=None, 
            height=80,
            font_size=28
        )
        self.btn_close.bind(on_press=self.dismiss)
        
        # Додаємо кнопки до layout
        layout.add_widget(Label(text="Додаткові функції:", size_hint_y=None, height=50))
        layout.add_widget(self.btn_save)
        layout.add_widget(self.btn_theme)
        layout.add_widget(self.btn_bookmark)
        layout.add_widget(self.btn_close)
        
        self.content = layout

    def apply_theme_from_app(self):
        """Застосовує тему з головного додатку."""
        try:
            colors = self.main_app.get_theme_colors()
            
            # Застосовуємо кольори до кнопок
            buttons = [self.btn_save, self.btn_theme, self.btn_bookmark, self.btn_close]
            for btn in buttons:
                btn.background_normal = ""
                btn.background_color = colors["button_bg"]
                btn.color = colors["button_fg"]
                
            # Фон попапу
            self.background = ""
            self.background_color = colors["input_bg"]
            
        except Exception as e:
            if hasattr(self.main_app, 'logger'):
                self.main_app.logger.error(f"❌ Помилка застосування теми в попапі: {e}")

    def save_text(self, instance):
        """Зберігає текст."""
        try:
            self.main_app.save_full_text()
            self.dismiss()
        except Exception as e:
            if hasattr(self.main_app, 'logger'):
                self.main_app.logger.error(f"❌ Помилка збереження тексту: {e}")

    def toggle_theme(self, instance):
        """Перемикає тему."""
        try:
            self.main_app.toggle_theme()
            # Оновлюємо тему попапу
            self.apply_theme_from_app()
        except Exception as e:
            if hasattr(self.main_app, 'logger'):
                self.main_app.logger.error(f"❌ Помилка перемикання теми: {e}")

    def save_bookmark(self, instance):
        """Зберігає закладку."""
        try:
            self.main_app.save_bookmark()
            if hasattr(self.main_app, 'logger'):
                self.main_app.logger.info("🔖 Закладку збережено з попапу")
            self.dismiss()
        except Exception as e:
            if hasattr(self.main_app, 'logger'):
                self.main_app.logger.error(f"❌ Помилка збереження закладки: {e}")