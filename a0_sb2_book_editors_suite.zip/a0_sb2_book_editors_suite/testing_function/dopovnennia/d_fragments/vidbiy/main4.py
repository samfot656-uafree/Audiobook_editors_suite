# -*- coding: utf-8 -*-
"""
/storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite/editors/accent_editor/main.py

Головний модуль редактора наголосів.
"""

import sys
import os
import json
from pathlib import Path

# Додаємо шляхи для імпортів
sys.path.insert(0, '/storage/emulated/0/a0_sb2_book_editors_suite')
sys.path.insert(0, '/storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite')

# Kivy imports
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.popup import Popup
from kivy.uix.label import Label
from kivy.core.window import Window
from kivy.clock import Clock

# Project imports
from book_editors_suite.core.config_manager import get_config_manager
from book_editors_suite.core.tts_manager import TTSManager
from book_editors_suite.ui.popups.edit_word_popup import EditWordPopup
from book_editors_suite.ui.popups.extra_buttons_popup import ExtraButtonsPopup
from book_editors_suite.utils.helpers import WORD_RE, strip_combining_acute, match_casing

class AccentEditorApp(App):
    """Основний клас редактора наголосів."""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.config_manager = None
        self.config = {}
        self.accents = {}
        self.text_for_correction = []
        self.fixed_text = []
        self.current_idx = -1
        self.selected_word = None
        self.tts_manager = None
        self.theme_mode = "day"

    def build(self):
        """Побудова інтерфейсу додатку."""
        print("🚀 Запуск редактора наголосів...")
        
        # Ініціалізація менеджерів
        self._init_managers()
        
        Window.softinput_mode = "below_target"
        return self._build_interface()

    def _init_managers(self):
        """Ініціалізація всіх менеджерів."""
        try:
            config_path = "/storage/emulated/0/a0_sb2_book_editors_suite/config.json"
            self.config_manager = get_config_manager(config_path)
            self.config = self.config_manager.load_for_editor('accent_editor')
            self.accents = self.load_accents()
            self.tts_manager = TTSManager()
            print("✅ Всі менеджери ініціалізовані")
        except Exception as e:
            print(f"❌ Помилка ініціалізації менеджерів: {e}")

    def _build_interface(self):
        """Побудова інтерфейсу."""
        root = BoxLayout(orientation='vertical', spacing=28, padding=28)

        # Верхній ряд кнопок
        top_row = BoxLayout(orientation='horizontal', size_hint_y=None, height=150, spacing=8)
        self.btn_listen = Button(text="Слухати", font_size=42)
        self.btn_pause = Button(text="Пауза", font_size=42)
        self.btn_edit = Button(text="Правити", font_size=42, disabled=True)
        self.btn_next = Button(text="Наступний", font_size=42)
        self.btn_extra = Button(text="...", font_size=42)
        
        for btn in (self.btn_listen, self.btn_pause, self.btn_edit, self.btn_next, self.btn_extra):
            top_row.add_widget(btn)

        # Текстове поле
        self.text_input = TextInput(
            font_size=self.config.get('TEXT_WIDGET_FONT_SIZE', 56),
            multiline=True
        )
        self.text_input.bind(on_touch_down=self.on_text_touch)

        # Додавання віджетів та прив'язка подій
        root.add_widget(top_row)
        root.add_widget(self.text_input)
        self._bind_events()

        # Автоматичні дії
        Clock.schedule_once(lambda *_: self.open_and_prepare_text(), 0.1)
        Clock.schedule_once(lambda *_: self.apply_theme(), 0)
        Clock.schedule_once(lambda *_: self.restore_bookmark(), 0.2)

        return root

    def _bind_events(self):
        """Прив'язка подій до кнопок."""
        self.btn_listen.bind(on_press=lambda *_: self.listen_current_paragraph())
        self.btn_pause.bind(on_press=lambda *_: self.stop_tts())
        self.btn_edit.bind(on_press=self.open_edit_popup)
        self.btn_next.bind(on_press=lambda *_: self.go_next_paragraph())
        self.btn_extra.bind(on_press=lambda *_: ExtraButtonsPopup(self).open())

    # Решта методів залишаються незмінними (але використовують імпортовані модулі)
    # ... (load_accents, save_accents, save_bookmark, restore_bookmark, тощо)

if __name__ == "__main__":
    AccentEditorApp().run()