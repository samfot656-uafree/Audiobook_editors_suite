# -*- coding: utf-8 -*-
"""
Модуль обробки тексту.
"""
from book_editors_suite.utils.helpers import WORD_RE, strip_combining_acute, match_casing


class TextProcessor:
    """Клас для різноманітної обробки тексту."""
    
    def __init__(self, logger=None):
        self.logger = logger
    
    def add_accents_to_text(self, text: str, accents: dict) -> str:
        """Додає наголоси до тексту згідно з словником."""
        def replace_with_accent(match):
            word = match.group(0)
            if '\u0301' in word:  # Якщо вже є наголос - залишаємо
                return word
            key = strip_combining_acute(word).lower()
            if key in accents:
                return match_casing(word, accents[key])
            return word

        accented_text = WORD_RE.sub(replace_with_accent, text)
        
        if self.logger:
            self.logger.info("🔤 Наголоси додано до тексту")
            
        return accented_text
    
    def split_into_paragraphs(self, text: str) -> list:
        """Розділяє текст на абзаци."""
        paragraphs = text.split("\n")
        if self.logger:
            self.logger.debug(f"📊 Текст розділено на {len(paragraphs)} абзаців")
        return paragraphs
    
    def count_words(self, text: str) -> int:
        """Підраховує кількість слів у тексті."""
        words = text.split()
        return len(words)
    
    def find_word_positions(self, text: str, word: str) -> list:
        """Знаходить усі позиції слова у тексті."""
        positions = []
        start = 0
        while True:
            start = text.find(word, start)
            if start == -1:
                break
            positions.append(start)
            start += len(word)
        return positions