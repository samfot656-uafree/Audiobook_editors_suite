# -*- coding: utf-8 -*-
"""
/storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite/editors/accent_editor/main.py

Головний модуль редактора наголосів.
Використовує ModularConfigManager та модульну структуру.
"""

import json
import re
from pathlib import Path

# Kivy imports
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.popup import Popup
from kivy.uix.label import Label
from kivy.core.window import Window
from kivy.clock import Clock

# Project imports
try:
    from book_editors_suite.core.config_manager import get_config_manager
    from book_editors_suite.ui.popups.edit_word_popup import EditWordPopup
    from book_editors_suite.ui.popups.extra_buttons_popup import ExtraButtonsPopup
    from book_editors_suite.core.tts_manager import TTSManager
    from book_editors_suite.utils.helpers import (
        strip_combining_acute, 
        match_casing, 
        get_clock_str, 
        get_battery_percent
    )
except ImportError:
    from core.config_manager import get_config_manager
    from ui.popups.edit_word_popup import EditWordPopup
    from ui.popups.extra_buttons_popup import ExtraButtonsPopup
    from core.tts_manager import TTSManager
    from utils.helpers import (
        strip_combining_acute, 
        match_casing, 
        get_clock_str, 
        get_battery_percent
    )

# Регулярка для слів з комбінованим наголосом та апострофом
WORD_RE = re.compile(
    r"(?:[^\W\d_](?:\u0301)?)+(?:'(?:[^\W\d_](?:\u0301)?)+)*",
    flags=re.UNICODE
)


class AccentEditorApp(App):
    """Основний клас редактора наголосів з використанням ModularConfigManager."""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.config_manager = None
        self.config = {}
        self.accents = {}
        self.text_for_correction = []
        self.fixed_text = []
        self.current_idx = -1
        self.selected_word = None
        self.tts_manager = None
        self.theme_mode = "day"

    def build(self):
        """Побудова інтерфейсу додатку."""
        # Ініціалізація конфіг менеджера
        config_path = "/storage/emulated/0/a0_sb2_book_editors_suite/config.json"
        self.config_manager = get_config_manager(config_path)
        self.config = self.config_manager.load_for_editor('accent_editor')
        self.accents = self.load_accents()
        
        # Ініціалізація TTS менеджера
        self.tts_manager = TTSManager()
        
        Window.softinput_mode = "below_target"

        # Основний layout
        root = BoxLayout(orientation='vertical', spacing=28, padding=28)

        # Верхній ряд кнопок
        top_row = BoxLayout(orientation='horizontal', size_hint_y=None, height=150, spacing=8)
        self.btn_listen = Button(text="Слухати", font_size=42)
        self.btn_pause = Button(text="Пауза", font_size=42)
        self.btn_edit = Button(text="Правити", font_size=42, disabled=True)
        self.btn_next = Button(text="Наступний", font_size=42)
        self.btn_extra = Button(text="...", font_size=42)
        
        for btn in (self.btn_listen, self.btn_pause, self.btn_edit, self.btn_next, self.btn_extra):
            top_row.add_widget(btn)

        # Текстове поле
        self.text_input = TextInput(
            font_size=self.config.get('TEXT_WIDGET_FONT_SIZE', 56),
            multiline=True
        )
        self.text_input.bind(on_touch_down=self.on_text_touch)

        # Додавання віджетів
        root.add_widget(top_row)
        root.add_widget(self.text_input)

        # Прив'язка подій
        self.btn_listen.bind(on_press=lambda *_: self.listen_current_paragraph())
        self.btn_pause.bind(on_press=lambda *_: self.stop_tts())
        self.btn_edit.bind(on_press=self.open_edit_popup)
        self.btn_next.bind(on_press=lambda *_: self.go_next_paragraph())
        self.btn_extra.bind(on_press=lambda *_: ExtraButtonsPopup(self).open())

        # Автоматичні дії
        Clock.schedule_once(lambda *_: self.open_and_prepare_text(), 0.1)
        Clock.schedule_once(lambda *_: self.apply_theme(), 0)
        Clock.schedule_once(lambda *_: self.restore_bookmark(), 0.2)

        return root

    # === Конфігурація та ініціалізація ===
    
    def load_accents(self):
        """Завантажує словник наголосів з JSON файлу."""
        accents_file = self.config.get('ACCENTS_FILE', '')
        if accents_file and Path(accents_file).exists():
            try:
                with open(accents_file, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception as e:
                print(f"Помилка завантаження accents.json: {e}")
        return {}

    def save_accents(self):
        """Зберігає словник наголосів у JSON файл."""
        accents_file = self.config.get('ACCENTS_FILE', '')
        if accents_file:
            try:
                Path(accents_file).parent.mkdir(parents=True, exist_ok=True)
                with open(accents_file, "w", encoding="utf-8") as f:
                    json.dump(self.accents, f, ensure_ascii=False, indent=2)
            except Exception as e:
                print(f"Помилка збереження accents: {e}")

    def save_bookmark(self):
        """Зберігає поточну позицію у конфіг."""
        if self.text_input:
            try:
                cursor_pos = self.text_input.cursor_index()
                scroll_y = self.text_input.scroll_y
                self.config_manager.update_bookmark('accent_editor', cursor_pos, scroll_y)
            except Exception as e:
                print(f"Помилка збереження закладки: {e}")

    def restore_bookmark(self):
        """Відновлює позицію з конфігу."""
        try:
            bookmark = self.config_manager.get_bookmark('accent_editor')
            if self.text_input and bookmark:
                self.text_input.cursor = (bookmark['cursor_pos'], 0)
                self.text_input.scroll_y = bookmark['scroll_y']
        except Exception as e:
            print(f"Помилка відновлення закладки: {e}")

    # === TTS функції ===
    
    def listen_current_paragraph(self):
        """Відтворює поточний абзац через TTS."""
        text = self.text_input.text.strip()
        if text:
            self.tts_manager.safe_tts_speak(text)

    def stop_tts(self):
        """Зупиняє TTS відтворення."""
        self.tts_manager.stop_tts()

    # === Робота з текстом ===
    
    def open_and_prepare_text(self):
        """Завантажує текст та автоматично додає наголоси з словника."""
        input_file = self.config.get('INPUT_TEXT_FILE', '')
        if not input_file or not Path(input_file).exists():
            self.show_popup("Помилка", f"Файл не знайдено:\n{input_file}")
            return

        try:
            with open(input_file, "r", encoding="utf-8") as f:
                raw_text = f.read()
        except Exception as e:
            self.show_popup("Помилка", f"Не вдалося прочитати файл:\n{e}")
            return

        # Автоматичне додавання наголосів з словника
        def replace_with_accent(match):
            word = match.group(0)
            if '\u0301' in word:  # Якщо вже є наголос - залишаємо
                return word
            key = strip_combining_acute(word).lower()
            if key in self.accents:
                return match_casing(word, self.accents[key])
            return word

        accented_text = WORD_RE.sub(replace_with_accent, raw_text)
        paragraphs = accented_text.split("\n")
        
        self.text_for_correction = paragraphs
        self.fixed_text = []
        self.current_idx = -1

        # Знаходимо перший непорожній абзац
        i = 0
        while i < len(paragraphs) and not paragraphs[i].strip():
            self.fixed_text.append("")
            i += 1
            
        if i < len(paragraphs):
            self.current_idx = i
            self.text_input.text = paragraphs[i]
        else:
            self.current_idx = len(paragraphs)
            self.text_input.text = ""
            self.show_popup("Готово", "Текст порожній.")

        self.clear_selection_state()

    def go_next_paragraph(self):
        """Переходить до наступного абзацу."""
        self.stop_tts()
        self.save_bookmark()
        
        if self.current_idx < 0 or self.current_idx >= len(self.text_for_correction):
            return

        self.fixed_text.append(self.text_input.text)
        self.current_idx += 1
        
        # Пропускаємо порожні абзаци
        while (self.current_idx < len(self.text_for_correction) and 
               not self.text_for_correction[self.current_idx].strip()):
            self.fixed_text.append("")
            self.current_idx += 1

        if self.current_idx < len(self.text_for_correction):
            self.text_input.text = self.text_for_correction[self.current_idx]
        else:
            self.text_input.text = ""
            self.show_popup("Кінець", "Досягнуто кінця тексту.")

        self.clear_selection_state()

    def build_full_text(self) -> str:
        """Побудова повного тексту з виправленими абзацами."""
        parts = list(self.fixed_text)
        if 0 <= self.current_idx < len(self.text_for_correction):
            parts.append(self.text_input.text)
            parts.extend(self.text_for_correction[self.current_idx + 1:])
        return "\n".join(parts)

    # === Виділення та редагування слів ===
    
    def on_text_touch(self, instance, touch):
        """Обробка торкання текстового поля для виділення слова."""
        if not instance.collide_point(*touch.pos):
            return False
        Clock.schedule_once(lambda *_: self.detect_word_at_cursor(), 0.01)
        return False

    def detect_word_at_cursor(self):
        """Визначає слово під курсором."""
        try:
            cursor_idx = self.text_input.cursor_index()
        except Exception:
            self.clear_selection_state()
            return

        text = self.text_input.text
        if not text:
            self.clear_selection_state()
            return

        # Знаходимо межі слова
        start = cursor_idx
        while start > 0 and self.is_word_char(text[start - 1]):
            start -= 1

        end = cursor_idx
        while end < len(text) and self.is_word_char(text[end]):
            end += 1

        word = text[start:end]
        if WORD_RE.fullmatch(word):
            self.selected_word = word
            self.btn_edit.disabled = False
        else:
            self.clear_selection_state()

    def is_word_char(self, char: str) -> bool:
        """Перевіряє, чи символ є частиною слова."""
        return char.isalpha() or char == '\u0301' or char == "'"

    def clear_selection_state(self):
        """Очищає стан виділення."""
        self.selected_word = None
        self.btn_edit.disabled = True

    def open_edit_popup(self, *_):
        """Відкриває попап для редагування слова."""
        if self.selected_word:
            self.stop_tts()
            EditWordPopup(self, self.selected_word).open()

    def replace_word_in_current_paragraph(self, old_word: str, new_word: str):
        """Замінює слово в поточному абзаці."""
        if self.current_idx < 0:
            return
        current_text = self.text_input.text
        replaced_text = current_text.replace(old_word, new_word, 1)
        self.text_input.text = replaced_text

    # === Утиліти ===
    
    def show_popup(self, title: str, message: str):
        """Показує спливаюче повідомлення."""
        popup = Popup(
            title=title,
            content=Label(text=message),
            size_hint=(0.8, 0.4)
        )
        popup.open()

    # === Тема інтерфейсу ===
    
    def get_theme_colors(self):
        """Повертає кольори теми."""
        if self.theme_mode == "day":
            return {
                "button_bg": (0.5, 0.5, 0.5, 1),
                "button_fg": (1, 1, 1, 1),
                "input_bg": (1, 1, 1, 1),
                "input_fg": (0, 0, 0, 1)
            }
        else:
            return {
                "button_bg": (0, 0, 0, 1),
                "button_fg": (0.6, 0.85, 1, 1),
                "input_bg": (0, 0, 0, 1),
                "input_fg": (0, 0, 1, 1)
            }

    def apply_theme(self):
        """Застосовує поточну тему до інтерфейсу."""
        colors = self.get_theme_colors()
        
        # Кнопки
        buttons = [self.btn_listen, self.btn_pause, self.btn_edit, self.btn_next, self.btn_extra]
        for btn in buttons:
            btn.background_normal = ""
            btn.background_color = colors["button_bg"]
            btn.color = colors["button_fg"]

        # Текстове поле
        self.text_input.background_color = colors["input_bg"]
        self.text_input.foreground_color = colors["input_fg"]
        self.text_input.cursor_color = (0.03, 0.85, 0.53, 1)
        
        # Фон вікна
        Window.clearcolor = colors["input_bg"]

    def toggle_theme(self):
        """Перемикає тему день/ніч."""
        self.stop_tts()
        self.theme_mode = "night" if self.theme_mode == "day" else "day"
        self.apply_theme()

    # === Збереження файлів ===
    
    def save_full_text(self):
        """Зберігає весь текст у TXT файл."""
        self.stop_tts()
        self.save_bookmark()
        
        content = self.build_full_text()
        output_file = self.config.get('INPUT_TEXT_FILE', '')
        
        if not output_file:
            self.show_popup("Помилка", "Шлях для збереження не вказано")
            return

        try:
            Path(output_file).parent.mkdir(parents=True, exist_ok=True)
            with open(output_file, "w", encoding="utf-8") as f:
                f.write(content)
            self.show_popup("Збережено", f"TXT збережено:\n{output_file}")
        except Exception as e:
            self.show_popup("Помилка збереження", str(e))

    def on_stop(self):
        """Викликається при закритті додатку."""
        self.save_bookmark()
        self.stop_tts()


if __name__ == "__main__":
    AccentEditorApp().run()