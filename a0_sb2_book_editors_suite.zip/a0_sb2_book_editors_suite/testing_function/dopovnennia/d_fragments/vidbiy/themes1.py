# -*- coding: utf-8 -*-
"""
Менеджер тем інтерфейсу.
"""


class ThemeManager:
    """Керування темами інтерфейсу."""
    
    def __init__(self):
        self.current_theme = "day"
        self.themes = {
            "day": {
                "button_bg": (0.5, 0.5, 0.5, 1),
                "button_fg": (1, 1, 1, 1),
                "input_bg": (1, 1, 1, 1),
                "input_fg": (0, 0, 0, 1),
                "cursor_color": (0.03, 0.85, 0.53, 1)
            },
            "night": {
                "button_bg": (0, 0, 0, 1),
                "button_fg": (0.6, 0.85, 1, 1),
                "input_bg": (0, 0, 0, 1),
                "input_fg": (0, 0, 1, 1),
                "cursor_color": (0.03, 0.85, 0.53, 1)
            }
        }
    
    def get_colors(self) -> dict:
        """Повертає кольори поточної теми."""
        return self.themes.get(self.current_theme, self.themes["day"])
    
    def toggle_theme(self):
        """Перемикає тему день/ніч."""
        self.current_theme = "night" if self.current_theme == "day" else "day"
    
    def set_theme(self, theme_name: str):
        """Встановлює конкретну тему."""
        if theme_name in self.themes:
            self.current_theme = theme_name