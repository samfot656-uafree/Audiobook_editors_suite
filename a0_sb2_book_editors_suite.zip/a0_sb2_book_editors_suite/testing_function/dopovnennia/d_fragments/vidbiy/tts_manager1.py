# -*- coding: utf-8 -*-
"""
/storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite/core/tts_manager.py

Менеджер TTS для всіх редакторів.
Інкапсулює логіку роботи з Text-to-Speech.
"""

try:
    from jnius import autoclass
    TextToSpeech = autoclass('android.speech.tts.TextToSpeech')
    Locale = autoclass('java.util.Locale')
    HashMap = autoclass('java.util.HashMap')
    PythonActivity = autoclass('org.kivy.android.PythonActivity')
except Exception:
    TextToSpeech = Locale = HashMap = PythonActivity = None


class TTSManager:
    """Уніфікований менеджер TTS для всіх редакторів."""
    
    def __init__(self):
        self.tts = None
        self._init_tts()

    def _init_tts(self):
        """Ініціалізує TTS для Android."""
        if not TextToSpeech:
            return
            
        try:
            self.tts = TextToSpeech(PythonActivity.mActivity, None)
            try:
                self.tts.setLanguage(Locale.forLanguageTag("uk-UA"))
            except Exception:
                try:
                    self.tts.setLanguage(Locale("uk"))
                except Exception:
                    pass
        except Exception as e:
            print(f"Помилка ініціалізації TTS: {e}")

    def safe_tts_speak(self, text: str):
        """Безпечне відтворення тексту через TTS."""
        if text and self.tts:
            try:
                params = HashMap()
                params.put("volume", "1.0")
                self.tts.speak(text, TextToSpeech.QUEUE_FLUSH, params)
            except Exception as e:
                print(f"Помилка TTS speak: {e}")

    def stop_tts(self):
        """Зупиняє TTS відтворення."""
        if self.tts:
            try:
                self.tts.stop()
            except Exception as e:
                print(f"Помилка TTS stop: {e}")

    def set_speech_rate(self, rate: float):
        """Встановлює швидкість мовлення."""
        if self.tts:
            try:
                self.tts.setSpeechRate(rate)
            except Exception:
                pass