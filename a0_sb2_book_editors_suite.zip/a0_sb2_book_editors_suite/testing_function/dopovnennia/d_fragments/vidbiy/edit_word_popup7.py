# -*- coding: utf-8 -*-
"""
Попап для редагування слова з наголосом.
"""
from kivy.uix.popup import Popup
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.clock import Clock

from book_editors_suite.utils.helpers import strip_combining_acute, match_casing


class EditWordPopup(Popup):
    """Попап для редагування слова та додавання наголосу."""
    
    def __init__(self, main_app, word, **kwargs):
        super().__init__(**kwargs)
        self.main_app = main_app
        self.original_word = word
        self.title = f"Редагувати слово: {word}"
        self.size_hint = (0.9, 0.5)
        self.auto_dismiss = False
        
        self._build_interface()
        Clock.schedule_once(lambda *_: self.apply_theme_from_app(), 0)

    def _build_interface(self):
        """Побудова інтерфейсу попапу."""
        layout = BoxLayout(orientation='vertical', spacing=15, padding=20)
        
        # Поточне слово
        layout.add_widget(Label(
            text=f"Поточне слово: {self.original_word}",
            size_hint_y=None,
            height=40
        ))
        
        # Поле для редагування
        self.edit_input = TextInput(
            text=self.original_word,
            multiline=False,
            size_hint_y=None,
            height=80,
            font_size=32
        )
        layout.add_widget(self.edit_input)
        
        # Рядок кнопок
        buttons_layout = BoxLayout(orientation='horizontal', spacing=10, size_hint_y=None, height=80)
        
        self.btn_save = Button(text="Зберегти", font_size=28)
        self.btn_save.bind(on_press=self.save_word)
        
        self.btn_cancel = Button(text="Скасувати", font_size=28)
        self.btn_cancel.bind(on_press=self.dismiss)
        
        self.btn_listen = Button(text="Слухати", font_size=28)
        self.btn_listen.bind(on_press=self.listen_word)
        
        buttons_layout.add_widget(self.btn_save)
        buttons_layout.add_widget(self.btn_listen)
        buttons_layout.add_widget(self.btn_cancel)
        
        layout.add_widget(buttons_layout)
        self.content = layout

    def apply_theme_from_app(self):
        """Застосовує тему з головного додатку."""
        try:
            colors = self.main_app.get_theme_colors()
            
            # Застосовуємо кольори до кнопок
            buttons = [self.btn_save, self.btn_cancel, self.btn_listen]
            for btn in buttons:
                btn.background_normal = ""
                btn.background_color = colors["button_bg"]
                btn.color = colors["button_fg"]
            
            # Текстове поле
            self.edit_input.background_color = colors["input_bg"]
            self.edit_input.foreground_color = colors["input_fg"]
            self.edit_input.cursor_color = colors.get("cursor_color", (0.03, 0.85, 0.53, 1))
            
            # Фон попапу
            self.background = ""
            self.background_color = colors["input_bg"]
            
        except Exception as e:
            if hasattr(self.main_app, 'logger'):
                self.main_app.logger.error(f"❌ Помилка застосування теми в попапі: {e}")

    def save_word(self, instance):
        """Зберігає змінене слово."""
        try:
            new_word = self.edit_input.text.strip()
            
            if not new_word:
                return
                
            if new_word != self.original_word:
                # Замінюємо слово в тексті
                self.main_app.replace_word_in_current_paragraph(self.original_word, new_word)
                
                # Оновлюємо словник наголосів
                key = strip_combining_acute(self.original_word).lower()
                new_key = strip_combining_acute(new_word).lower()
                
                # Видаляємо старий запис, якщо ключ змінився
                if key != new_key and key in self.main_app.accents:
                    del self.main_app.accents[key]
                
                # Додаємо новий запис
                self.main_app.accents[new_key] = new_word
                
                # Зберігаємо словник
                self.main_app.file_manager.save_accents(self.main_app.accents)
                
                if hasattr(self.main_app, 'logger'):
                    self.main_app.logger.info(f"💾 Слово збережено: '{self.original_word}' -> '{new_word}'")
            
            self.dismiss()
            
        except Exception as e:
            if hasattr(self.main_app, 'logger'):
                self.main_app.logger.error(f"❌ Помилка збереження слова: {e}")


# Додайте цей метод до класу EditWordPopup:

def apply_theme(self):
    """Застосовує тему до попапу."""
    try:
        colors = self.parent_app.get_theme_colors()
        
        # Застосування кольорів до елементів попапу
        self.background = ''
        self.background_color = colors["input_bg"]
        
        # Застосування до кнопок
        buttons = [self.btn_save, self.btn_cancel]
        for btn in buttons:
            btn.background_normal = ""
            btn.background_color = colors["button_bg"]
            btn.color = colors["button_fg"]
            
        # Застосування до текстових полів
        text_inputs = [self.input_original, self.input_replacement]
        for text_input in text_inputs:
            text_input.background_color = colors["input_bg"]
            text_input.foreground_color = colors["input_fg"]
            text_input.cursor_color = colors.get("cursor_color", (0.03, 0.85, 0.53, 1))
            
    except Exception as e:
        print(f"Помилка застосування теми в попапі: {e}")


    def listen_word(self, instance):
        """Відтворює слово через TTS."""
        try:
            word_to_speak = self.edit_input.text.strip()
            if word_to_speak:
                self.main_app.safe_tts_speak(word_to_speak)
        except Exception as e:
            if hasattr(self.main_app, 'logger'):
                self.main_app.logger.error(f"❌ Помилка відтворення слова: {e}")