"""
Менеджер конфігурації для всіх редакторів книг.
Проста логіка: спільні параметри тільки для читання, особисті - для читання та запису.
"""

import json
import re
import os
from pathlib import Path
from typing import Dict, Any, List, Optional


class ModularConfigManager:
    """
    Модульний менеджер конфігурації для всіх редакторів книг.
    Проста логіка: спільні параметри тільки для читання, особисті - для читання та запису.
    """
    
    def __init__(self, config_path: str):
        self.config_file = Path(config_path)
        self.data = {}
        
        # Спільні параметри (только для чтения)
        self.common_params = {
            'params': [
                'CONFIG_VERSION',
                'TEXT_WIDGET_FONT_SIZE',
                'BBTN_FONT_SIZE',
                'BBTN_HEIGHT',
                'ACCENT_CHAR',
                'INPUT_TEXT_FILE',
                'OUTPUT_FOLDER',
                'TEMP_FOLDER',
                'VOICE_DICT',
                'PAUSE_DICT'
            ],
            'defaults': {
                'CONFIG_VERSION': '0_0_0_2',
                'TEXT_WIDGET_FONT_SIZE': 56,
                'BBTN_FONT_SIZE': 38,
                'BBTN_HEIGHT': 120,
                'ACCENT_CHAR': '\u0301',
                'INPUT_TEXT_FILE': '/storage/emulated/0/Documents/pidgotovka_knigi/txt/Чекаючий.1.1.Шлях_до_заснування.S-t-i-k-s.txt',
                'OUTPUT_FOLDER': '/storage/emulated/0/Documents/pidgotovka_knigi/txt',
                'TEMP_FOLDER': '/storage/emulated/0/Documents/pidgotovka_knigi/temp_folder',
                'VOICE_DICT': {
                    "G1": "Розповідач",
                    "G2": "Чоловік1", 
                    "G3": "Чоловік2",
                    "G4": "Жінка1",
                    "G5": "Жінка2",
                    "G6": "Хлопець",
                    "G7": "Дівчина",
                    "G8": "Думки чол",
                    "G9": "Думки жін"
                },
                'PAUSE_DICT': {
                    "P4": "PAUSE_4",
                    "P7": "PAUSE_7", 
                    "P1": "PAUSE_1",
                    "P2": "PAUSE_2"
                },
            }
        }
        
        # Особисті параметри кожного редактора
        self.editor_registry = {
            'accent_editor': {
                'params': [
                    'ACCENTS_FILE',
                    'OUTPUT_MP3_FOLDER', 
                    'TTS_MODE', 
                    'DO_SPLIT',
                    'BOOKMARK'
                ],
                'defaults': {
                    'ACCENTS_FILE': '/storage/emulated/0/Documents/pidgotovka_knigi/jsons/accents_probl.json',
                    'OUTPUT_MP3_FOLDER': '/storage/emulated/0/Documents/pidgotovka_knigi/output_mp3',
                    'TTS_MODE': 'gTTS', 
                    'DO_SPLIT': False,
                    'BOOKMARK': {'cursor': 0, 'scroll': 0.0}
                }
            },
            'voice_tags_editor': {
                'params': [
                    'PAUSE_4_MP3',
                    'PAUSE_7_MP3', 
                    'PAUSE_1_MP3', 
                    'PAUSE_2_MP3',
                    'PAUSE_4_WAV',
                    'PAUSE_7_WAV', 
                    'PAUSE_1_WAV', 
                    'PAUSE_2_WAV',
                    "MELODY_START_MP3",
                    "MELODY_END_MP3",
                    "MELODY_START_WAV",
                    "MELODY_END_WAV",
                    "TEST_WAV",                    
                    'BOOKMARK'
                ],
                'defaults': {
                    "PAUSE_4_MP3": "/storage/emulated/0/Documents/Inp_mp3/silence_0.4s.mp3",
                    "PAUSE_7_MP3": "/storage/emulated/0/Documents/Inp_mp3/silence_0.7s.mp3",
                    "PAUSE_1_MP3": "/storage/emulated/0/Documents/Inp_mp3/silence_1.0s.mp3",
                    "PAUSE_2_MP3": "/storage/emulated/0/Documents/Inp_mp3/Pause_s2.mp3",
                    "PAUSE_4_WAV": "/storage/emulated/0/Documents/Inp_mp3/silence__0.4s.wav",
                    "PAUSE_7_WAV": "/storage/emulated/0/Documents/Inp_mp3/silence__0.7s.wav",
                    "PAUSE_1_WAV": "/storage/emulated/0/Documents/Inp_mp3/silence__1.0s.wav",
                    "PAUSE_2_WAV": "/storage/emulated/0/Documents/Inp_mp3/Vr_mel_multispeakers2/MELODY_END.wav",
                    "MELODY_START_MP3": "/storage/emulated/0/Documents/Inp_mp3/MELODY_START.mp3",
                    "MELODY_END_MP3": "/storage/emulated/0/Documents/Inp_mp3/MELODY_END.mp3",
                    "MELODY_START_WAV": "/storage/emulated/0/Documents/Inp_mp3/Початок_глави.wav",
                    "MELODY_END_WAV": "/storage/emulated/0/Documents/Inp_mp3/Завершення_глави.wav",
                    "TEST_WAV": "/storage/emulated/0/Documents/Inp_mp3/part_097.wav",
                    'BOOKMARK': {'cursor': 0, 'scroll': 0.0}
                }
            },
            'sound_effects_editor': {
                'params': [
                    'SOUNDS_EFFECTS_LIST', 
                    'SOUNDS_EFFECTS_FILES',
                    'SOUNDS_EFFECTS_INPUT_FOLDER',
                    'SOUND_DICT',
                    'BOOKMARK'
                ],
                'defaults': {
                    'SOUND_DICT': {
                        "S1": "Звук_пострілу_part_022",                        
                        "S2": "Машина_гальмує_part_027", 
                        "S3": "Гарчання_мутанта1_part_047"
                    },
                    'SOUNDS_EFFECTS_LIST': '/storage/emulated/0/Documents/pidgotovka_knigi/jsons/scenarios_ozvuch_c4.json',
                    'SOUNDS_EFFECTS_FILES': '/storage/emulated/0/Documents/pidgotovka_knigi/jsons/sounds_effect_files_dict.json',
                    'SOUNDS_EFFECTS_INPUT_FOLDER': '/storage/emulated/0/Documents/pidgotovka_knigi/input_sounds_effects',
                    'BOOKMARK': {'cursor': 0, 'scroll': 0.0}
                }
            },
            'multispeaker_tts': {
                'params': [
                    'INPUT_SOUNDS_FOLDER',
                    'FRAGMENT_SOFT_LIMIT',
                    'FRAGMENT_HARD_LIMIT', 
                    'DO_SPLIT',
                    'DO_MERGE',
                    'TTS_MODE',
                    'SOUND_DICT',
                    'BOOKMARK'
                ],
                'defaults': {
                    'INPUT_SOUNDS_FOLDER': '/storage/emulated/0/Documents/pidgotovka_knigi/input_melodu',
                    'FRAGMENT_SOFT_LIMIT': 900,
                    'FRAGMENT_HARD_LIMIT': 1000,
                    'DO_SPLIT': True,
                    'DO_MERGE': False,
                    'TTS_MODE': 'TFile',
                    'SOUND_DICT': {
                        "S1": "Звук_пострілу_part_022",
                        "S2": "Машина_гальмує_part_027", 
                        "S3": "Гарчання_мутанта1_part_047"
                    },
                    'BOOKMARK': {'cursor': 0, 'scroll': 0.0}
                }
            }
        }
        
        # Завантажуємо конфіг при ініціалізації
        self.load_full_config()

    def ensure_config(self):
        """Створює базовий конфіг, якщо його не існує"""
        if not self.config_file.exists():
            self.config_file.parent.mkdir(parents=True, exist_ok=True)
            
            base_config = {}
            
            # Додаємо спільні параметри
            for param, value in self.common_params['defaults'].items():
                common_param = f"COMMON_{param.upper()}"
                base_config[common_param] = value
            
            # Додаємо особисті параметри кожного редактора
            for editor_name, editor_info in self.editor_registry.items():
                for param, value in editor_info['defaults'].items():
                    personal_param = f"{editor_name.upper()}_{param.upper()}"
                    base_config[personal_param] = value
            
            self.save_full_config(base_config)
            print(f"ensure_config: ✅ Створено новий конфіг: {self.config_file}\n")
        else:
            print(f"ensure_config: ✅ Використовується існуючий конфіг: {self.config_file}\n")

    def load_full_config(self) -> Dict[str, Any]:
        """Завантажує повний конфіг з файлу"""
        self.ensure_config()  # Гарантуємо наявність конфігу
        
        if self.config_file.exists():
            try:
                with open(self.config_file, "r", encoding="utf-8") as f:
                    self.data = json.load(f)
                print(f"load_full_config: ✅ Завантажено конфіг: {len(self.data)} параметрів\n")
            except Exception as e:
                print(f"load_full_config: ❌ Помилка завантаження конфігу: {e}\n")
                self.data = {}
        return self.data
 
    def load_for_editor(self, editor_name: str) -> Dict[str, Any]:
        """Завантажує тільки параметри потрібні конкретному редактору"""
        if editor_name not in self.editor_registry:
            raise ValueError(f"load_for_editor: ❌ Невідомий редактор: {editor_name}\n")
            
        editor_config = {}
        
        # Завантажуємо спільні параметри (тільки для читання)
        for param in self.common_params['params']:
            if param in self.data:
                editor_config[param] = self.data[param]
            elif param in self.common_params['defaults']:
                editor_config[param] = self.common_params['defaults'][param]
        
        # Завантажуємо особисті параметри редактора
        for param in self.editor_registry[editor_name]['params']:
            personal_param = f"{editor_name.upper()}_{param.upper()}"
            if personal_param in self.data:
                editor_config[param] = self.data[personal_param]
            elif param in self.editor_registry[editor_name]['defaults']:
                editor_config[param] = self.editor_registry[editor_name]['defaults'][param]
        
        print(f"load_for_editor: ✅ Завантажено конфіг для {editor_name}: {len(editor_config)} параметрів\n")
        return editor_config
 
    def save_from_editor(self, editor_name: str, editor_data: Dict[str, Any]):
        """Зберігає тільки особисті параметри від конкретного редактора"""
        if editor_name not in self.editor_registry:
            raise ValueError(f"save_from_editor: ❌ Невідомий редактор: {editor_name}\n")
            
        # Оновлюємо тільки особисті параметри редактора
        updated_params = []
        
        for param, value in editor_data.items():
            # Перевіряємо чи параметр є особистим для редактора
            if param in self.editor_registry[editor_name]['params']:
                personal_param = f"{editor_name.upper()}_{param.upper()}"
                self.data[personal_param] = value
                updated_params.append(personal_param)
        
        # Зберігаємо оновлений конфіг
        if updated_params:
            self.save_full_config()
            print(f"save_from_editor: ✅ Оновлено особисті параметри {editor_name}: {len(updated_params)} параметрів\n")
                
    def save_full_config(self, data: Dict[str, Any] = None):
        """Зберігає повний конфіг у файл"""
        if data is not None:
            self.data = data
            
        try:
            self.config_file.parent.mkdir(parents=True, exist_ok=True)
            with open(self.config_file, "w", encoding="utf-8") as f:
                json.dump(self.data, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            print(f"save_full_config: ❌ Помилка збереження конфігу: {e}\n")
            return False

    def load_config_dict(self) -> Dict[str, Any]:
        """Завантажує конфіг як словник"""
        if self.config_file.exists():
            try:
                with open(self.config_file, "r", encoding="utf-8") as f:
                    return json.load(f) or {}
            except Exception as e:
                print(f"load_config_dict: ❌ Помилка читання конфігу: {e}\n")
                return {}
        return {}

    def update_bookmark(self, editor_name: str, cursor_pos: int, scroll_y: float):
        """Оновлює закладку для конкретного редактора"""
        updates = {
            'BOOKMARK': {
                'cursor': int(cursor_pos),
                'scroll': float(scroll_y)
            }
        }
        self.save_from_editor(editor_name, updates)
        print(f"update_bookmark: ✅ Оновлено закладку для {editor_name}: cursor={cursor_pos}, scroll={scroll_y}\n")
       
    def get_bookmark(self, editor_name: str) -> Dict[str, Any]:
        """Отримує закладку для конкретного редактора"""
        editor_config = self.load_for_editor(editor_name)
        bookmark = editor_config.get('BOOKMARK', {'cursor': 0, 'scroll': 0.0})
        return {
            'scroll_y': bookmark.get('scroll', 0.0),
            'cursor_pos': bookmark.get('cursor', 0)
        }

    def get_common_param(self, param_name: str, default=None):
        """Отримує значення спільного параметра (тільки читання)"""
        common_param = f"COMMON_{param_name.upper()}"
        return self.data.get(common_param, default)

    def get_personal_param(self, editor_name: str, param_name: str, default=None):
        """Отримує значення особистого параметра"""
        if editor_name not in self.editor_registry:
            raise ValueError(f"get_personal_param: ❌ Невідомий редактор: {editor_name}\n")
            
        personal_param = f"{editor_name.upper()}_{param_name.upper()}"
        return self.data.get(personal_param, default)
        
    def set_personal_param(self, editor_name: str, param_name: str, value):
        """Встановлює значення особистого параметра"""
        if editor_name not in self.editor_registry:
            raise ValueError(f"set_personal_param: ❌ Невідомий редактор: {editor_name}\n")
            
        if param_name not in self.editor_registry[editor_name]['params']:
            print(f"set_personal_param: ⚠️ Параметр {param_name} не знайдено в особистих параметрах {editor_name}\n")
            return False
            
        personal_param = f"{editor_name.upper()}_{param_name.upper()}"
        self.data[personal_param] = value
        return self.save_full_config()

    def update_voice_dict(self, editor_name: str, voice_dict: Dict[str, str]):
        """Оновлює словник голосів для конкретного редактора"""
        self.set_personal_param(editor_name, 'voice_dict', voice_dict)
        
    def update_sound_dict(self, editor_name: str, sound_dict: Dict[str, str]):
        """Оновлює словник звукових ефектів для конкретного редактора"""
        self.set_personal_param(editor_name, 'sound_dict', sound_dict)

    def sanitize_name(self, s: str, for_filename: bool = True) -> str:
        """Очищує рядок для використання в назвах файлів"""
        s2 = re.sub(r"^##\s* ", "", s)
        s2 = re.sub(r"#g\d+: ? ", "", s2)
        s2 = re.sub(r"#S\d+: ? ", "", s2)
        s2 = s2.strip()
        
        if for_filename:
            s2 = re.sub(r"[^\w\d_-]", "_", s2)
            if not s2:
                s2 = "Глава"
        return s2
        
    def get_editor_info(self, editor_name: str) -> Dict[str, Any]:
        """Повертає інформацію про редактор та його параметри"""
        if editor_name not in self.editor_registry:
            return {}
        
        info = {
            'name': editor_name,
            'personal_params': self.editor_registry[editor_name]['params'],
            'common_params': self.common_params['params'],
            'loaded_config': self.load_for_editor(editor_name)
        }
        return info
        
    def list_editors(self) -> List[str]:
        """Повертає список доступних редакторів"""
        return list(self.editor_registry.keys())


# Синглтон для глобального доступу
_global_config_manager = None

def get_config_manager(config_path: str = None) -> ModularConfigManager:
    """Повертає глобальний екземпляр менеджера конфігурації"""
    global _global_config_manager
    if _global_config_manager is None and config_path:
        _global_config_manager = ModularConfigManager(config_path)
    return _global_config_manager

def reset_config_manager():
    """Скидає глобальний екземпляр менеджера конфігурації (для тестування)"""
    global _global_config_manager
    _global_config_manager = None
    print("reset_config_manager: ✅ Синглтон конфіг менеджера скинуто\n")

# Експорт функцій та класів
__all__ = ['ModularConfigManager', 'get_config_manager', 'reset_config_manager']