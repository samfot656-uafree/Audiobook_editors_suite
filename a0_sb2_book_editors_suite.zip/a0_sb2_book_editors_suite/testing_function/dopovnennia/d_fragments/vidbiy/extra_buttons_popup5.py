# -*- coding: utf-8 -*-

#a0_sb2_book_editors_suite
#/storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite/ui/popups/extra_buttons_popup.py
"""
Попап з додатковими кнопками для редактора наголосів.
"""
from kivy.uix.popup import Popup
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.clock import Clock


class ExtraButtonsPopup(Popup):
    """Попап з додатковими функціями редактора."""
    
    def __init__(self, main_app, **kwargs):
        super().__init__(**kwargs)
        self.main_app = main_app
        self.config = main_app.config     
        self.bbtn_font_size=self.main_app.config_manager.get_common_param('BBTN_FONT_SIZE', 38)     
        self.bbtn_height=self.main_app.config_manager.get_common_param('BBTN_HEIGHT', 120)
        self.title = "Додаткові функції"
        self.size_hint = (0.9, 0.4)
        self.auto_dismiss = True
        
        self._build_interface()
        Clock.schedule_once(lambda *_: self.apply_theme_from_app(), 0)

    def _build_interface(self):
        """Побудова інтерфейсу попапу."""
        layout = BoxLayout(orientation='vertical', spacing=8, padding=6)
        btn_row = BoxLayout(size_hint_y=None, height=self.bbtn_height, spacing=8)


                
        # Кнопки функцій
        self.btn_save = Button(
            text="Зберегти текст", 
            size_hint_y=None, 
            font_size=self.bbtn_font_size
        )
        self.btn_save.bind(on_press=self.save_text)
        
        self.btn_theme = Button(
            text="Змінити тему", 
            size_hint_y=None, 
          
            font_size=self.bbtn_font_size
        )
        self.btn_theme.bind(on_press=self.toggle_theme)
        
        self.btn_bookmark = Button(
            text="Зберегти закладку", 
            size_hint_y=None, 
            height=self.bbtn_height,
            font_size=self.bbtn_font_size
        )
        self.btn_bookmark.bind(on_press=self.save_bookmark)
        self.btn_reset_bm = Button(text="Закладку 0", font_size=self.bbtn_font_size)
        
        self.btn_close = Button(
            text="Закрити", 
            size_hint_y=None, 
            height=self.bbtn_height,
            font_size=self.bbtn_font_size
        )
        self.btn_close.bind(on_press=self.dismiss)
        
        # Додаємо кнопки до layout

        layout.add_widget(btn_row)
        btn_row.add_widget(self.btn_save)
        btn_row.add_widget(self.btn_theme)
        btn_row.add_widget(self.btn_bookmark)
        btn_row.add_widget(self.btn_reset_bm)
        btn_row.add_widget(self.btn_close)
        layout.add_widget(Label())
        
        self.content = layout

    def apply_theme_from_app(self):
        """Застосовує тему з головного додатку."""
        try:
            colors = self.main_app.get_theme_colors()
            
            # Застосовуємо кольори до кнопок
            buttons = [self.btn_save, self.btn_theme, self.btn_bookmark, btn_reset_bm, self.btn_close]
            for btn in buttons:
                btn.background_normal = ""
                btn.background_color = colors["button_bg"]
                btn.color = colors["button_fg"]
                
            # Фон попапу
            self.background = ""
            self.background_color = colors["input_bg"]
            
        except Exception as e:
            if hasattr(self.main_app, 'logger'):
                self.main_app.logger.error(f"❌ Помилка застосування теми в попапі: {e}")

    def save_text(self, instance):
        """Зберігає текст."""
        try:
            self.main_app.save_full_text()
            self.dismiss()
        except Exception as e:
            if hasattr(self.main_app, 'logger'):
                self.main_app.logger.error(f"❌ Помилка збереження тексту: {e}")

    def toggle_theme(self, instance):
        """Перемикає тему."""
        try:
            self.main_app.toggle_theme()
            # Оновлюємо тему попапу
            self.apply_theme_from_app()
        except Exception as e:
            if hasattr(self.main_app, 'logger'):
                self.main_app.logger.error(f"❌ Помилка перемикання теми: {e}")

    def save_bookmark(self, instance):
        """Зберігає закладку."""
        try:
            self.main_app.save_bookmark()
            if hasattr(self.main_app, 'logger'):
                self.main_app.logger.info("🔖 Закладку збережено з попапу")
            self.dismiss()
        except Exception as e:
            if hasattr(self.main_app, 'logger'):
                self.main_app.logger.error(f"❌ Помилка збереження закладки: {e}")