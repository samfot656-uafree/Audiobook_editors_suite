"""
Головний модуль для тестування системи редакторів книг.
Налаштовує логування та імпортує основні компоненти.
"""

import os
import sys
import logging
import logging.config  # Додано імпорт для dictConfig
from pathlib import Path

# Додаємо шлях до кореневої папки проекту для імпортів
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

def setup_logging():
    """Налаштовує логування для всієї системи"""
    
    # Створюємо папку для логів
    log_dir = Path(__file__).parent / 'logs'
    log_dir.mkdir(exist_ok=True)
    
    # Конфігурація логування
    logging_config = {
        'version': 1,
        'disable_existing_loggers': False,
        'formatters': {
            'detailed': {
                'format': '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                'datefmt': '%Y-%m-%d %H:%M:%S'
            },
            'simple': {
                'format': '%(levelname)s - %(message)s'
            }
        },
        'handlers': {
            # Файл для конфіг менеджера
            'config_file': {
                'class': 'logging.FileHandler',
                'filename': str(log_dir / 'config_manager.log'),
                'formatter': 'detailed',
                'encoding': 'utf-8'
            },
            # Файл для редактора наголосів
            'accent_editor_file': {
                'class': 'logging.FileHandler',
                'filename': str(log_dir / 'accent_editor.log'),
                'formatter': 'detailed',
                'encoding': 'utf-8'
            },
            # Файл для редактора тегів голосів
            'voice_tags_editor_file': {
                'class': 'logging.FileHandler',
                'filename': str(log_dir / 'voice_tags_editor.log'),
                'formatter': 'detailed',
                'encoding': 'utf-8'
            },
            # Файл для редактора звукових ефектів
            'sound_effects_editor_file': {
                'class': 'logging.FileHandler',
                'filename': str(log_dir / 'sound_effects_editor.log'),
                'formatter': 'detailed',
                'encoding': 'utf-8'
            },
            # Файл для мультиспікер TTS
            'multispeaker_tts_file': {
                'class': 'logging.FileHandler',
                'filename': str(log_dir / 'multispeaker_tts.log'),
                'formatter': 'detailed',
                'encoding': 'utf-8'
            },
            # Консольний вивід для відладки
            'console': {
                'class': 'logging.StreamHandler',
                'formatter': 'simple',
                'stream': sys.stdout
            }
        },
        'loggers': {
            'config_manager': {
                'handlers': ['config_file', 'console'],
                'level': 'INFO',
                'propagate': False
            },
            'accent_editor': {
                'handlers': ['accent_editor_file', 'console'],
                'level': 'INFO',
                'propagate': False
            },
            'voice_tags_editor': {
                'handlers': ['voice_tags_editor_file', 'console'],
                'level': 'INFO',
                'propagate': False
            },
            'sound_effects_editor': {
                'handlers': ['sound_effects_editor_file', 'console'],
                'level': 'INFO',
                'propagate': False
            },
            'multispeaker_tts': {
                'handlers': ['multispeaker_tts_file', 'console'],
                'level': 'INFO',
                'propagate': False
            }
        },
        'root': {
            'handlers': ['console'],
            'level': 'WARNING'
        }
    }
    
    # Застосовуємо конфігурацію
    logging.config.dictConfig(logging_config)
    
    print(f"✅ Логування налаштовано. Лог-файли у: {log_dir}")

def test_config_manager():
    """Тестує роботу конфіг менеджера"""
    try:
        from book_editors_suite.core.config_manager import ModularConfigManager
        
        # Шлях до тестового конфігу
        test_config_path = Path(__file__).parent / 'test_config.json'
        
        # Створюємо менеджер конфігурації
        config_manager = ModularConfigManager(str(test_config_path))
        
        # Тестуємо завантаження для різних редакторів
        editors = ['accent_editor', 'voice_tags_editor', 'sound_effects_editor', 'multispeaker_tts']
        
        for editor in editors:
            try:
                editor_config = config_manager.load_for_editor(editor)
                print(f"✅ {editor}: завантажено {len(editor_config)} параметрів")
            except Exception as e:
                print(f"❌ {editor}: помилка - {e}")
        
        return config_manager
        
    except Exception as e:
        print(f"❌ Помилка імпорту або роботи config_manager: {e}")
        return None

def main():
    """Головна функція тестування"""
    print("🚀 Запуск тестування системи редакторів книг...")
    
    # Налаштовуємо логування
    setup_logging()
    
    # Тестуємо конфіг менеджер
    config_manager = test_config_manager()
    
    if config_manager:
        print("✅ Конфіг менеджер успішно протестовано")
        
        # Додаткові тести можна додати тут
        print("\n📋 Доступні редактори:")
        editors = config_manager.list_editors()
        for editor in editors:
            info = config_manager.get_editor_info(editor)
            print(f"  • {editor}: {len(info['personal_params'])} особистих параметрів")
    
    print("\n🎯 Тестування завершено. Перевірте лог-файли для деталей.")

if __name__ == "__main__":
    main()

#"""
#Головний модуль для тестування системи редакторів книг.
#Налаштовує логування та імпортує основні компоненти.
#"""

#import os
#import sys
#import logging
#from pathlib import Path

# Додаємо шлях до кореневої папки проекту для імпортів
#project_root = Path(__file__).parent.parent
#sys.path.insert(0, str(project_root))

#def setup_logging():
#    """Налаштовує логування для всієї системи"""
#    
#    # Створюємо папку для логів
#    log_dir = Path(__file__).parent / 'logs'
#    log_dir.mkdir(exist_ok=True)
#    
#    # Конфігурація логування
#    logging_config = {
#        'version': 1,
#        'disable_existing_loggers': False,
#        'formatters': {
#            'detailed': {
#                'format': '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
#                'datefmt': '%Y-%m-%d %H:%M:%S'
#            },
#            'simple': {
#                'format': '%(levelname)s - %(message)s'
#            }
#        },
#        'handlers': {
#            # Файл для конфіг менеджера
#            'config_file': {
#                'class': 'logging.FileHandler',
#                'filename': str(log_dir / 'config_manager.log'),
#                'formatter': 'detailed',
#                'encoding': 'utf-8'
#            },
#            # Файл для редактора наголосів
#            'accent_editor_file': {
#                'class': 'logging.FileHandler',
#                'filename': str(log_dir / 'accent_editor.log'),
#                'formatter': 'detailed',
#                'encoding': 'utf-8'
#            },
#            # Файл для редактора тегів голосів
#            'voice_tags_editor_file': {
#                'class': 'logging.FileHandler',
#                'filename': str(log_dir / 'voice_tags_editor.log'),
#                'formatter': 'detailed',
#                'encoding': 'utf-8'
#            },
#            # Файл для редактора звукових ефектів
#            'sound_effects_editor_file': {
#                'class': 'logging.FileHandler',
#                'filename': str(log_dir / 'sound_effects_editor.log'),
#                'formatter': 'detailed',
#                'encoding': 'utf-8'
#            },
#            # Файл для мультиспікер TTS
#            'multispeaker_tts_file': {
#                'class': 'logging.FileHandler',
#                'filename': str(log_dir / 'multispeaker_tts.log'),
#                'formatter': 'detailed',
#                'encoding': 'utf-8'
#            },
#            # Консольний вивід для відладки
#            'console': {
#                'class': 'logging.StreamHandler',
#                'formatter': 'simple',
#                'stream': sys.stdout
#            }
#        },
#        'loggers': {
#            'config_manager': {
#                'handlers': ['config_file', 'console'],
#                'level': 'INFO',
#                'propagate': False
#            },
#            'accent_editor': {
#                'handlers': ['accent_editor_file', 'console'],
#                'level': 'INFO',
#                'propagate': False
#            },
#            'voice_tags_editor': {
#                'handlers': ['voice_tags_editor_file', 'console'],
#                'level': 'INFO',
#                'propagate': False
#            },
#            'sound_effects_editor': {
#                'handlers': ['sound_effects_editor_file', 'console'],
#                'level': 'INFO',
#                'propagate': False
#            },
#            'multispeaker_tts': {
#                'handlers': ['multispeaker_tts_file', 'console'],
#                'level': 'INFO',
#                'propagate': False
#            }
#        },
#        'root': {
#            'handlers': ['console'],
#            'level': 'WARNING'
#        }
#    }
#    
#    # Застосовуємо конфігурацію
#    logging.config.dictConfig(logging_config)
#    
#    print(f"✅ Логування налаштовано. Лог-файли у: {log_dir}")

#def test_config_manager():
#    """Тестує роботу конфіг менеджера"""
#    try:
#        from book_editors_suite.core.config_manager import ModularConfigManager
#        
#        # Шлях до тестового конфігу
#        test_config_path = Path(__file__).parent / 'test_config.json'
#        
#        # Створюємо менеджер конфігурації
#        config_manager = ModularConfigManager(str(test_config_path))
#        
#        # Тестуємо завантаження для різних редакторів
#        editors = ['accent_editor', 'voice_tags_editor', 'sound_effects_editor', 'multispeaker_tts']
#        
#        for editor in editors:
#            try:
#                editor_config = config_manager.load_for_editor(editor)
#                print(f"✅ {editor}: завантажено {len(editor_config)} параметрів")
#            except Exception as e:
#                print(f"❌ {editor}: помилка - {e}")
#        
#        return config_manager
#        
#    except Exception as e:
#        print(f"❌ Помилка імпорту або роботи config_manager: {e}")
#        return None

#def main():
#    """Головна функція тестування"""
#    print("🚀 Запуск тестування системи редакторів книг...")
#    
#    # Налаштовуємо логування
#    setup_logging()
#    
#    # Тестуємо конфіг менеджер
#    config_manager = test_config_manager()
#    
#    if config_manager:
#        print("✅ Конфіг менеджер успішно протестовано")
#        
#        # Додаткові тести можна додати тут
#        print("\n📋 Доступні редактори:")
#        editors = config_manager.list_editors()
#        for editor in editors:
#            info = config_manager.get_editor_info(editor)
#            print(f"  • {editor}: {len(info['personal_params'])} особистих параметрів")
#    
#    print("\n🎯 Тестування завершено. Перевірте лог-файли для деталей.")

#if __name__ == "__main__":
#    main()