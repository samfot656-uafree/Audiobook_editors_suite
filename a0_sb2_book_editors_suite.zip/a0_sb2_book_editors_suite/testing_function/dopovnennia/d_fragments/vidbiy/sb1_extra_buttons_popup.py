# -*- coding: utf-8 -*-

#a0_sb2_book_editors_suite
#/storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite/ui/popups/extra_buttons_popup.py
"""
Попап з додатковими кнопками для редактора наголосів.
"""
import sys
import os
from pathlib import Path
from kivy.uix.popup import Popup
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.clock import Clock

# Додаємо шляхи для імпортів
sys.path.insert(0, '/storage/emulated/0/a0_sb2_book_editors_suite')
sys.path.insert(0, '/storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite')

# Project imports
from book_editors_suite.core.config_manager import get_config_manager
from book_editors_suite.core.tts_manager import TTSManager
from book_editors_suite.core.file_manager import FileManager
from book_editors_suite.core.text_processor import TextProcessor
from book_editors_suite.core.logging_manager import LoggingManager
from book_editors_suite.ui.popups.edit_word_popup import EditWordPopup
#from book_editors_suite.ui.popups.extra_buttons_popup import ExtraButtonsPopup
from book_editors_suite.ui.themes import ThemeManager
from book_editors_suite.utils.helpers import WORD_RE


class ExtraButtonsPopup(Popup):
    """Попап з додатковими функціями редактора."""

  #-------------------------------------------   
    def __init__(self, parent_app, **kwargs):
        super().__init__(**kwargs)        
        self.parent_app = parent_app
        self.config = parent_app.config
        self.title = "Додаткові функції"
        self.size_hint = (0.8, 0.6)
        self.auto_dismiss = True
                       
        bbtn_font_size=self.parent_app.config_manager.get_common_param('BBTN_FONT_SIZE', 38)
        text_widget_font_size=self.parent_app.config_manager.get_common_param('TEXT_WIDGET_FONT_SIZE', 56)
        bbtn_height=self.parent_app.config_manager.get_common_param('BBTN_HEIGHT', 120)
        
        self._build_interface()
        Clock.schedule_once(lambda *_: self.apply_theme_from_app(), 0)

#-------------------------------------------
    def _build_interface(self):
        """Побудова інтерфейсу попапу."""
        
        #dffffggg
        
        root = BoxLayout(orientation='vertical', spacing=8, padding=22)
        btn_row = BoxLayout(size_hint_y=None, height=self.bbtn_height, spacing=8)
        
        self.btn_open = Button(text="Відкрити", font_size=self.bbtn_font_size)
        self.btn_save_txt = Button(text="До txt", font_size=self.bbtn_font_size)
        self.btn_theme = Button(text="День-ніч", font_size=self.bbtn_font_size)
        self.btn_reset_bm = Button(text="Закладку 0", font_size=self.bbtn_font_size)
        self.btn_back = Button(text="Назад", font_size=self.bbtn_font_size)
        
        for b in (self.btn_open, self.btn_save_txt, self.btn_theme, self.btn_reset_bm, self.btn_back):
            btn_row.add_widget(b)
            
        root.add_widget(btn_row)
        root.add_widget(Label())
        self.content = root

#        # Прив'язки подій
#        self.btn_open.bind(on_press=lambda *_: (self.open_file_async(), self.dismiss()))
#        self.btn_save_txt.bind(on_press=lambda *_: (self.save_file(), self.dismiss()))
#        self.btn_theme.bind(on_press=lambda *_: (self.parent_app.toggle_theme(), self.dismiss()))
#        self.btn_reset_bm.bind(on_press=lambda *_: (self.reset_bookmark(), self.dismiss()))
#        self.btn_back.bind(on_press=lambda *_: self.dismiss())

#-------------------------------------------
#    def open_file_async(self):
#        """Відкриває файл асинхронно."""
#        self.parent_app.main_layout.open_file_async()

#-------------------------------------------
#    def save_file(self):
#        """Зберігає файл."""
#        self.parent_app.main_layout.save_file()

#-------------------------------------------
#    def reset_bookmark(self):
#        """Скидає закладку."""
#        self.parent_app.config_manager.reset_bookmark()
#        # Оновлюємо UI
#        if hasattr(self.parent_app, 'main_layout') and self.parent_app.main_layout.text_widget:
#            self.parent_app.main_layout.text_widget.scroll_y = 1.0
#            self.parent_app.main_layout._set_cursor_by_index(0)
#            
#        
#        Popup(title="Закладка скинута", 
#              content=Label(text="Відкриття з початку тексту буде активне."), 
#              size_hint=(0.9, 0.35)).open()
#======================        
#        #cggghh
#        layout = BoxLayout(orientation='vertical', spacing=10, padding=20)
#        
#        # Кнопки функцій
#        self.btn_save = Button(
#            text="Зберегти текст", 
#            size_hint_y=None, 
#            height=100,
#            font_size=32
#        )
#        self.btn_save.bind(on_press=self.save_text)
#        
#        self.btn_theme = Button(
#            text="Змінити тему", 
#            size_hint_y=None, 
#            height=100,
#            font_size=32
#        )
#        self.btn_theme.bind(on_press=self.toggle_theme)
#        
#        self.btn_bookmark = Button(
#            text="Зберегти закладку", 
#            size_hint_y=None, 
#            height=100,
#            font_size=32
#        )
#        self.btn_bookmark.bind(on_press=self.save_bookmark)
#        
#        self.btn_close = Button(
#            text="Закрити", 
#            size_hint_y=None, 
#            height=80,
#            font_size=28
#        )
#        self.btn_close.bind(on_press=self.dismiss)
#        
#        # Додаємо кнопки до layout
#        layout.add_widget(Label(text="Додаткові функції:", size_hint_y=None, height=50))
#        layout.add_widget(self.btn_save)
#        layout.add_widget(self.btn_theme)
#        layout.add_widget(self.btn_bookmark)
#        layout.add_widget(self.btn_close)
#        
#        self.content = layout

#-------------------------------------------
#    def apply_theme_from_app(self):
#        """Застосовує тему з головного додатку."""
#        try:
#            colors = self.parent_app.get_theme_colors()
#            
#            # Застосовуємо кольори до кнопок
#            buttons = [self.btn_save, self.btn_theme, self.btn_bookmark, self.btn_close]
#            for btn in buttons:
#                btn.background_normal = ""
#                btn.background_color = colors["button_bg"]
#                btn.color = colors["button_fg"]
#                
#            # Фон попапу
#            self.background = ""
#            self.background_color = colors["input_bg"]
#            
#        except Exception as e:
#            if hasattr(self.parent_app, 'logger'):
#                self.main_app.logger.error(f"❌ Помилка застосування теми в попапі: {e}")

#-------------------------------------------
#    def save_text(self, instance):
#        """Зберігає текст."""
#        try:
#            self.parent_app.save_full_text()
#            self.dismiss()
#        except Exception as e:
#            if hasattr(self.parent_app, 'logger'):
#                self.parent_app.logger.error(f"❌ Помилка збереження тексту: {e}")

#-------------------------------------------
#    def toggle_theme(self, instance):
#        """Перемикає тему."""
#        try:
#            self.parent_app.toggle_theme()
#            # Оновлюємо тему попапу
#            self.apply_theme_from_app()
#        except Exception as e:
#            if hasattr(self.parent_app, 'logger'):
#                self.main_app.logger.error(f"❌ Помилка перемикання теми: {e}")
#-------------------------------------------
#    def save_bookmark(self, instance):
#        """Зберігає закладку."""
#        try:
#            self.parent_app.save_bookmark()
#            if hasattr(self.parent_app, 'logger'):
#                self.parent_app.logger.info("🔖 Закладку збережено з попапу")
#            self.dismiss()
#        except Exception as e:
#            if hasattr(self.parent_app, 'logger'):
#                self.parent_app.logger.error(f"❌ Помилка збереження закладки: {e}")
#-------------------------------------------                