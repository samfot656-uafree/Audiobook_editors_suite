# У розділі common_params додаємо нові параметри для закладок
self.common_params = {
    'params': [
        'CONFIG_VERSION',
        'TEXT_WIDGET_FONT_SIZE',
        'BBTN_FONT_SIZE', 
        'BBTN_HEIGHT',
        'ACCENT_CHAR',
        'INPUT_TEXT_FILE',
        'OUTPUT_FOLDER',
        'TEMP_FOLDER',
        'VOICE_DICT',
        'PAUSE_DICT'
    ],
    'defaults': {
        'CONFIG_VERSION': '0_0_0_3',  # Оновлюємо версію
        # ... інші параметри без змін
    }
}

# Оновлюємо структуру закладки для всіх редакторів
# У кожному редакторі змінюємо структуру BOOKMARK:
'BOOKMARK': {
    'cursor': 0, 
    'scroll': 0.0,
    'paragraph_index': 0  # Додаємо нове поле
}