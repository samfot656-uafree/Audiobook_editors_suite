# -*- coding: utf-8 -*-
# /storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite/editors/accent_editor/main.py

"""
Головний модуль редактора наголосів з підтримкою проектів книг.
"""
#виправити gTTS, закладку, копіювання словника наголосів,  save_full_mp3
import sys
import os
from pathlib import Path

# Додаємо шляхи для імпортів
sys.path.insert(0, '/storage/emulated/0/a0_sb2_book_editors_suite')
sys.path.insert(0, '/storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite')

# Kivy imports
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.popup import Popup
from kivy.uix.label import Label
from kivy.core.window import Window
from kivy.clock import Clock

# Project imports
from book_editors_suite.core.config_manager import ModularConfigManager, get_config_manager
from book_editors_suite.core.tts_manager import TTSManager
from book_editors_suite.core.file_manager import FileManager
from book_editors_suite.core.text_processor import TextProcessor
from book_editors_suite.core.logging_manager import LoggingManager
from book_editors_suite.ui.popups.edit_word_popup import EditWordPopup
from book_editors_suite.ui.popups.extra_buttons_popup import ExtraButtonsPopup
from book_editors_suite.ui.themes import ThemeManager
from book_editors_suite.utils.helpers import WORD_RE


class AccentEditorApp(App):
    """Основний клас редактора наголосів з підтримкою проектів книг."""

#----__init__---------------------------------------        
    def __init__(self, book_project_name: str, input_text_file: str = None, **kwargs):
        super().__init__(**kwargs)
        
        self.book_project_name = book_project_name
        self.input_text_file = input_text_file
        self.app_name = "accent_editor"
        
        # Ініціалізація менеджерів
        self.config_manager = None
        self.config = {}
        self.accents = {}
        self.text_for_correction = []
        self.fixed_text = []
        self.current_idx = -1
        self.selected_word = None
        self.tts_manager = None
        self.file_manager = None
        self.text_processor = None
        self.logger = None
        self.theme_manager = None
        
        self.current_scroll_y = 0.0
        self.current_cursor_pos = 0
        self.current_paragraph_index = 0

#----build---------------------------------------
    def build(self):
        """Побудова інтерфейсу додатку."""
        # Ініціалізація менеджерів з підтримкою проекту
        self._init_managers()
        
        Window.softinput_mode = "below_target"
        return self._build_interface()

#----_init_managers---------------------------------------
    def _init_managers(self):
        """Ініціалізація всіх менеджерів з підтримкою проекту."""
        try:
            # Створюємо менеджер конфігурації для проекту
            self.config_manager = get_config_manager(
                book_project_name=self.book_project_name,
                input_text_file=self.input_text_file
            )
            
            # Завантажуємо конфіг для редактора
            self.config = self.config_manager.load_for_editor('accent_editor')
            
            # Отримуємо інформацію про проект
            project_info = self.config_manager.get_project_info()
            
            # Ініціалізація менеджерів
            self.logger = LoggingManager(
                log_dir=project_info['base_path'] + f"/{self.book_project_name}/temp_folder/logs",
                app_name="accent_editor"
            )
            self.file_manager = FileManager(self.config_manager, 'accent_editor', self.logger)
            self.text_processor = TextProcessor(self.logger)
            self.tts_manager = TTSManager()
            self.theme_manager = ThemeManager()
            
            # Завантаження даних
            self.accents = self.file_manager.load_accents()
            
            self.logger.info(f"\n_init_managers: 105 \nВсі менеджери ініціалізовані для проекту '{self.book_project_name}'")
            self.logger.info(f"_init_managers: 106 \nТекстовий файл: \n{self.config.get('INPUT_TEXT_FILE', 'Невідомо')}\n")
            
        except Exception as e:
            error_msg = f"\n_init_managers: 109 \nПомилка ініціалізації менеджерів: {e}"
            if self.logger:
                self.logger.error(error_msg)
            else:
                print(error_msg)
            self.show_popup("Помилка _init_managers: 114", f"Не вдалося ініціалізувати проект:\n{e}")

#----_build_interface--------------------------------
    def _build_interface(self):
        """Побудова інтерфейсу."""
        self.logger.info("\n_build_interface: 119 \nСтворення елементів інтерфейсу...\n")
        
        bbtn_font_size = self.config_manager.get_common_param('BBTN_FONT_SIZE', 38)
        text_widget_font_size = self.config_manager.get_common_param('TEXT_WIDGET_FONT_SIZE', 56)
        bbtn_height = self.config_manager.get_common_param('BBTN_HEIGHT', 120)
            
        root = BoxLayout(orientation='vertical', spacing=8, padding=22)

        # Верхній ряд кнопок
        top_row = BoxLayout(orientation='horizontal', size_hint_y=None, height=bbtn_height, spacing=8)
        self.btn_listen = Button(text="Слухати", font_size=bbtn_font_size)
        self.btn_pause = Button(text="Пауза", font_size=bbtn_font_size)
        self.btn_edit = Button(text="Правити", font_size=bbtn_font_size, disabled=True)
        self.btn_next = Button(text="Наступний", font_size=bbtn_font_size)
        self.btn_extra = Button(text="  . . .  ", font_size=bbtn_font_size)
        
        for btn in (self.btn_listen, self.btn_pause, self.btn_edit, self.btn_next, self.btn_extra):
            top_row.add_widget(btn)
            

        # Текстове поле
        self.text_input = TextInput(
            font_size=text_widget_font_size,
            multiline=True
        )
        self.text_input.bind(on_touch_down=self.on_text_touch)

        # Додавання віджетів та прив'язка подій
        root.add_widget(top_row)
        root.add_widget(self.text_input)
        self._bind_events()

        # Автоматичні дії
        Clock.schedule_once(lambda *_: self.open_and_prepare_text(), 0.1)
        Clock.schedule_once(lambda *_: self.apply_theme(), 0)
        Clock.schedule_once(lambda *_: self.restore_bookmark(), 0.2)

        self.logger.info("\n_build_interface: 156  \nІнтерфейс успішно побудовано\n")
        return root

#----_bind_events-------------------------------------
    def _bind_events(self):
        """Прив'язка подій до кнопок."""
        self.btn_listen.bind(on_press=lambda *_: self.listen_current_paragraph())
        self.btn_pause.bind(on_press=lambda *_: self.stop_tts())
        self.btn_edit.bind(on_press=self.open_edit_popup)
        self.btn_next.bind(on_press=lambda *_: self.go_next_paragraph())
        self.btn_extra.bind(on_press=lambda *_: ExtraButtonsPopup(main_app=self, editor_name=self.app_name).open())

    # === Основні методи ===

#----move_bookmark------------------------------
def move_bookmark(self):
    """Оновлює позицію закладки у властивостях класу без запису у конфіг файл. Викликається лише при переході до наступного абзацу."""
    try:
        if self.text_input:
            # Оновлюємо ВСІ три параметри закладки
            self.current_cursor_pos = self.text_input.cursor_index()
            self.current_scroll_y = self.text_input.scroll_y
            # current_paragraph_index вже оновлено в go_next_paragraph, але явно вказуємо його для ясності
            self.logger.debug(f"move_bookmark: Оновлено закладку: абзац {self.current_paragraph_index}, позиція {self.current_cursor_pos}, прокрутка {self.current_scroll_y}")
    except Exception as e:
        self.logger.error(f"move_bookmark: Помилка оновлення закладки: {e}")

#----save_bookmark------------------------------

def save_bookmark(self):
    """Зберігає поточну позицію у конфіг проекту. Викликається при збереженні тексту."""
    try:
        if hasattr(self, 'config_manager'):
            self.config_manager.update_bookmark(
                'accent_editor', 
                self.current_cursor_pos, 
                self.current_scroll_y,
                self.current_paragraph_index
            )
            self.logger.debug(f"save_bookmark: Закладку збережено у конфіг: абзац {self.current_paragraph_index}")
    except Exception as e:
        self.logger.error(f"save_bookmark: Помилка збереження закладки: {e}")

#----restore_bookmark--------------------------

def restore_bookmark(self):
    """Відновлює позицію з конфігу проекту. Викликається при відкритті тексту."""
    try:
        if hasattr(self, 'config_manager'):
            bookmark = self.config_manager.get_bookmark('accent_editor')
            if bookmark:
                self.current_scroll_y = bookmark.get('scroll_y', 0.0)
                self.current_cursor_pos = bookmark.get('cursor_pos', 0)
                self.current_paragraph_index = bookmark.get('paragraph_index', 0)
                self.logger.debug(f"restore_bookmark: Відновлено закладку з конфігу: абзац {self.current_paragraph_index}")
    except Exception as e:
        self.logger.error(f"restore_bookmark: Помилка відновлення закладки: {e}")
        
#----open_and_prepare_text-------------------
    def open_and_prepare_text(self):
    """Завантажує текст, додає наголоси, розбиває на абзаци та відновлює позицію закладки."""
    try:
        # Завантаження тексту
        raw_text = self.file_manager.load_input_text()
        if raw_text is None:
            self.logger.warning("open_and_prepare_text: Текст не знайдено.")
            return

        # Додаємо наголоси та розбиваємо на абзаци
        accented_text = self.text_processor.add_accents_to_text(raw_text, self.accents)
        paragraphs = accented_text.split("\n")
        
        # Зберігаємо всі абзаци
        self.text_for_correction = paragraphs
        self.fixed_text = []

        # Відновлюємо закладку
        self.restore_bookmark()
        target_index = self.current_paragraph_index

        # Імітуємо переходи до закладки
        for i in range(target_index):
            # Просто додаємо абзаци до закладки в fixed_text без змін
            self.fixed_text.append(self.text_for_correction[i])

        # Встановлюємо поточний абзац (той, що позначений закладкою)
        if target_index < len(self.text_for_correction):
            self.text_input.text = self.text_for_correction[target_index]
            self.current_paragraph_index = target_index
        else:
            self.text_input.text = ""
            self.current_paragraph_index = len(self.text_for_correction)

        # Оновлюємо кнопку
        total_paragraphs = len(self.text_for_correction)
        self.btn_extra.text = f"   . . .   \n{self.current_paragraph_index+1}/{total_paragraphs}"

        self.logger.info(f"open_and_prepare_text: Відкрито абзац {self.current_paragraph_index+1}/{total_paragraphs} з закладки")
        self.clear_selection_state()

    except Exception as e:
        self.logger.error(f"open_and_prepare_text: Помилка підготовки тексту: {e}")
        self.show_popup("Помилка", f"Не вдалося підготувати текст:\n{e}")


#----go_next_paragraph--------------------------
    def go_next_paragraph(self):
    """Переходить до наступного абзацу, зберігаючи поточний у fixed_text."""
    self.stop_tts()

    # Зберігаємо поточний абзац в fixed_text
    current_text = self.text_input.text
    if self.current_paragraph_index < len(self.text_for_correction):
        # Замінюємо оригінальний текст на відредагований
        self.fixed_text.append(current_text)
        
        # Переходимо до наступного абзацу
        self.current_paragraph_index += 1
        
        if self.current_paragraph_index < len(self.text_for_correction):
            self.text_input.text = self.text_for_correction[self.current_paragraph_index]
            self.logger.info(f"go_next_paragraph: Перехід до абзацу {self.current_paragraph_index+1}/{len(self.text_for_correction)}")
        else:
            self.text_input.text = ""
            self.logger.info("go_next_paragraph: Досягнуто кінця тексту")
            self.show_popup("Кінець", "Досягнуто кінця тексту.")
    else:
        self.logger.warning("go_next_paragraph: Немає більше абзаців")

    # Оновлюємо кнопку та закладку
    self.btn_extra.text = f"   . . .   \n{self.current_paragraph_index+1}/{len(self.text_for_correction)}"
    self.move_bookmark()
    self.clear_selection_state()

#----listen_current_paragraph----------------
    def listen_current_paragraph(self):
        """Відтворює поточний абзац через TTS."""
        text = self.text_input.text.strip()
        if text:
            self.logger.info(f"\nlisten_current_paragraph: 307 \nВідтворення TTS: {len(text)} символів\n")
            self.tts_manager.safe_tts_speak(text)
        else:
            self.logger.warning("\nlisten_current_paragraph: 310 \nСпроба відтворення порожнього тексту\n")

#----stop_tts-----------------------------
    def stop_tts(self):
        """Зупиняє TTS відтворення."""
        if self.tts_manager:
            self.tts_manager.stop_tts()
            self.logger.info("\nstop_tts: 317 \nTTS зупинено\n")

    # === Робота з виділенням слів ===

#----on_text_touch-----------------------------    
    def on_text_touch(self, instance, touch):
        """Обробка торкання текстового поля для виділення слова."""
        if not instance.collide_point(*touch.pos):
            return False
        Clock.schedule_once(lambda *_: self.detect_word_at_cursor(), 0.01)
        return False

#----detect_word_at_cursor----------------
    def detect_word_at_cursor(self):
        """Визначає слово під курсором."""
        try:
            cursor_idx = self.text_input.cursor_index()
        except Exception as e:
            self.logger.debug(f"\ndetect_word_at_cursor: 335 \nПомилка отримання позиції курсору: \n{e}\n")
            self.clear_selection_state()
            return

        text = self.text_input.text
        if not text:
            self.clear_selection_state()
            return

        # Знаходимо межі слова
        start = cursor_idx
        while start > 0 and self.is_word_char(text[start - 1]):
            start -= 1

        end = cursor_idx
        while end < len(text) and self.is_word_char(text[end]):
            end += 1

        word = text[start:end]
        if WORD_RE.fullmatch(word):
            self.selected_word = word
            self.btn_edit.disabled = False
            self.logger.debug(f"\ndetect_word_at_cursor: 357 \nВиділено слово: '{word}'\n")
        else:
            self.clear_selection_state()

#----is_word_char-----------------------------
    def is_word_char(self, char: str) -> bool:
        """Перевіряє, чи символ є частиною слова."""
        return char.isalpha() or char == '\u0301' or char == "'"

#----save_accents-----------------------------
    def save_accents(self):
        """Зберігає словник наголосів у проект."""
        try:
            success = self.file_manager.save_accents(self.accents)
            if success:
                self.logger.info("\nsave_accents: 372 \nСловник наголосів збережено в проект\n")
            else:
                self.logger.error("\nsave_accents: 374 \nПомилка збереження словника наголосів\n")
        except Exception as e:
            self.logger.error(f"\nsave_accents: 376 \nПомилка збереження словника: \n{e}\n")

#----clear_selection_state----------------------
    def clear_selection_state(self):
        """Очищає стан виділення."""
        if self.selected_word:
            self.logger.debug("\nclear_selection_state: 382 \nОчищено виділення слова\n")
        self.selected_word = None
        self.btn_edit.disabled = True

#----open_edit_popup-----------------------------
    def open_edit_popup(self, *_):
        """Відкриває попап для редагування слова."""
        if self.selected_word:
            self.logger.info(f"\nopen_edit_popup: 390 \nВідкриття попапу редагування слова: '{self.selected_word}\n'")
            self.stop_tts()
            EditWordPopup(self, self.selected_word, self.app_name).open()

#----replace_word_in_current_paragraph-
    def replace_word_in_current_paragraph(self, old_word: str, new_word: str):
        """Замінює слово в поточному абзаці."""
        if self.current_idx < 0:
            return
            
        current_text = self.text_input.text
        replaced_text = current_text.replace(old_word, new_word, 1)
        self.text_input.text = replaced_text
        
        self.logger.info(f"\nreplace_word_in_current_paragraph: 404 \nЗамінено слово: '{old_word}' -> '{new_word}'\n")

    # === Збереження даних ===

#----save_full_text---------

def save_full_text(self):
    """Зберігає весь текст у файл та оновлює закладку в конфігу."""
    self.stop_tts()
    
    # Збираємо повний текст
    content = self.build_full_text()
    
    # Зберігаємо текст у файл
    success = self.file_manager.save_output_text(content)
    
    # Зберігаємо закладку в конфіг
    self.save_bookmark()
    
    if success:
        self.logger.info("save_full_text: Текст успішно збережено")
    else:
        self.logger.error("save_full_text: Помилка збереження тексту")

#----build_full_text---------

def build_full_text(self) -> str:
    """Побудова повного тексту: fixed_text + поточний + решта text_for_correction."""
    # Збираємо всі частини тексту
    full_parts = []
    
    # Додаємо вже відредаговані абзаци
    full_parts.extend(self.fixed_text)
    
    # Додаємо поточний абзац
    if self.current_paragraph_index < len(self.text_for_correction):
        full_parts.append(self.text_input.text)
        
        # Додаємо решту невідредагованих абзаців
        if self.current_paragraph_index + 1 < len(self.text_for_correction):
            remaining_paragraphs = self.text_for_correction[self.current_paragraph_index + 1:]
            full_parts.extend(remaining_paragraphs)
    
    # З'єднуємо всі абзаци
    full_text = "\n".join(full_parts)
    
    self.logger.debug(f"build_full_text: Зібрано повний текст: {len(full_parts)} абзаців")
    return full_text

#-------------------------------------------------
def save_full_mp3(self):
    """Зберігає весь текст у MP3 через gTTS онлайн."""
    self.stop_tts()
    
    # Отримуємо повний текст
    content = self.build_full_text().strip()
    if not content:
        self.show_popup("Помилка", "Текст порожній, немає що конвертувати.")
        return

    try:
        # Отримуємо інформацію про проект з config_manager
        project_info = self.config_manager.get_project_info()
        project_name = project_info['project_name']
        project_path = project_info['base_path'] + f"/{project_name}"
        
        # Створюємо шлях для MP3 файлу
        mp3_folder = f"{project_path}/outputs/output_mp3"
        os.makedirs(mp3_folder, exist_ok=True)
        
        out_f_path = f"{mp3_folder}/{project_name}.mp3"
        
        # Конвертуємо текст в MP3 за допомогою gTTS
        from gtts import gTTS
        tts = gTTS(text=content, lang="uk")
        tts.save(out_f_path)
        
        # Показуємо повідомлення про успішне збереження
        popup_content = Label(text=f"MP3 збережено:\n{out_f_path}")
        popup = Popup(title="MP3 збережено", content=popup_content, size_hint=(0.9, 0.35))
        popup.open()
        
        self.logger.info(f"save_full_mp3: MP3 успішно збережено: {out_f_path}")
        
    except ImportError:
        error_msg = "Бібліотека gTTS не встановлена. Встановіть її командою: pip install gtts"
        self.logger.error(f"save_full_mp3: {error_msg}")
        self.show_popup("Помилка gTTS", error_msg)
    except Exception as e:
        error_msg = f"Помилка конвертації в MP3: {str(e)}"
        self.logger.error(f"save_full_mp3: {error_msg}")
        self.show_popup("Помилка gTTS", error_msg)

# Додаємо метод до класу
AccentEditorApp.save_full_mp3 = save_full_mp3


AccentEditorApp.save_full_text = save_full_text


    # === Тема інтерфейсу ===

#----get_theme_colors---------        
    def get_theme_colors(self):
        """Повертає кольори теми (для сумісності з попапами)."""
        return self.theme_manager.get_colors()

#----apply_theme---------    
    def apply_theme(self):
        """Застосовує поточну тему до інтерфейсу."""
        try:
            # Створюємо словник з віджетами для теми
            widgets_dict = {
                'buttons': [self.btn_listen, self.btn_pause, self.btn_edit, self.btn_next, self.btn_extra],
                'text_inputs': [self.text_input],
                'window': Window
            }
            
            # Використовуємо ThemeManager для застосування теми
            self.theme_manager.apply_theme_to_widgets(widgets_dict)
            self.logger.debug("\napply_theme: 482 \nТему застосовано\n")
        except Exception as e:
            self.logger.error(f"\napply_theme: 484 \nПомилка застосування теми: \n{e}\n")

#----toggle_theme---------
    def toggle_theme(self):
        """Перемикає тему день/ніч."""
        self.stop_tts()
        self.theme_manager.toggle_theme()
        self.apply_theme()
        self.logger.info(f"\ntoggle_theme: 492 \nПереключено тему: {self.theme_manager.current_theme}\n")

    # === Утиліти ===

#----show_popup---------
    def show_popup(self, title: str, message: str):
        """Показує спливаюче повідомлення."""
        popup = Popup(
            title=title,
            content=Label(text=message),
            size_hint=(0.8, 0.4)
        )
        popup.open()
        self.logger.debug(f"\nshow_popup: 505 \nПоказано попап: {title}: {message}\n")

#----on_stop---------
    def on_stop(self):
        """Викликається при закритті додатку - зберігає закладку, зупиняє ттс."""
        self.save_bookmark()
        self.stop_tts()
        self.logger.info("\non_stop: 512 \nРедактор наголосів закрито\n")
        self.logger.info('/=\+' * 10)

#===запуск=======
if __name__ == "__main__":
    # Новий спосіб запуску з підтримкою проектів
    input_text_file = "/storage/emulated/0/Documents/Inp_txt/Чекаючий_1_1.txt"
    book_project_name = "Чекаючий_1_1"
    
    app = AccentEditorApp(
        book_project_name=book_project_name,
        input_text_file=input_text_file
    )
    app.run()