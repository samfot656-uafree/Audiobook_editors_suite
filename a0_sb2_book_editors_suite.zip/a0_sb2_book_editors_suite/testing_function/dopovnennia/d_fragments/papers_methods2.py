def move_bookmark(self):
    """Оновлює позицію закладки у властивостях класу без запису у конфіг файл. Викликається лише при переході до наступного абзацу."""
    try:
        if self.text_input:
            # Оновлюємо ВСІ три параметри закладки
            self.current_cursor_pos = self.text_input.cursor_index()
            self.current_scroll_y = self.text_input.scroll_y
            # current_paragraph_index вже оновлено в go_next_paragraph, але явно вказуємо його для ясності
            self.logger.debug(f"move_bookmark: Оновлено закладку: абзац {self.current_paragraph_index}, позиція {self.current_cursor_pos}, прокрутка {self.current_scroll_y}")
    except Exception as e:
        self.logger.error(f"move_bookmark: Помилка оновлення закладки: {e}")

def save_bookmark(self):
    """Зберігає поточну позицію у конфіг проекту. Викликається при збереженні тексту."""
    try:
        if hasattr(self, 'config_manager'):
            self.config_manager.update_bookmark(
                'accent_editor', 
                self.current_cursor_pos, 
                self.current_scroll_y,
                self.current_paragraph_index
            )
            self.logger.debug(f"save_bookmark: Закладку збережено у конфіг: абзац {self.current_paragraph_index}")
    except Exception as e:
        self.logger.error(f"save_bookmark: Помилка збереження закладки: {e}")

def restore_bookmark(self):
    """Відновлює позицію з конфігу проекту. Викликається при відкритті тексту."""
    try:
        if hasattr(self, 'config_manager'):
            bookmark = self.config_manager.get_bookmark('accent_editor')
            if bookmark:
                self.current_scroll_y = bookmark.get('scroll_y', 0.0)
                self.current_cursor_pos = bookmark.get('cursor_pos', 0)
                self.current_paragraph_index = bookmark.get('paragraph_index', 0)
                self.logger.debug(f"restore_bookmark: Відновлено закладку з конфігу: абзац {self.current_paragraph_index}")
    except Exception as e:
        self.logger.error(f"restore_bookmark: Помилка відновлення закладки: {e}")
        
 def go_next_paragraph(self):
    """Переходить до наступного абзацу, зберігаючи поточний у fixed_text."""
    self.stop_tts()

    # Зберігаємо поточний абзац в fixed_text
    current_text = self.text_input.text
    if self.current_paragraph_index < len(self.text_for_correction):
        self.fixed_text.append(current_text)
        
        # Переходимо до наступного абзацу
        self.current_paragraph_index += 1
        
        if self.current_paragraph_index < len(self.text_for_correction):
            self.text_input.text = self.text_for_correction[self.current_paragraph_index]
            self.logger.info(f"go_next_paragraph: Перехід до абзацу {self.current_paragraph_index+1}/{len(self.text_for_correction)}")
        else:
            self.text_input.text = ""
            self.logger.info("go_next_paragraph: Досягнуто кінця тексту")
            self.show_popup("Кінець", "Досягнуто кінця тексту.")
    else:
        self.logger.warning("go_next_paragraph: Немає більше абзаців")

    # Оновлюємо кнопку
    self.btn_extra.text = f"   . . .   \n{self.current_paragraph_index+1}/{len(self.text_for_correction)}"
    
    # Оновлюємо закладку у властивостях класу (без запису в конфіг)
    self.move_bookmark()
    
    self.clear_selection_state()       