#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Редактор голосів та пауз - просто і зрозуміло
"""

import sys
from smart_config import open_book, get_book

def main():
    book_name = sys.argv[1] if len(sys.argv) > 1 else "Чекаючий_1_1_Шлях_до_заснування"
    book = open_book(book_name)
    config = book.get_editor_config("voice_tags_editor")
    
    print(f"🎙️ Редактор голосів для: {book.config['book_name']}")
    print(f"📍 Закладка: {config['bookmark']}")
    
    # Робота з текстом...
    with open(config['text_file'], 'r', encoding='utf-8') as f:
        text = f.read()
    
    print(f"📝 Текст готовий для розмітки голосів: {len(text)} символів")
    
    input("\n🔧 Додавайте теги голосів... (Enter для симуляції)")
    
    # Зберігаємо прогрес
    book.update_bookmark("voice_tags_editor", cursor=2800, paragraph=75)
    
    if input("\nЗавершити роботу з голосами? (y/n): ").lower() == 'y':
        book.next_editor()
        print("🎉 Переходимо до редактора звуків!")

if __name__ == '__main__':
    main()