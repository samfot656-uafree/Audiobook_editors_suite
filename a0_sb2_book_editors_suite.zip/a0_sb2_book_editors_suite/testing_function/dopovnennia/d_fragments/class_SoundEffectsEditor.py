class SoundEffectsEditor(BaseEditor):
    """Редактор звукових ефектів"""
    
    def __init__(self, book_project_name: str, input_text_file: str = None, **kwargs):
        super().__init__(book_project_name, input_text_file, editor_name="sound_effects_editor")
        
        # Ініціалізація менеджера звукових ефектів
        sound_effects_list_path = self.config.get('SOUNDS_EFFECTS_LIST', '')
        self.sound_effects_manager = SoundEffectsManager(sound_effects_list_path, self.logger)
        
        # Додаткові властивості для звукових ефектів
        self.sound_dict = self.config.get('SOUND_DICT', {})
        self.sound_effects_input_folder = self.config.get('SOUNDS_EFFECTS_INPUT_FOLDER', '')
    
    def add_sound_effect_to_text(self, tag: str, description: str, file_path: str) -> bool:
        """Додати звуковий ефект до тексту та списку"""
        try:
            # Додаємо тег до тексту в позицію курсору
            if hasattr(self, 'text_widget') and self.text_widget:
                cursor_pos = self.text_widget.cursor_index()
                sound_tag = f"#{tag}: "
                self.text_widget.text = (self.text_widget.text[:cursor_pos] + 
                                       sound_tag + 
                                       self.text_widget.text[cursor_pos:])
                # Переміщаємо курсор після тегу
                self.text_widget.cursor = (cursor_pos + len(sound_tag), 0)
            
            # Додаємо до списку звукових ефектів
            success = self.sound_effects_manager.add_or_update_sound_effect(
                tag, description, file_path
            )
            
            if success:
                self.logger.info(f"Додано звуковий ефект: {tag} - {description}")
            
            return success
            
        except Exception as e:
            self.logger.error(f"Помилка додавання звукового ефекту: {e}")
            return False
    
    def load_sound_effects(self) -> Dict[str, Dict[str, str]]:
        """Завантажити список звукових ефектів"""
        return self.sound_effects_manager.read_sound_effects_list()
    
    def delete_sound_effect(self, tag: str) -> bool:
        """Видалити звуковий ефект"""
        return self.sound_effects_manager.delete_sound_effect(tag)
    
    def sort_sound_effects(self) -> bool:
        """Відсортувати звукові ефекти"""
        return self.sound_effects_manager.sort_sound_effects_list()
    
    def get_next_available_tag(self) -> str:
        """Отримати наступний доступний тег"""
        existing_tags = self.sound_effects_manager.get_all_tags()
        used_numbers = []
        
        for tag in existing_tags:
            match = re.match(r'S(\d+)', tag.upper())
            if match:
                used_numbers.append(int(match.group(1)))
        
        next_number = 1
        while next_number in used_numbers:
            next_number += 1
        
        return f"S{next_number}"