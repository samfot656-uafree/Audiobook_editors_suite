def on_bookmark_start(self, *_):
    """Встановлює закладку на початок тексту."""
    try:
        # Викликаємо метод конфіг менеджера для оновлення закладки з усіма параметрами
        self.main_app.config_manager.update_bookmark(
            editor_name=self.editor_name,
            cursor_pos=0,
            scroll_y=0.0,
            paragraph_index=0
        )
        
        # Оновлюємо поточні значення в головному додатку
        self.main_app.current_cursor_pos = 0
        self.main_app.current_scroll_y = 0.0
        self.main_app.current_paragraph_index = 0
        self.main_app.current_idx = 0
        
        # Встановлюємо текст першого абзацу
        if self.main_app.text_for_correction:
            self.main_app.text_input.text = self.main_app.text_for_correction[0]
            self.main_app.text_input.cursor = (0, 0)
            self.main_app.text_input.scroll_y = 0.0
        
        if hasattr(self.main_app, 'logger'):
            self.main_app.logger.info(f"🔖 Закладку встановлено на початок тексту для {self.editor_name}")
        
        # Повідомлення про успішне встановлення закладки
        Popup(
            title="Закладка", 
            content=Label(text="Закладку встановлено на початок тексту"), 
            size_hint=(0.7, 0.3)
        ).open()
            
    except Exception as e:
        if hasattr(self.main_app, 'logger'):
            self.main_app.logger.error(f"❌ Помилка встановлення закладки для {self.editor_name}: {e}")
        Popup(
            title="Помилка закладки", 
            content=Label(text=f"Не вдалося встановити закладку:\n{e}"), 
            size_hint=(0.8, 0.3)
        ).open()