#z
# У accent_editor
#popup = ExtraButtonsPopup(main_app=self, editor_name='accent_editor')

# У voice_tags_editor  
#popup = ExtraButtonsPopup(main_app=self, editor_name='voice_tags_editor')

# У sound_effects_editor
#popup = ExtraButtonsPopup(main_app=self, editor_name='sound_effects_editor')

# У multispeaker_tts
#popup = ExtraButtonsPopup(main_app=self, editor_name='multispeaker_tts')
#z
