#zakl do editors/init.py


from utils.bookmark_utils import create_bookmark, get_bookmark, init_bookmarks

__all__ = ['create_bookmark', 'get_bookmark', 'init_bookmarks']