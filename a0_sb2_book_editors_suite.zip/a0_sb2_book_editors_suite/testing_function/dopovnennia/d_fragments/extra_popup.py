        from kivy.uix.popup import Popup
        from kivy.uix.label import Label




# ----------------- Попап додаткових кнопок -----------------
class ExtraButtonsPopup(Popup):
    """Вікно для рідко використовуваних кнопок"""

#-------------------------------------------------        
    def __init__(self, main_app, **kwargs):
        super().__init__(**kwargs)
        self.main_app = main_app
        self.title = "Додаткові кнопки"
        self.size_hint = (0.95, 0.8)

        root = BoxLayout(orientation='vertical', spacing=8, padding=8)

        # Ряд кнопок зверху
        btn_row = BoxLayout(size_hint_y=None, height=150, spacing=8)
        
        self.btn_save_txt = Button(text="До txt", font_size=42)
        self.btn_save_mp3 = Button(text="До mp3", font_size=42)
        self.btn_theme    = Button(text="День-ніч", font_size=42)
        self.btn_sort_dict= Button(text="Сортуй", font_size=42)
        self.btn_reset_bm= Button(text="Закладку 0", font_size=42)

                
        
        self.btn_back     = Button(text="Назад", font_size=42)
        for b in (self.btn_save_txt, self.btn_save_mp3, self.btn_theme, self.btn_sort_dict, btn_reset_bm, self.btn_back):
            btn_row.add_widget(b)
        root.add_widget(btn_row)
# кнопки зверху
        root.add_widget(Label())  
# порожній простір під кнопками
        self.content = root

        # Прив'язка кнопок
        self.btn_save_txt.bind(on_press=self.on_save_txt)
        self.btn_save_mp3.bind(on_press=self.on_save_mp3)
        self.btn_theme.bind(on_press=self.on_toggle_theme)
        self.btn_sort_dict.bind(on_press=self.on_sort_dict)       
         self.btn_reset_bm.bind(on_press=lambda *_: (self.reset_bookmark(), self.dismiss()))  
        self.btn_back.bind(on_press=lambda *_: self.dismiss())

        Clock.schedule_once(lambda *_: self.apply_theme_from_app(), 0)

#-------------------------------------------------
    def apply_theme_from_app(self):
        colors = self.main_app.get_theme_colors()
        for b in (self.btn_save_txt, self.btn_save_mp3, self.btn_theme, self.btn_sort_dict, self.btn_back):
            b.background_normal = ""
            b.background_color = colors["button_bg"]
            b.color = colors["button_fg"]

#-------------------------------------------------
    def on_save_txt(self, *_):
        self.main_app.save_full_text()
        self.dismiss()

#-------------------------------------------------
    def on_save_mp3(self, *_):
        self.main_app.save_full_mp3()
        self.dismiss()

#-------------------------------------------------
    def on_toggle_theme(self, *_):
        self.main_app.toggle_theme()
        self.dismiss()

#-------------------------------------------------
    def on_sort_dict(self, *_):
        """Сортування словника за ключами"""
        self.main_app.accents = dict(sorted(self.main_app.accents.items()))
        self.main_app.save_accents()
        Popup(title="Словник відсортовано", content=Label(text="Словник успішно відсортовано"),
              size_hint=(0.8,0.3)).open()



    def reset_bookmark(self):
        """Скидає закладку."""
        self.main_app.config_manager.reset_bookmark()
        # Оновлюємо UI
        if hasattr(self.main_app, 'main_layout') and self.main_app.main_layout.text_widget:
            self.main_app.main_layout.text_widget.scroll_y = 1.0
            self.main_app.main_layout._set_cursor_by_index(0)
            

        Popup(title="Закладка скинута", 
              content=Label(text="Відкриття з початку тексту буде активне."), 
              size_hint=(0.9, 0.35)).open()
