python create_book.py "Назва_книги" "/шлях/до/тексту.txt"

python accent_editor.py "Назва_книги"

python voice_editor.py "Назва_книги" 

python list_books.py