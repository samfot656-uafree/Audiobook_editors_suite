def open_and_prepare_text(self):
    """Завантажує текст, додає наголоси, розбиває на абзаци та відновлює позицію закладки."""
    try:
        # Завантаження тексту
        raw_text = self.file_manager.load_input_text()
        if raw_text is None:
            self.logger.warning("open_and_prepare_text: Текст не знайдено.")
            return

        # Додаємо наголоси та розбиваємо на абзаци
        accented_text = self.text_processor.add_accents_to_text(raw_text, self.accents)
        paragraphs = accented_text.split("\n")
        
        # Зберігаємо всі абзаци
        self.text_for_correction = paragraphs
        self.fixed_text = []

        # Відновлюємо закладку
        self.restore_bookmark()
        target_index = self.current_paragraph_index

        # Імітуємо переходи до закладки - додаємо всі абзаци ДО закладки в fixed_text
        for i in range(target_index):
            self.fixed_text.append(self.text_for_correction[i])

        # Пропускаємо порожні абзаци, починаючи з закладки
        while (target_index < len(paragraphs) and 
               not paragraphs[target_index].strip()):
            self.fixed_text.append("")
            target_index += 1

        # Встановлюємо поточний абзац (перший непорожній після закладки)
        if target_index < len(paragraphs):
            self.text_input.text = paragraphs[target_index]
            self.current_paragraph_index = target_index
            self.logger.info(f"open_and_prepare_text: Відкрито абзац {target_index+1}/{len(paragraphs)} з закладки")
        else:
            self.text_input.text = ""
            self.current_paragraph_index = len(paragraphs)
            self.logger.warning("open_and_prepare_text: Текст порожній або закладка вказує на кінець")
            self.show_popup("Готово", "Текст порожній або закладка вказує на кінець.")

        # Оновлюємо кнопку
        total_paragraphs = len(paragraphs)
        self.btn_extra.text = f"   . . .   \n{self.current_paragraph_index+1}/{total_paragraphs}"

        self.clear_selection_state()

    except Exception as e:
        self.logger.error(f"open_and_prepare_text: Помилка підготовки тексту: {e}")
        self.show_popup("Помилка", f"Не вдалося підготувати текст:\n{e}")

def go_next_paragraph(self):
    """Переходить до наступного абзацу, зберігаючи поточний у fixed_text."""
    self.stop_tts()

    # Зберігаємо поточний абзац в fixed_text
    current_text = self.text_input.text
    if self.current_paragraph_index < len(self.text_for_correction):
        self.fixed_text.append(current_text)
        
        # Переходимо до наступного абзацу
        self.current_paragraph_index += 1
        
        # Пропускаємо порожні абзаци
        skipped_count = 0
        while (self.current_paragraph_index < len(self.text_for_correction) and 
               not self.text_for_correction[self.current_paragraph_index].strip()):
            self.fixed_text.append("")
            self.current_paragraph_index += 1
            skipped_count += 1

        # Встановлюємо наступний непорожній абзац
        if self.current_paragraph_index < len(self.text_for_correction):
            self.text_input.text = self.text_for_correction[self.current_paragraph_index]
            self.logger.info(f"go_next_paragraph: Перехід до абзацу {self.current_paragraph_index+1}/{len(self.text_for_correction)}")
            if skipped_count > 0:
                self.logger.debug(f"go_next_paragraph: Пропущено {skipped_count} порожніх абзаців")
        else:
            self.text_input.text = ""
            self.logger.info("go_next_paragraph: Досягнуто кінця тексту")
            self.show_popup("Кінець", "Досягнуто кінця тексту.")
    else:
        self.logger.warning("go_next_paragraph: Немає більше абзаців")

    # Оновлюємо кнопку та закладку
    self.btn_extra.text = f"   . . .   \n{self.current_paragraph_index+1}/{len(self.text_for_correction)}"
    self.move_bookmark()
    self.clear_selection_state()