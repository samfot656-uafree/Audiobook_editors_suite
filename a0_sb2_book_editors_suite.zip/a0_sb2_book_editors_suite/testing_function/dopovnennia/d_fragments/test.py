# Простий тест
def test_editor():
    editor = VoiceTagsEditor(
        book_project_name="Тестовий_проект",
        input_text_file="/шлях/до/файлу.txt"
    )
    
    # Перевірка:
    print("Конфіг завантажено:", bool(editor.config))
    print("Файл з конфігу:", editor.INPUT_FILE)
    print("Закладка:", editor.config_manager.get_bookmark('voice_tags_editor'))