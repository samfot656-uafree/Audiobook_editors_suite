##оновлені частини коду


class AccentEditorApp(App):
    """Основний клас редактора наголосів."""
    
    def __init__(self, config_path="config_json", **kwargs):
        super().__init__(**kwargs)
        # ... інший код ініціалізації ...
        
        # Нові атрибути для відстеження позиції
        self.current_scroll_y = 0.0
        self.current_cursor_pos = 0
        self.current_paragraph_index = 0

    def save_bookmark(self):
        """Зберігає поточну позицію у конфіг з новими полями."""
        if self.text_input and hasattr(self, 'config_manager'):
            try:
                self.current_cursor_pos = self.text_input.cursor_index()
                self.current_scroll_y = self.text_input.scroll_y
                self.current_paragraph_index = self.current_idx
                
                self.config_manager.update_bookmark(
                    'accent_editor', 
                    self.current_cursor_pos, 
                    self.current_scroll_y,
                    self.current_paragraph_index
                )
                self.logger.debug(f"\nsave_bookmark: 🔖 Закладка збережена: абзац {self.current_paragraph_index}, позиція {self.current_cursor_pos}\n")
            except Exception as e:
                self.logger.error(f"\nsave_bookmark: Помилка збереження закладки: {e}\n")

    def restore_bookmark(self):
        """Відновлює позицію з конфігу з новими полями."""
        try:
            if hasattr(self, 'config_manager'):
                bookmark = self.config_manager.get_bookmark('accent_editor')
                if self.text_input and bookmark:
                    # Встановлюємо позицію курсора і прокрутки
                    self.text_input.cursor = (bookmark['cursor_pos'], 0)
                    self.text_input.scroll_y = bookmark['scroll_y']
                    
                    # Встановлюємо індекс абзацу
                    self.current_paragraph_index = bookmark.get('paragraph_index', 0)
                    
                    self.logger.info(f"\nrestore_bookmark: 🔖 Закладку відновлено: абзац {self.current_paragraph_index}, позиція {bookmark['cursor_pos']}\n")
        except Exception as e:
            self.logger.error(f"\nrestore_bookmark: Помилка відновлення закладки: {e}\n")

    def open_and_prepare_text(self):
        """Завантажує текст та автоматично додає наголоси, відновлює позицію."""
        try:
            # Завантаження тексту через FileManager
            raw_text = self.file_manager.load_input_text()
            if raw_text is None:
                return

            # Обробка тексту через TextProcessor
            accented_text = self.text_processor.add_accents_to_text(raw_text, self.accents)
            paragraphs = accented_text.split("\n")
            
            self.text_for_correction = paragraphs
            self.fixed_text = []

            # Відновлюємо закладку ДО встановлення поточного абзацу
            self.restore_bookmark()
            
            # Встановлюємо початковий абзац на основі закладки
            if 0 <= self.current_paragraph_index < len(paragraphs):
                self.current_idx = self.current_paragraph_index
                self.text_input.text = paragraphs[self.current_paragraph_index]
                self.logger.info(f"\nopen_and_prepare_text: 📖 Відкрито абзац {self.current_paragraph_index+1}/{len(paragraphs)} з закладки\n")
            else:
                # Якщо закладка некоректна, знаходимо перший непорожній абзац
                i = 0
                while i < len(paragraphs) and not paragraphs[i].strip():
                    self.fixed_text.append("")
                    i += 1
                    
                if i < len(paragraphs):
                    self.current_idx = i
                    self.text_input.text = paragraphs[i]
                    self.logger.info(f"\nopen_and_prepare_text: 📖 Відкрито перший абзац {i+1}/{len(paragraphs)}\n")
                else:
                    self.current_idx = len(paragraphs)
                    self.text_input.text = ""
                    self.logger.warning("\nopen_and_prepare_text: 📖 Текст порожній\n")
                    self.show_popup("Готово", "Текст порожній.")

            self.clear_selection_state()
            
        except Exception as e:
            self.logger.error(f"\nopen_and_prepare_text: ❌ Помилка підготовки тексту: {e}\n")
            self.show_popup("Помилка", f"Не вдалося підготувати текст:\n{e}")

    def go_next_paragraph(self):
        """Переходить до наступного абзацу та зберігає позицію."""
        self.logger.info("\ngo_next_paragraph: ➡️ Перехід до наступного абзацу\n")
        self.stop_tts()
        
        if self.current_idx < 0 or self.current_idx >= len(self.text_for_correction):
            self.logger.warning("\ngo_next_paragraph: ⚠️ Неможливо перейти: некоректний поточний індекс\n")
            return

        # Зберігаємо поточний абзац
        self.fixed_text.append(self.text_input.text)
        self.current_idx += 1
        
        # Пропускаємо порожні абзаци
        skipped_count = 0
        while (self.current_idx < len(self.text_for_correction) and 
               not self.text_for_correction[self.current_idx].strip()):
            self.fixed_text.append("")
            self.current_idx += 1
            skipped_count += 1

        if self.current_idx < len(self.text_for_correction):
            self.text_input.text = self.text_for_correction[self.current_idx]
            
            # Оновлюємо поточну позицію
            self.current_paragraph_index = self.current_idx
            self.current_cursor_pos = 0
            self.current_scroll_y = 0.0
            
            self.logger.info(f"\ngo_next_paragraph: ✅ Перехід до абзацу {self.current_idx+1}/{len(self.text_for_correction)} (пропущено {skipped_count} порожніх)\n")
        else:
            self.text_input.text = ""
            self.logger.info("\ngo_next_paragraph: 🏁 Досягнуто кінця тексту\n")
            self.show_popup("Кінець", "Досягнуто кінця тексту.")

        self.clear_selection_state()
        
        # Автоматично зберігаємо закладку при переході
        self.save_bookmark()

    def save_full_text(self):
        """Зберігає весь текст у TXT файл та оновлює закладку."""
        self.stop_tts()
        
        content = self.build_full_text()
        success = self.file_manager.save_output_text(content)
        
        # Автоматичне збереження закладки при збереженні тексту
        self.save_bookmark()
        
        if success:
            self.logger.info("\nsave_full_text:💾 Текст успішно збережено\n")
        else:
            self.logger.error("\nsave_full_text: ❌ Помилка збереження тексту\n")

    def on_stop(self):
        """Викликається при закритті додатку - зберігає закладку."""
        self.save_bookmark()
        self.stop_tts()
        self.logger.info("\non_stop: 🔴 Редактор наголосів закрито\n ===========================")