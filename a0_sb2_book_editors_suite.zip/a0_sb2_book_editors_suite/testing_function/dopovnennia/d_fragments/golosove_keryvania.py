# -*- coding: utf-8 -*-
"""
ТЕСТОВИЙ МОДУЛЬ ГОЛОСОВОГО УПРАВЛІННЯ
Тестує різні системи розпізнавання мови для редактора
"""

from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.togglebutton import ToggleButton
from kivy.uix.popup import Popup
from kivy.clock import Clock
from kivy.core.window import Window
import json
import logging

# Словник команд
VOICE_COMMANDS = {
    # Навігація
    "наступний": "next_paragraph",
    "попередній": "prev_paragraph", 
    "початок": "to_start",
    
    # TTS управління
    "слухати": "listen",
    "пауза": "pause",
    "стоп": "stop",
    
    # Редагування
    "правити": "edit_word",
    "наголос": "insert_accent",
    "зберегти": "save",
    
    # Інтерфейс
    "тема": "toggle_theme",
    "меню": "open_menu"
}

class VoiceRecognitionTester(App):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.recognition_enabled = False
        self.current_recognition_system = "android"  # android / vosk / mock
        self.last_command = ""
        
        # Налаштування логування
        self.setup_logging()
        
    def setup_logging(self):
        """Налаштовує логування для тестування"""
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger('VoiceTest')
        
    def build(self):
        """Побудова інтерфейсу тестувальника"""
        Window.clearcolor = (0.1, 0.1, 0.1, 1)
        
        root = BoxLayout(orientation='vertical', spacing=10, padding=20)
        
        # Заголовок
        title = Label(
            text="ТЕСТ ГОЛОСОВОГО УПРАВЛІННЯ",
            font_size=30,
            size_hint_y=None,
            height=60,
            color=(1, 1, 1, 1)
        )
        root.add_widget(title)
        
        # Статус розпізнавання
        self.status_label = Label(
            text="Розпізнавання: ВИМКНЕНО",
            font_size=38,
            size_hint_y=None,
            height=40,
            color=(1, 0.5, 0.5, 1)
        )
        root.add_widget(self.status_label)
        
        # Остання команда
        self.command_label = Label(
            text="Остання команда: ---",
            font_size=36,
            size_hint_y=None,
            height=35,
            color=(0.8, 0.8, 1, 1)
        )
        root.add_widget(self.command_label)
        
        # Система розпізнавання
        self.system_label = Label(
            text="Система: Android SpeechRecognizer",
            font_size=36,
            size_hint_y=None,
            height=35,
            color=(0.7, 1, 0.7, 1)
        )
        root.add_widget(self.system_label)
        
        # Кнопка перемикача розпізнавання
        self.toggle_btn = ToggleButton(
            text='УВІМКНУТИ РОЗПІЗНАВАННЯ',
            font_size=30,
            size_hint_y=None,
            height=80
        )
        self.toggle_btn.bind(on_press=self.toggle_recognition)
        root.add_widget(self.toggle_btn)
        
        # Кнопки вибору системи
        system_layout = BoxLayout(orientation='horizontal', size_hint_y=None, height=60, spacing=10)
        
        self.android_btn = ToggleButton(
            text='Android',
            group='recognition_system',
            state='down'
        )
        self.android_btn.bind(on_press=lambda x: self.switch_recognition_system("android"))
        
        self.vosk_btn = ToggleButton(
            text='Vosk',
            group='recognition_system'
        )
        self.vosk_btn.bind(on_press=lambda x: self.switch_recognition_system("vosk"))
        
        self.mock_btn = ToggleButton(
            text='Mock (тест)',
            group='recognition_system'
        )
        self.mock_btn.bind(on_press=lambda x: self.switch_recognition_system("mock"))
        
        system_layout.add_widget(self.android_btn)
        system_layout.add_widget(self.vosk_btn)
        system_layout.add_widget(self.mock_btn)
        root.add_widget(system_layout)
        
        # Кнопка тестової команди
        test_btn = Button(
            text='ТЕСТ: Надіслати команду "слухати"',
            font_size=38,
            size_hint_y=None,
            height=60
        )
        test_btn.bind(on_press=lambda x: self.mock_voice_command("слухати"))
        root.add_widget(test_btn)
        
        # Інформація про доступні команди
        commands_info = Label(
            text=f"Доступні команди: {', '.join(VOICE_COMMANDS.keys())}",
            font_size=34,
            size_hint_y=None,
            height=100,
            color=(0.9, 0.9, 0.5, 1)
        )
        root.add_widget(commands_info)
        
        # Лог подій
        self.log_label = Label(
            text="Лог подій:\n",
            font_size=32,
            text_size=(Window.width - 40, None),
            size_hint_y=1,
            halign='left',
            valign='top'
        )
        self.log_label.bind(size=self._update_text_size)
        root.add_widget(self.log_label)
        
        self.log_message("Додаток запущено. Оберіть систему розпізнавання.")
        
        return root
    
    def _update_text_size(self, instance, size):
        """Оновлює розмір тексту для лейбла логу"""
        instance.text_size = (size[0], None)
    
    def log_message(self, message):
        """Додає повідомлення до логу"""
        self.logger.info(message)
        current_text = self.log_label.text
        new_text = f"{message}\n{current_text}"
        # Обмежуємо кількість рядків у лозі
        lines = new_text.split('\n')
        if len(lines) > 15:
            new_text = '\n'.join(lines[:15])
        self.log_label.text = new_text
    
    def toggle_recognition(self, instance):
        """Увімкнення/вимкнення розпізнавання"""
        if instance.state == 'down':
            self.start_recognition()
        else:
            self.stop_recognition()
    
    def start_recognition(self):
        """Запуск розпізнавання мови"""
        self.recognition_enabled = True
        self.status_label.text = "Розпізнавання: УВІМКНЕНО"
        self.status_label.color = (0.5, 1, 0.5, 1)
        self.toggle_btn.text = "ВИМКНУТИ РОЗПІЗНАВАННЯ"
        
        self.log_message(f"🚀 Запуск розпізнавання ({self.current_recognition_system})")
        
        # Запускаємо обрану систему розпізнавання
        if self.current_recognition_system == "android":
            self.start_android_recognition()
        elif self.current_recognition_system == "vosk":
            self.start_vosk_recognition()
        elif self.current_recognition_system == "mock":
            self.start_mock_recognition()
    
    def stop_recognition(self):
        """Зупинка розпізнавання мови"""
        self.recognition_enabled = False
        self.status_label.text = "Розпізнавання: ВИМКНЕНО"
        self.status_label.color = (1, 0.5, 0.5, 1)
        self.toggle_btn.text = "УВІМКНУТИ РОЗПІЗНАВАННЯ"
        
        self.log_message("⏹️ Розпізнавання зупинено")
    
    def switch_recognition_system(self, system):
        """Перемикання системи розпізнавання"""
        if self.recognition_enabled:
            self.stop_recognition()
        
        self.current_recognition_system = system
        self.system_label.text = f"Система: {system.upper()}"
        
        system_names = {
            "android": "Android SpeechRecognizer",
            "vosk": "Vosk (офлайн)",
            "mock": "Mock (тестування)"
        }
        
        self.log_message(f"🔁 Переключено на систему: {system_names.get(system, system)}")
    
    def start_android_recognition(self):
        """Запуск Android SpeechRecognizer"""
        try:
            from jnius import autoclass
            
            self.SpeechRecognizer = autoclass('android.speech.SpeechRecognizer')
            self.RecognizerIntent = autoclass('android.speech.RecognizerIntent')
            self.Intent = autoclass('android.content.Intent')
            
            # Перевірка доступності
            if not self.SpeechRecognizer.isRecognitionAvailable(PythonActivity.mActivity):
                self.log_message("❌ Android SpeechRecognizer не доступний")
                self.show_popup("Помилка", "SpeechRecognizer не доступний на цьому пристрої")
                self.stop_recognition()
                return
            
            # Створення розпізнавача
            self.speech_recognizer = self.SpeechRecognizer.createSpeechRecognizer(
                autoclass('org.kivy.android.PythonActivity').mActivity
            )
            
            # Налаштування Intent
            intent = self.Intent(self.RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            intent.putExtra(self.RecognizerIntent.EXTRA_LANGUAGE_MODEL, 
                          self.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            intent.putExtra(self.RecognizerIntent.EXTRA_LANGUAGE, "uk-UA")
            intent.putExtra(self.RecognizerIntent.EXTRA_PROMPT, "Скажіть команду...")
            intent.putExtra(self.RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            
            # Спроба офлайн режиму
            try:
                intent.putExtra(self.RecognizerIntent.EXTRA_PREFER_OFFLINE, True)
            except:
                self.log_message("ℹ️ Офлайн режим не підтримується")
            
            # Запуск слухання
            self.speech_recognizer.startListening(intent)
            self.log_message("🎤 Android SpeechRecognizer: Слухаю...")
            
        except Exception as e:
            self.log_message(f"❌ Помилка Android SpeechRecognizer: {str(e)}")
            self.show_popup("Помилка", f"Не вдалося запустити розпізнавання:\n{str(e)}")
            self.stop_recognition()
    
    def start_vosk_recognition(self):
        """Запуск Vosk розпізнавання (офлайн)"""
        try:
            import vosk
            self.log_message("🔧 Vosk: Спроба ініціалізації...")
            
            # Тут буде код для Vosk
            # Поки що імітуємо
            self.log_message("✅ Vosk ініціалізовано (імітація)")
            self.log_message("🎤 Vosk: Слухаю... (імітація)")
            
        except ImportError:
            self.log_message("❌ Vosk не встановлено. pip install vosk")
            self.show_popup("Помилка", "Vosk не встановлено.\n\nКоманда встановлення:\npip install vosk")
            self.stop_recognition()
        except Exception as e:
            self.log_message(f"❌ Помилка Vosk: {str(e)}")
            self.stop_recognition()
    
    def start_mock_recognition(self):
        """Запуск тестового режиму (імітація)"""
        self.log_message("🎤 Mock: Тестове розпізнавання активне")
        self.log_message("💡 Скажіть одну з доступних команд")
        
        # Імітуємо отримання команди через 3 секунди
        Clock.schedule_once(lambda dt: self.mock_voice_command("слухати"), 3)
    
    def mock_voice_command(self, command=None):
        """Імітація отримання голосової команди (для тесту)"""
        if not self.recognition_enabled:
            return
            
        if command is None:
            # Випадкова команда для тесту
            import random
            command = random.choice(list(VOICE_COMMANDS.keys()))
        
        self.log_message(f"🎯 Отримано команду: '{command}'")
        self.process_voice_command(command)
    
    def process_voice_command(self, command_text):
        """Обробка розпізнаної команди"""
        command_text = command_text.lower().strip()
        self.last_command = command_text
        
        # Оновлюємо інтерфейс
        self.command_label.text = f"Остання команда: {command_text}"
        
        # Перевіряємо чи команда в словнику
        if command_text in VOICE_COMMANDS:
            action = VOICE_COMMANDS[command_text]
            self.log_message(f"✅ Виконано: {command_text} -> {action}")
            
            # Тут буде виклик реальних методів редактора
            self.execute_command(action)
        else:
            self.log_message(f"❌ Невідома команда: '{command_text}'")
            self.show_popup("Невідома команда", 
                          f"'{command_text}' не розпізнана.\n\nДоступні команди:\n{', '.join(VOICE_COMMANDS.keys())}")
    
    def execute_command(self, action):
        """Виконує дію відповідно до команди"""
        action_methods = {
            "next_paragraph": self.cmd_next_paragraph,
            "prev_paragraph": self.cmd_prev_paragraph,
            "to_start": self.cmd_to_start,
            "listen": self.cmd_listen,
            "pause": self.cmd_pause,
            "stop": self.cmd_stop,
            "edit_word": self.cmd_edit_word,
            "insert_accent": self.cmd_insert_accent,
            "save": self.cmd_save,
            "toggle_theme": self.cmd_toggle_theme,
            "open_menu": self.cmd_open_menu
        }
        
        if action in action_methods:
            action_methods[action]()
        else:
            self.log_message(f"⚠️ Дія '{action}' не реалізована")
    
    # Команди-заглушки для тесту
    def cmd_next_paragraph(self):
        self.log_message("📖 Перехід до наступного абзацу")
    
    def cmd_prev_paragraph(self):
        self.log_message("📖 Перехід до попереднього абзацу")
    
    def cmd_to_start(self):
        self.log_message("🔙 Перехід до початку")
    
    def cmd_listen(self):
        self.log_message("🔊 Відтворення тексту")
    
    def cmd_pause(self):
        self.log_message("⏸️ Пауза відтворення")
    
    def cmd_stop(self):
        self.log_message("⏹️ Зупинка відтворення")
    
    def cmd_edit_word(self):
        self.log_message("✏️ Редагування слова")
    
    def cmd_insert_accent(self):
        self.log_message("́ Вставка наголосу")
    
    def cmd_save(self):
        self.log_message("💾 Збереження")
    
    def cmd_toggle_theme(self):
        self.log_message("🌙 Зміна теми")
    
    def cmd_open_menu(self):
        self.log_message("📋 Відкриття меню")
    
    def show_popup(self, title, message):
        """Показує спливаюче повідомлення"""
        popup = Popup(
            title=title,
            content=Label(text=message),
            size_hint=(0.8, 0.4)
        )
        popup.open()
        Clock.schedule_once(lambda dt: popup.dismiss(), 3)
    
    def on_stop(self):
        """При закритті додатка"""
        if hasattr(self, 'speech_recognizer'):
            try:
                self.speech_recognizer.destroy()
            except:
                pass

# Глобальна змінна для Android
PythonActivity = None
try:
    from jnius import autoclass
    PythonActivity = autoclass('org.kivy.android.PythonActivity')
except:
    pass

if __name__ == "__main__":
    VoiceRecognitionTester().run()