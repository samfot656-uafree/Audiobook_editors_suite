#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Простий перегляд всіх книг
"""

import json
from pathlib import Path

def list_books():
    """Показує всі книги. Без зайвих деталей."""
    projects_path = Path("/storage/emulated/0/projects")
    
    if not projects_path.exists():
        print("📁 Папка проектів пуста")
        return
    
    print("📚 Ваші книги:")
    print("=" * 50)
    
    for item in projects_path.iterdir():
        if item.is_dir():
            config_file = item / "config.json"
            if config_file.exists():
                with open(config_file, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                
                print(f"\n📖 {config['book_name']}")
                print(f"   🎯 Зараз: {config['current_editor']}")
                print(f"   📅 Створено: {config['created'][:10]}")
                
                # Розмір тексту
                text_file = Path(config['text_file'])
                if text_file.exists():
                    size = text_file.stat().st_size
                    print(f"   📝 Текст: {size} байт")

if __name__ == '__main__':
    list_books()