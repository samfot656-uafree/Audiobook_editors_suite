# -*- coding: utf-8 -*-
# Простий конвертер TXT в MP3 - ТОЧНО ПРАЦЮЄ
# Зберегти як: /storage/emulated/0/Documents/txt_to_mp3_simple.py

import os
from pathlib import Path
from gtts import gTTS

def convert_txt_to_mp3():
    """Простий конвертер, який завжди працює"""
    
    # === НАЛАШТУВАННЯ === ЗМІНІТЬ ЦІ ШЛЯХИ НА СВОЇ
    input_txt = "/storage/emulated/0/Documents/Inp_txt/Чекаючий_1_1.txt"
    output_mp3 = "/storage/emulated/0/Documents/Out_mp3/Чекаючий_1_1.mp3"
    
    try:
        print("🔄 Запуск конвертера...")
        
        # Перевірка вхідного файлу
        if not os.path.exists(input_txt):
            print(f"❌ Файл не знайдено: {input_txt}")
            return False
        
        # Читання тексту
        print("📖 Читаємо текст...")
        with open(input_txt, 'r', encoding='utf-8') as f:
            text = f.read().strip()
        
        if not text:
            print("❌ Файл порожній")
            return False
        
        print(f"📊 Знайдено текст: {len(text)} символів")
        
        # Створення папки для MP3
        os.makedirs(Path(output_mp3).parent, exist_ok=True)
        
        # Конвертація в MP3
        print("🎵 Конвертуємо в MP3...")
        tts = gTTS(text=text, lang='uk')
        tts.save(output_mp3)
        
        print(f"✅ УСПІХ! MP3 збережено: {output_mp3}")
        print(f"✅ Розмір файлу: {os.path.getsize(output_mp3)} байт")
        
        return True
        
    except Exception as e:
        print(f"❌ ПОМИЛКА: {e}")
        return False

# Запуск
if __name__ == "__main__":
    success = convert_txt_to_mp3()
    
    if success:
        print("\n🎉 Конвертація завершена успішно!")
    else:
        print("\n💥 Конвертація не вдалася")
    
    input("Натисніть Enter для виходу...")