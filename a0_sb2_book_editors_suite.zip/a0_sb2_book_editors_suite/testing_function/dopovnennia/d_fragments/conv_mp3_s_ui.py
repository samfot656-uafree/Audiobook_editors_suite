# -*- coding: utf-8 -*-
# Конвертер TXT в MP3 з інтерфейсом
# Зберігає як: /storage/emulated/0/Documents/txt_to_mp3_gui.py

from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.popup import Popup
from kivy.uix.filechooser import FileChooserListView
import os
from pathlib import Path
from gtts import gTTS

class TxtToMp3Converter(App):
    def build(self):
        self.title = "Конвертер TXT → MP3"
        
        layout = BoxLayout(orientation='vertical', padding=20, spacing=15)
        
        # Поле для шляху до TXT
        layout.add_widget(Label(text="📄 Вхідний TXT файл:"))
        self.txt_input = TextInput(
            text="/storage/emulated/0/Documents/Inp_txt/Чекаючий_1_1.txt",
            size_hint_y=None, height=60
        )
        layout.add_widget(self.txt_input)
        
        # Поле для шляху до MP3
        layout.add_widget(Label(text="🎵 Вихідний MP3 файл:"))
        self.mp3_input = TextInput(
            text="/storage/emulated/0/Documents/Out_mp3/Чекаючий_1_1.mp3",
            size_hint_y=None, height=60
        )
        layout.add_widget(self.mp3_input)
        
        # Кнопки
        btn_layout = BoxLayout(size_hint_y=None, height=80, spacing=10)
        
        self.btn_convert = Button(text="🔄 Конвертувати")
        self.btn_convert.bind(on_press=self.convert)
        btn_layout.add_widget(self.btn_convert)
        
        self.btn_clear = Button(text="❌ Очистити")
        self.btn_clear.bind(on_press=self.clear_fields)
        btn_layout.add_widget(self.btn_clear)
        
        layout.add_widget(btn_layout)
        
        # Статус
        self.status_label = Label(
            text="Готовий до конвертації...",
            size_hint_y=None, height=40
        )
        layout.add_widget(self.status_label)
        
        return layout
    
    def convert(self, instance):
        input_txt = self.txt_input.text.strip()
        output_mp3 = self.mp3_input.text.strip()
        
        if not input_txt:
            self.show_popup("Помилка", "Вкажіть шлях до TXT файлу")
            return
            
        if not output_mp3:
            self.show_popup("Помилка", "Вкажіть шлях для MP3 файлу")
            return
        
        try:
            self.status_label.text = "Перевірка файлів..."
            
            # Перевірка вхідного файлу
            if not os.path.exists(input_txt):
                self.show_popup("Помилка", f"Файл не знайдено:\n{input_txt}")
                return
            
            # Читання тексту
            with open(input_txt, 'r', encoding='utf-8') as f:
                text = f.read().strip()
            
            if not text:
                self.show_popup("Помилка", "Текстовий файл порожній")
                return
            
            self.status_label.text = "Конвертація..."
            
            # Створення папки
            os.makedirs(Path(output_mp3).parent, exist_ok=True)
            
            # Конвертація
            tts = gTTS(text=text, lang='uk', slow=False)
            tts.save(output_mp3)
            
            self.status_label.text = "✅ Готово!"
            self.show_popup("Успіх", f"MP3 збережено:\n{output_mp3}")
            
        except Exception as e:
            self.status_label.text = "❌ Помилка"
            self.show_popup("Помилка", f"Не вдалося конвертувати:\n{str(e)}")
    
    def clear_fields(self, instance):
        self.txt_input.text = ""
        self.mp3_input.text = ""
        self.status_label.text = "Поля очищено"
    
    def show_popup(self, title, message):
        popup = Popup(
            title=title,
            content=Label(text=message),
            size_hint=(0.8, 0.4)
        )
        popup.open()

if __name__ == "__main__":
    TxtToMp3Converter().run()