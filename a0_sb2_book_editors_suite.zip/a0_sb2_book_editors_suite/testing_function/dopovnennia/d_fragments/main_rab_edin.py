# -*- coding: utf-8 -*-
"""
/storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite/editors/accent_editor/main.py

Головний модуль редактора наголосів.
Використовує ModularConfigManager та модульну структуру.
"""

import sys
import os
import json
import re
from datetime import datetime
from pathlib import Path

# Додаємо шляхи для імпортів
sys.path.insert(0, '/storage/emulated/0/a0_sb2_book_editors_suite')
sys.path.insert(0, '/storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite')

# Kivy imports
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.popup import Popup
from kivy.uix.label import Label
from kivy.core.window import Window
from kivy.clock import Clock

# Спроба імпортувати з проекту
try:
    from core.config_manager import get_config_manager
    print("✅ Успішно імпортовано config_manager з core")
except ImportError as e:
    print(f"❌ Помилка імпорту config_manager: {e}")
    # Створимо заглушку для тестування
    class ConfigManagerStub:
        def __init__(self):
            self.data = {}
        def load_for_editor(self, editor_name):
            return {
                'TEXT_WIDGET_FONT_SIZE': 56,
                'ACCENTS_FILE': '/storage/emulated/0/Documents/pidgotovka_knigi/jsons/accents_probl.json',
                'INPUT_TEXT_FILE': '/storage/emulated/0/Documents/pidgotovka_knigi/txt/Чекаючий.1.1.Шлях_до_заснування.S-t-i-k-s.txt',
                'OUTPUT_MP3_FOLDER': '/storage/emulated/0/Documents/pidgotovka_knigi/output_mp3'
            }
        def update_bookmark(self, editor_name, cursor_pos, scroll_y):
            print(f"Закладка оновлена: {cursor_pos}, {scroll_y}")
        def get_bookmark(self, editor_name):
            return {'cursor_pos': 0, 'scroll_y': 1.0}
    
    def get_config_manager(path):
        return ConfigManagerStub()

# Регулярка для слів з комбінованим наголосом та апострофом
WORD_RE = re.compile(
    r"(?:[^\W\d_](?:\u0301)?)+(?:'(?:[^\W\d_](?:\u0301)?)+)*",
    flags=re.UNICODE
)

# === Допоміжні функції ===
def strip_combining_acute(s: str) -> str:
    """Видаляє комбінований наголос з рядка."""
    return s.replace('\u0301', '')

def match_casing(original: str, replacement: str) -> str:
    """Підбирає регістр заміни під оригінал."""
    if not original:
        return replacement
    if original.isupper():
        return replacement.upper()
    if original[0].isupper():
        return replacement[0].upper() + replacement[1:].lower()
    return replacement.lower()

def get_clock_str() -> str:
    """Повертає поточний час у форматі HH:MM."""
    try:
        return datetime.now().strftime("%H:%M")
    except Exception:
        return "--:--"

def get_battery_percent() -> int:
    """Повертає заряд батареї у %."""
    try:
        from jnius import autoclass
        PythonActivity = autoclass('org.kivy.android.PythonActivity')
        Context = autoclass('android.content.Context')
        BatteryManager = autoclass('android.os.BatteryManager')
        
        activity = PythonActivity.mActivity
        bm = activity.getSystemService(Context.BATTERY_SERVICE)
        val = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        if isinstance(val, (int, float)) and 0 <= int(val) <= 100:
            return int(val)
    except Exception:
        pass
    return -1

# === Попап редагування слова ===
class EditWordPopup(Popup):
    """Попап для редагування слова, вставки наголосу та збереження."""

    def __init__(self, main_app, original_word, **kwargs):
        super().__init__(**kwargs)
        self.main_app = main_app
        self.original_word = original_word
        self.title = f"Редагування: {original_word}"
        self.size_hint = (0.98, 0.88)

        root = BoxLayout(orientation='vertical', spacing=8, padding=8)
        btn_row = BoxLayout(size_hint_y=None, height=160, spacing=8)
        self.btn_listen = Button(text="Слухати", font_size=42)
        self.btn_insert = Button(text="Наголос", font_size=42)
        self.btn_save_both = Button(text="Сл+текст", font_size=42)
        self.btn_save_text = Button(text="В текст", font_size=42)
        self.btn_cancel = Button(text="Назад", font_size=42)
        for b in (self.btn_listen, self.btn_insert, self.btn_save_both, self.btn_save_text, self.btn_cancel):
            btn_row.add_widget(b)
        root.add_widget(btn_row)

        self.edit_input = TextInput(text=original_word, font_size=72, multiline=False)
        root.add_widget(self.edit_input)

        # Контейнер з годинником і батареєю
        info_row = BoxLayout(orientation='horizontal', size_hint_y=None, height=80, spacing=12)
        self.clock_label = Label(text=f"Час: {get_clock_str()}", font_size=36, halign='left', valign='middle')
        self.clock_label.bind(size=lambda inst, val: setattr(inst, 'text_size', val))
        batt = get_battery_percent()
        batt_txt = f"{batt}%" if batt >= 0 else "—"
        self.batt_label = Label(text=f"Батарея: {batt_txt}", font_size=36, halign='right', valign='middle')
        self.batt_label.bind(size=lambda inst, val: setattr(inst, 'text_size', val))
        info_row.add_widget(self.clock_label)
        info_row.add_widget(self.batt_label)
        root.add_widget(info_row)

        # Прив'язка функцій кнопок
        self.btn_listen.bind(on_press=self.on_listen_word)
        self.btn_insert.bind(on_press=self.on_insert_accent)
        self.btn_save_both.bind(on_press=self.on_save_dict_and_text)
        self.btn_save_text.bind(on_press=self.on_save_text_only)
        self.btn_cancel.bind(on_press=lambda *_: self.dismiss())

        self.content = root
        Clock.schedule_once(lambda *_: self.apply_theme_from_app(), 0)

    def apply_theme_from_app(self):
        """Встановлює колір поля редагування слова залежно від заряду батареї."""
        batt = get_battery_percent()
        colors = self.main_app.get_theme_colors()
        if batt >= 0:
            self.edit_input.cursor_color = (0.03, 0.85, 0.53, 1)
            if batt < 25:
                self.edit_input.background_color = (1, 0.2, 0.2, 1)
            elif batt < 30:
                self.edit_input.background_color = (1, 0.6, 0.6, 1)
            else:
                self.edit_input.background_color = colors["input_bg"]
                self.edit_input.foreground_color = colors["input_fg"]

        for b in (self.btn_listen, self.btn_insert, self.btn_save_both, self.btn_save_text, self.btn_cancel, self.batt_label, self.clock_label):
            b.background_normal = ""
            b.background_color = colors["button_bg"]
            b.color = colors["button_fg"]

    def on_insert_accent(self, *_):
        txt = strip_combining_acute(self.edit_input.text)
        try:
            pos = self.edit_input.cursor_index()
        except Exception:
            pos = len(txt)
        new = txt[:pos] + '\u0301' + txt[pos:]
        self.edit_input.text = new
        try:
            self.edit_input.cursor = (pos + 1, 0)
        except Exception:
            pass

    def on_listen_word(self, *_):
        text = self.edit_input.text.strip()
        if text:
            self.main_app.safe_tts_speak(text)

    def on_save_dict_and_text(self, *_):
        new_word = self.edit_input.text.strip()
        if not new_word:
            self.dismiss()
            return
        # Зберігаємо в словник нижнім регістром
        key = strip_combining_acute(self.original_word).lower()
        self.main_app.accents[key] = new_word.lower()
        self.main_app.save_accents()
        # Додаємо в текст у поточному регістрі
        replaced = match_casing(self.original_word, new_word)
        self.main_app.replace_word_in_current_paragraph(self.original_word, replaced)
        self.dismiss()

    def on_save_text_only(self, *_):
        new_word = self.edit_input.text.strip()
        if not new_word:
            self.dismiss()
            return
        replaced = match_casing(self.original_word, new_word)
        self.main_app.replace_word_in_current_paragraph(self.original_word, replaced)
        self.dismiss()

# === Попап додаткових кнопок ===
class ExtraButtonsPopup(Popup):
    """Вікно для рідко використовуваних кнопок"""

    def __init__(self, main_app, **kwargs):
        super().__init__(**kwargs)
        self.main_app = main_app
        self.title = "Додаткові кнопки"
        self.size_hint = (0.95, 0.8)

        root = BoxLayout(orientation='vertical', spacing=8, padding=8)

        # Ряд кнопок зверху
        btn_row = BoxLayout(size_hint_y=None, height=150, spacing=8)
        self.btn_save_txt = Button(text="До txt", font_size=42)
        self.btn_save_mp3 = Button(text="До mp3", font_size=42)
        self.btn_theme = Button(text="День-ніч", font_size=42)
        self.btn_sort_dict = Button(text="Сортуй", font_size=42)
        self.btn_back = Button(text="Назад", font_size=42)
        for b in (self.btn_save_txt, self.btn_save_mp3, self.btn_theme, self.btn_sort_dict, self.btn_back):
            btn_row.add_widget(b)
        root.add_widget(btn_row)
        
        root.add_widget(Label())  # порожній простір
        
        self.content = root

        # Прив'язка кнопок
        self.btn_save_txt.bind(on_press=self.on_save_txt)
        self.btn_save_mp3.bind(on_press=self.on_save_mp3)
        self.btn_theme.bind(on_press=self.on_toggle_theme)
        self.btn_sort_dict.bind(on_press=self.on_sort_dict)
        self.btn_back.bind(on_press=lambda *_: self.dismiss())

        Clock.schedule_once(lambda *_: self.apply_theme_from_app(), 0)

    def apply_theme_from_app(self):
        colors = self.main_app.get_theme_colors()
        for b in (self.btn_save_txt, self.btn_save_mp3, self.btn_theme, self.btn_sort_dict, self.btn_back):
            b.background_normal = ""
            b.background_color = colors["button_bg"]
            b.color = colors["button_fg"]

    def on_save_txt(self, *_):
        self.main_app.save_full_text()
        self.dismiss()

    def on_save_mp3(self, *_):
        self.main_app.save_full_mp3()
        self.dismiss()

    def on_toggle_theme(self, *_):
        self.main_app.toggle_theme()
        self.dismiss()

    def on_sort_dict(self, *_):
        """Сортування словника за ключами"""
        self.main_app.accents = dict(sorted(self.main_app.accents.items()))
        self.main_app.save_accents()
        popup = Popup(
            title="Словник відсортовано", 
            content=Label(text="Словник успішно відсортовано"),
            size_hint=(0.8, 0.3)
        )
        popup.open()

# === Основний додаток ===
class AccentEditorApp(App):
    """Основний клас редактора наголосів."""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.config_manager = None
        self.config = {}
        self.accents = {}
        self.text_for_correction = []
        self.fixed_text = []
        self.current_idx = -1
        self.selected_word = None
        self.tts = None
        self.theme_mode = "day"

    def build(self):
        """Побудова інтерфейсу додатку."""
        print("🚀 Запуск редактора наголосів...")
        
        # Ініціалізація конфіг менеджера
        try:
            config_path = "/storage/emulated/0/a0_sb2_book_editors_suite/config.json"
            self.config_manager = get_config_manager(config_path)
            self.config = self.config_manager.load_for_editor('accent_editor')
            print("✅ Конфігурація завантажена")
        except Exception as e:
            print(f"❌ Помилка завантаження конфігурації: {e}")
            self.config = {
                'TEXT_WIDGET_FONT_SIZE': 56,
                'ACCENTS_FILE': '/storage/emulated/0/Documents/pidgotovka_knigi/jsons/accents_probl.json',
                'INPUT_TEXT_FILE': '/storage/emulated/0/Documents/pidgotovka_knigi/txt/Чекаючий.1.1.Шлях_до_заснування.S-t-i-k-s.txt',
                'OUTPUT_MP3_FOLDER': '/storage/emulated/0/Documents/pidgotovka_knigi/output_mp3'
            }
        
        self.accents = self.load_accents()
        print(f"✅ Завантажено {len(self.accents)} наголосів")
        
        Window.softinput_mode = "below_target"

        # Основний layout
        root = BoxLayout(orientation='vertical', spacing=28, padding=28)

        # Верхній ряд кнопок
        top_row = BoxLayout(orientation='horizontal', size_hint_y=None, height=150, spacing=8)
        self.btn_listen = Button(text="Слухати", font_size=42)
        self.btn_pause = Button(text="Пауза", font_size=42)
        self.btn_edit = Button(text="Правити", font_size=42, disabled=True)
        self.btn_next = Button(text="Наступний", font_size=42)
        self.btn_extra = Button(text="...", font_size=42)
        
        for btn in (self.btn_listen, self.btn_pause, self.btn_edit, self.btn_next, self.btn_extra):
            top_row.add_widget(btn)

        # Текстове поле
        self.text_input = TextInput(
            font_size=self.config.get('TEXT_WIDGET_FONT_SIZE', 56),
            multiline=True
        )
        self.text_input.bind(on_touch_down=self.on_text_touch)

        # Додавання віджетів
        root.add_widget(top_row)
        root.add_widget(self.text_input)

        # Прив'язка подій
        self.btn_listen.bind(on_press=lambda *_: self.listen_current_paragraph())
        self.btn_pause.bind(on_press=lambda *_: self.stop_tts())
        self.btn_edit.bind(on_press=self.open_edit_popup)
        self.btn_next.bind(on_press=lambda *_: self.go_next_paragraph())
        self.btn_extra.bind(on_press=lambda *_: ExtraButtonsPopup(self).open())

        # Автоматичні дії
        Clock.schedule_once(lambda *_: self.open_and_prepare_text(), 0.1)
        Clock.schedule_once(lambda *_: self.apply_theme(), 0)
        Clock.schedule_once(lambda *_: self.restore_bookmark(), 0.2)

        return root

    # === Конфігурація та ініціалізація ===
    
    def load_accents(self):
        """Завантажує словник наголосів з JSON файлу."""
        accents_file = self.config.get('ACCENTS_FILE', '')
        if accents_file and Path(accents_file).exists():
            try:
                with open(accents_file, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception as e:
                print(f"Помилка завантаження accents.json: {e}")
        return {}

    def save_accents(self):
        """Зберігає словник наголосів у JSON файл."""
        accents_file = self.config.get('ACCENTS_FILE', '')
        if accents_file:
            try:
                Path(accents_file).parent.mkdir(parents=True, exist_ok=True)
                with open(accents_file, "w", encoding="utf-8") as f:
                    json.dump(self.accents, f, ensure_ascii=False, indent=2)
                print("✅ Словник наголосів збережено")
            except Exception as e:
                print(f"Помилка збереження accents: {e}")

    def save_bookmark(self):
        """Зберігає поточну позицію у конфіг."""
        if self.text_input and hasattr(self, 'config_manager'):
            try:
                cursor_pos = self.text_input.cursor_index()
                scroll_y = self.text_input.scroll_y
                self.config_manager.update_bookmark('accent_editor', cursor_pos, scroll_y)
            except Exception as e:
                print(f"Помилка збереження закладки: {e}")

    def restore_bookmark(self):
        """Відновлює позицію з конфігу."""
        try:
            if hasattr(self, 'config_manager'):
                bookmark = self.config_manager.get_bookmark('accent_editor')
                if self.text_input and bookmark:
                    self.text_input.cursor = (bookmark['cursor_pos'], 0)
                    self.text_input.scroll_y = bookmark['scroll_y']
        except Exception as e:
            print(f"Помилка відновлення закладки: {e}")

    # === TTS функції ===
    
    def init_tts(self):
        """Ініціалізує TTS для Android."""
        try:
            from jnius import autoclass
            TextToSpeech = autoclass('android.speech.tts.TextToSpeech')
            Locale = autoclass('java.util.Locale')
            HashMap = autoclass('java.util.HashMap')
            PythonActivity = autoclass('org.kivy.android.PythonActivity')
            
            tts = TextToSpeech(PythonActivity.mActivity, None)
            try:
                tts.setLanguage(Locale.forLanguageTag("uk-UA"))
            except Exception:
                try:
                    tts.setLanguage(Locale("uk"))
                except Exception:
                    pass
            print("✅ TTS ініціалізовано")
            return tts
        except Exception as e:
            print(f"❌ Помилка ініціалізації TTS: {e}")
            return None

    def safe_tts_speak(self, text: str):
        """Безпечне відтворення тексту через TTS."""
        if text:
            if self.tts is None:
                self.tts = self.init_tts()
            if self.tts:
                try:
                    from jnius import autoclass
                    HashMap = autoclass('java.util.HashMap')
                    TextToSpeech = autoclass('android.speech.tts.TextToSpeech')
                    
                    params = HashMap()
                    params.put("volume", "1.0")
                    self.tts.speak(text, TextToSpeech.QUEUE_FLUSH, params)
                except Exception as e:
                    print(f"Помилка TTS speak: {e}")

    def stop_tts(self):
        """Зупиняє TTS відтворення."""
        if self.tts:
            try:
                self.tts.stop()
            except Exception as e:
                print(f"Помилка TTS stop: {e}")

    def listen_current_paragraph(self):
        """Відтворює поточний абзац через TTS."""
        text = self.text_input.text.strip()
        if text:
            self.safe_tts_speak(text)

    # === Робота з текстом ===
    
    def open_and_prepare_text(self):
        """Завантажує текст та автоматично додає наголоси з словника."""
        input_file = self.config.get('INPUT_TEXT_FILE', '')
        if not input_file or not Path(input_file).exists():
            self.show_popup("Помилка", f"Файл не знайдено:\n{input_file}")
            return

        try:
            with open(input_file, "r", encoding="utf-8") as f:
                raw_text = f.read()
            print(f"✅ Текст завантажено: {len(raw_text)} символів")
        except Exception as e:
            self.show_popup("Помилка", f"Не вдалося прочитати файл:\n{e}")
            return

        # Автоматичне додавання наголосів з словника
        def replace_with_accent(match):
            word = match.group(0)
            if '\u0301' in word:  # Якщо вже є наголос - залишаємо
                return word
            key = strip_combining_acute(word).lower()
            if key in self.accents:
                return match_casing(word, self.accents[key])
            return word

        accented_text = WORD_RE.sub(replace_with_accent, raw_text)
        paragraphs = accented_text.split("\n")
        
        self.text_for_correction = paragraphs
        self.fixed_text = []
        self.current_idx = -1

        # Знаходимо перший непорожній абзац
        i = 0
        while i < len(paragraphs) and not paragraphs[i].strip():
            self.fixed_text.append("")
            i += 1
            
        if i < len(paragraphs):
            self.current_idx = i
            self.text_input.text = paragraphs[i]
            print(f"✅ Відкрито абзац {i+1}/{len(paragraphs)}")
        else:
            self.current_idx = len(paragraphs)
            self.text_input.text = ""
            self.show_popup("Готово", "Текст порожній.")

        self.clear_selection_state()

    def go_next_paragraph(self):
        """Переходить до наступного абзацу."""
        self.stop_tts()
        self.save_bookmark()
        
        if self.current_idx < 0 or self.current_idx >= len(self.text_for_correction):
            return

        self.fixed_text.append(self.text_input.text)
        self.current_idx += 1
        
        # Пропускаємо порожні абзаци
        while (self.current_idx < len(self.text_for_correction) and 
               not self.text_for_correction[self.current_idx].strip()):
            self.fixed_text.append("")
            self.current_idx += 1

        if self.current_idx < len(self.text_for_correction):
            self.text_input.text = self.text_for_correction[self.current_idx]
            print(f"✅ Перехід до абзацу {self.current_idx+1}/{len(self.text_for_correction)}")
        else:
            self.text_input.text = ""
            self.show_popup("Кінець", "Досягнуто кінця тексту.")

        self.clear_selection_state()

    def build_full_text(self) -> str:
        """Побудова повного тексту з виправленими абзацами."""
        parts = list(self.fixed_text)
        if 0 <= self.current_idx < len(self.text_for_correction):
            parts.append(self.text_input.text)
            parts.extend(self.text_for_correction[self.current_idx + 1:])
        return "\n".join(parts)

    # === Виділення та редагування слів ===
    
    def on_text_touch(self, instance, touch):
        """Обробка торкання текстового поля для виділення слова."""
        if not instance.collide_point(*touch.pos):
            return False
        Clock.schedule_once(lambda *_: self.detect_word_at_cursor(), 0.01)
        return False

    def detect_word_at_cursor(self):
        """Визначає слово під курсором."""
        try:
            cursor_idx = self.text_input.cursor_index()
        except Exception:
            self.clear_selection_state()
            return

        text = self.text_input.text
        if not text:
            self.clear_selection_state()
            return

        # Знаходимо межі слова
        start = cursor_idx
        while start > 0 and self.is_word_char(text[start - 1]):
            start -= 1

        end = cursor_idx
        while end < len(text) and self.is_word_char(text[end]):
            end += 1

        word = text[start:end]
        if WORD_RE.fullmatch(word):
            self.selected_word = word
            self.btn_edit.disabled = False
        else:
            self.clear_selection_state()

    def is_word_char(self, char: str) -> bool:
        """Перевіряє, чи символ є частиною слова."""
        return char.isalpha() or char == '\u0301' or char == "'"

    def clear_selection_state(self):
        """Очищає стан виділення."""
        self.selected_word = None
        self.btn_edit.disabled = True

    def open_edit_popup(self, *_):
        """Відкриває попап для редагування слова."""
        if self.selected_word:
            self.stop_tts()
            EditWordPopup(self, self.selected_word).open()

    def replace_word_in_current_paragraph(self, old_word: str, new_word: str):
        """Замінює слово в поточному абзаці."""
        if self.current_idx < 0:
            return
        current_text = self.text_input.text
        replaced_text = current_text.replace(old_word, new_word, 1)
        self.text_input.text = replaced_text

    # === Утиліти ===
    
    def show_popup(self, title: str, message: str):
        """Показує спливаюче повідомлення."""
        popup = Popup(
            title=title,
            content=Label(text=message),
            size_hint=(0.8, 0.4)
        )
        popup.open()

    # === Тема інтерфейсу ===
    
    def get_theme_colors(self):
        """Повертає кольори теми."""
        if self.theme_mode == "day":
            return {
                "button_bg": (0.5, 0.5, 0.5, 1),
                "button_fg": (1, 1, 1, 1),
                "input_bg": (1, 1, 1, 1),
                "input_fg": (0, 0, 0, 1)
            }
        else:
            return {
                "button_bg": (0, 0, 0, 1),
                "button_fg": (0.6, 0.85, 1, 1),
                "input_bg": (0, 0, 0, 1),
                "input_fg": (0, 0, 1, 1)
            }

    def apply_theme(self):
        """Застосовує поточну тему до інтерфейсу."""
        colors = self.get_theme_colors()
        
        # Кнопки
        buttons = [self.btn_listen, self.btn_pause, self.btn_edit, self.btn_next, self.btn_extra]
        for btn in buttons:
            btn.background_normal = ""
            btn.background_color = colors["button_bg"]
            btn.color = colors["button_fg"]

        # Текстове поле
        self.text_input.background_color = colors["input_bg"]
        self.text_input.foreground_color = colors["input_fg"]
        self.text_input.cursor_color = (0.03, 0.85, 0.53, 1)
        
        # Фон вікна
        Window.clearcolor = colors["input_bg"]

    def toggle_theme(self):
        """Перемикає тему день/ніч."""
        self.stop_tts()
        self.theme_mode = "night" if self.theme_mode == "day" else "day"
        self.apply_theme()

    # === Збереження файлів ===
    
    def save_full_text(self):
        """Зберігає весь текст у TXT файл."""
        self.stop_tts()
        self.save_bookmark()
        
        content = self.build_full_text()
        output_file = self.config.get('INPUT_TEXT_FILE', '')
        
        if not output_file:
            self.show_popup("Помилка", "Шлях для збереження не вказано")
            return

        try:
            Path(output_file).parent.mkdir(parents=True, exist_ok=True)
            with open(output_file, "w", encoding="utf-8") as f:
                f.write(content)
            self.show_popup("Збережено", f"TXT збережено:\n{output_file}")
            print(f"✅ Текст збережено: {output_file}")
        except Exception as e:
            self.show_popup("Помилка збереження", str(e))

    def save_full_mp3(self):
        """Зберігає весь текст у MP3 через gTTS."""
        self.stop_tts()
        self.save_bookmark()
        
        try:
            from gtts import gTTS
        except ImportError:
            self.show_popup("Помилка", "gTTS не встановлено")
            return

        content = self.build_full_text().strip()
        if not content:
            self.show_popup("Помилка", "Текст порожній")
            return

        output_folder = self.config.get('OUTPUT_MP3_FOLDER', '')
        if not output_folder:
            self.show_popup("Помилка", "Папка для MP3 не вказана")
            return

        try:
            # Створюємо папку якщо не існує
            Path(output_folder).mkdir(parents=True, exist_ok=True)
            
            # Формуємо ім'я файлу
            input_filename = Path(self.config.get('INPUT_TEXT_FILE', 'text')).stem
            timestamp = datetime.now().strftime("%d_%m_%Y_%H_%M")
            output_filename = f"{input_filename}_змін_{timestamp}.mp3"
            output_path = Path(output_folder) / output_filename
            
            # Генеруємо MP3
            tts = gTTS(text=content, lang="uk")
            tts.save(str(output_path))
            
            self.show_popup("MP3 збережено", f"MP3 збережено:\n{output_path}")
            print(f"✅ MP3 збережено: {output_path}")
        except Exception as e:
            self.show_popup("Помилка gTTS", str(e))

    def on_stop(self):
        """Викликається при закритті додатку."""
        self.save_bookmark()
        self.stop_tts()
        print("🔴 Редактор наголосів закрито")


if __name__ == "__main__":
    AccentEditorApp().run()