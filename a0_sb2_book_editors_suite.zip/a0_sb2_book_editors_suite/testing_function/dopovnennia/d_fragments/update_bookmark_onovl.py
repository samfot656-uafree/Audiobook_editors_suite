def update_bookmark(self, editor_name: str, cursor_pos: int, scroll_y: float, paragraph_index: int):
    """Оновлює закладку для конкретного редактора з новими полями."""
    updates = {
        'BOOKMARK': {
            'cursor': int(cursor_pos),
            'scroll': float(scroll_y),
            'paragraph_index': int(paragraph_index)
        }
    }
    self.save_from_editor(editor_name, updates)
    self.logger.info(f"update_bookmark: \nОновлено закладку для {editor_name}: \nparagraph={paragraph_index}, cursor={cursor_pos}, scroll={scroll_y}\n")

def get_bookmark(self, editor_name: str) -> Dict[str, Any]:
    """Отримує закладку для конкретного редактора з новими полями."""
    editor_config = self.load_for_editor(editor_name)
    bookmark = editor_config.get('BOOKMARK', {'cursor': 0, 'scroll': 0.0, 'paragraph_index': 0})
    return {
        'scroll_y': bookmark.get('scroll', 0.0),
        'cursor_pos': bookmark.get('cursor', 0),
        'paragraph_index': bookmark.get('paragraph_index', 0)
    }