# В методі _create_project_config додаємо конфіг для sound_effects_editor:
"SOUND_EFFECTS_EDITOR_SOUNDS_EFFECTS_LIST": f"{base_path}/json/sound_effects_list.json",
"SOUND_EFFECTS_EDITOR_SOUNDS_EFFECTS_FILES": f"{base_path}/json/sound_effects_files.json",
"SOUND_EFFECTS_EDITOR_SOUNDS_EFFECTS_INPUT_FOLDER": f"{base_path}/inputs/input_sounds_effects",
"SOUND_EFFECTS_EDITOR_BOOKMARK": {
    "cursor": 0,
    "scroll": 0.0,
    "paragraph_index": 0
},

# В методі create_project_structure оновлюємо створення JSON файлів:
json_files = {
    f"{project_path}/json/accents_files.json": {"акцент": "на́голос"},
    f"{project_path}/json/sound_effects_list.json": {"sound_effects": {}},  # Нова структура
    f"{project_path}/json/sound_effects_files.json": {"sounds": {}}
}