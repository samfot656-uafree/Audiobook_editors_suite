# === Спрощена логіка роботи з текстом на папері ===

def open_and_prepare_text(self):
    """Завантажує текст, додає наголоси, розбиває на абзаци та відновлює позицію закладки."""
    try:
        # Завантаження тексту
        raw_text = self.file_manager.load_input_text()
        if raw_text is None:
            self.logger.warning("open_and_prepare_text: Текст не знайдено.")
            return

        # Додаємо наголоси та розбиваємо на абзаци
        accented_text = self.text_processor.add_accents_to_text(raw_text, self.accents)
        paragraphs = accented_text.split("\n")
        
        # Зберігаємо всі абзаци
        self.text_for_correction = paragraphs
        self.fixed_text = []

        # Відновлюємо закладку
        self.restore_bookmark()
        target_index = self.current_paragraph_index

        # Імітуємо переходи до закладки
        for i in range(target_index):
            # Просто додаємо абзаци до закладки в fixed_text без змін
            self.fixed_text.append(self.text_for_correction[i])

        # Встановлюємо поточний абзац (той, що позначений закладкою)
        if target_index < len(self.text_for_correction):
            self.text_input.text = self.text_for_correction[target_index]
            self.current_paragraph_index = target_index
        else:
            self.text_input.text = ""
            self.current_paragraph_index = len(self.text_for_correction)

        # Оновлюємо кнопку
        total_paragraphs = len(self.text_for_correction)
        self.btn_extra.text = f"   . . .   \n{self.current_paragraph_index+1}/{total_paragraphs}"

        self.logger.info(f"open_and_prepare_text: Відкрито абзац {self.current_paragraph_index+1}/{total_paragraphs} з закладки")
        self.clear_selection_state()

    except Exception as e:
        self.logger.error(f"open_and_prepare_text: Помилка підготовки тексту: {e}")
        self.show_popup("Помилка", f"Не вдалося підготувати текст:\n{e}")

def go_next_paragraph(self):
    """Переходить до наступного абзацу, зберігаючи поточний у fixed_text."""
    self.stop_tts()

    # Зберігаємо поточний абзац в fixed_text
    current_text = self.text_input.text
    if self.current_paragraph_index < len(self.text_for_correction):
        # Замінюємо оригінальний текст на відредагований
        self.fixed_text.append(current_text)
        
        # Переходимо до наступного абзацу
        self.current_paragraph_index += 1
        
        if self.current_paragraph_index < len(self.text_for_correction):
            self.text_input.text = self.text_for_correction[self.current_paragraph_index]
            self.logger.info(f"go_next_paragraph: Перехід до абзацу {self.current_paragraph_index+1}/{len(self.text_for_correction)}")
        else:
            self.text_input.text = ""
            self.logger.info("go_next_paragraph: Досягнуто кінця тексту")
            self.show_popup("Кінець", "Досягнуто кінця тексту.")
    else:
        self.logger.warning("go_next_paragraph: Немає більше абзаців")

    # Оновлюємо кнопку та закладку
    self.btn_extra.text = f"   . . .   \n{self.current_paragraph_index+1}/{len(self.text_for_correction)}"
    self.move_bookmark()
    self.clear_selection_state()

def build_full_text(self) -> str:
    """Побудова повного тексту: fixed_text + поточний + решта text_for_correction."""
    # Збираємо всі частини тексту
    full_parts = []
    
    # Додаємо вже відредаговані абзаци
    full_parts.extend(self.fixed_text)
    
    # Додаємо поточний абзац
    if self.current_paragraph_index < len(self.text_for_correction):
        full_parts.append(self.text_input.text)
        
        # Додаємо решту невідредагованих абзаців
        if self.current_paragraph_index + 1 < len(self.text_for_correction):
            remaining_paragraphs = self.text_for_correction[self.current_paragraph_index + 1:]
            full_parts.extend(remaining_paragraphs)
    
    # З'єднуємо всі абзаци
    full_text = "\n".join(full_parts)
    
    self.logger.debug(f"build_full_text: Зібрано повний текст: {len(full_parts)} абзаців")
    return full_text

def save_full_text(self):
    """Зберігає весь текст у файл та оновлює закладку в конфігу."""
    self.stop_tts()
    
    # Збираємо повний текст
    content = self.build_full_text()
    
    # Зберігаємо текст у файл
    success = self.file_manager.save_output_text(content)
    
    # Зберігаємо закладку в конфіг
    self.save_bookmark()
    
    if success:
        self.logger.info("save_full_text: Текст успішно збережено")
    else:
        self.logger.error("save_full_text: Помилка збереження тексту")

def move_bookmark(self):
    """Оновлює позицію закладки у властивостях класу без запису у конфіг файл."""
    try:
        if self.text_input:
            self.current_cursor_pos = self.text_input.cursor_index()
            self.current_scroll_y = self.text_input.scroll_y
            self.logger.debug(f"move_bookmark: Оновлено закладку: абзац {self.current_paragraph_index}")
    except Exception as e:
        self.logger.error(f"move_bookmark: Помилка оновлення закладки: {e}")

def save_bookmark(self):
    """Зберігає поточну позицію у конфіг проекту."""
    try:
        if hasattr(self, 'config_manager'):
            self.config_manager.update_bookmark(
                'accent_editor', 
                self.current_cursor_pos, 
                self.current_scroll_y,
                self.current_paragraph_index
            )
            self.logger.debug(f"save_bookmark: Закладку збережено: абзац {self.current_paragraph_index}")
    except Exception as e:
        self.logger.error(f"save_bookmark: Помилка збереження закладки: {e}")

def restore_bookmark(self):
    """Відновлює позицію з конфігу проекту."""
    try:
        if hasattr(self, 'config_manager'):
            bookmark = self.config_manager.get_bookmark('accent_editor')
            if bookmark:
                self.current_scroll_y = bookmark.get('scroll_y', 0.0)
                self.current_cursor_pos = bookmark.get('cursor_pos', 0)
                self.current_paragraph_index = bookmark.get('paragraph_index', 0)
                self.logger.debug(f"restore_bookmark: Відновлено закладку: абзац {self.current_paragraph_index}")
    except Exception as e:
        self.logger.error(f"restore_bookmark: Помилка відновлення закладки: {e}")