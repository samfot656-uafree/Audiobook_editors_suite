# В editor_registry додаємо:
'sound_effects_editor': {
    'params': [
        'SOUNDS_EFFECTS_LIST', 
        'SOUNDS_EFFECTS_FILES',
        'SOUNDS_EFFECTS_INPUT_FOLDER',
        'SOUND_DICT',
        'BOOKMARK'
    ],
    'defaults': {
        'SOUND_DICT': {
            "S01": "Звук_пострілу",                        
            "S02": "Машина_гальмує", 
            "S03": "Гарчання_мутанта"
        },
        'SOUNDS_EFFECTS_LIST': '',
        'SOUNDS_EFFECTS_FILES': '',
        'SOUNDS_EFFECTS_INPUT_FOLDER': '',
        'BOOKMARK': {'cursor': 0, 'scroll': 0.0, 'paragraph_index': 0}
    }
},