# -*- coding: utf-8 -*-
# Конвертер з вибором файлів
# Зберегти як: /storage/emulated/0/Documents/txt_to_mp3_chooser.py

import os
from pathlib import Path
from gtts import gTTS

def choose_and_convert():
    """Конвертер з можливістю вибору файлів"""
    
    print("=== КОНВЕРТЕР TXT → MP3 ===")
    
    # Вибір вхідного файлу
    default_input = "/storage/emulated/0/Documents/Inp_txt/Чекаючий_1_1.txt"
    input_txt = input(f"Вхідний TXT файл [{default_input}]: ").strip()
    if not input_txt:
        input_txt = default_input
    
    # Вибір вихідного файлу  
    default_output = "/storage/emulated/0/Documents/Out_mp3/Чекаючий_1_1.mp3"
    output_mp3 = input(f"Вихідний MP3 файл [{default_output}]: ").strip()
    if not output_mp3:
        output_mp3 = default_output
    
    # Конвертація
    try:
        print(f"\n🔄 Конвертація: {Path(input_txt).name} → {Path(output_mp3).name}")
        
        # Перевірки
        if not os.path.exists(input_txt):
            print(f"❌ Файл не знайдено: {input_txt}")
            return False
            
        with open(input_txt, 'r', encoding='utf-8') as f:
            text = f.read().strip()
            
        if not text:
            print("❌ Файл порожній")
            return False
            
        # Створення папки
        os.makedirs(Path(output_mp3).parent, exist_ok=True)
        
        # Конвертація
        print("🎵 Створюємо MP3...")
        tts = gTTS(text=text, lang='uk')
        tts.save(output_mp3)
        
        print(f"✅ Успішно! Файл: {output_mp3}")
        return True
        
    except Exception as e:
        print(f"❌ Помилка: {e}")
        return False

if __name__ == "__main__":
    choose_and_convert()
    input("\nНатисніть Enter для виходу...")