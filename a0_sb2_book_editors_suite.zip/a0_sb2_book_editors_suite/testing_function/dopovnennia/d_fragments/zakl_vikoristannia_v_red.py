#використання в редакторах

# У будь-якому редакторі (accent_editor/main.py, voice_tags_editor/main.py, тощо)
from core.config_manager import ConfigManager
# або
from utils.bookmark_utils import create_bookmark, get_bookmark

# При збереженні стану
create_bookmark('accent_editor', cursor_position, scroll_position)

# При завантаженні
bookmark = get_bookmark('accent_editor')
cursor_pos = bookmark['cursor']
scroll_pos = bookmark['scroll']