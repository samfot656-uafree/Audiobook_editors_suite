# -*- coding: utf-8 -*-
"""
СПРОЩЕНИЙ ТЕСТ ГОЛОСОВОГО УПРАВЛІННЯ
Тільки Android SpeechRecognizer + Mock режим
З виводом логу в TextInput
"""

from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.togglebutton import ToggleButton
from kivy.uix.popup import Popup
from kivy.uix.textinput import TextInput
from kivy.uix.scrollview import ScrollView
from kivy.clock import Clock
from kivy.core.window import Window
import random

# Словник команд
VOICE_COMMANDS = {
    # Навігація
    "наступний": "next_paragraph",
    "попередній": "prev_paragraph", 
    "початок": "to_start",
    
    # TTS управління
    "слухати": "listen",
    "пауза": "pause",
    "стоп": "stop",
    
    # Редагування
    "правити": "edit_word",
    "наголос": "insert_accent",
    "зберегти": "save",
    
    # Інтерфейс
    "тема": "toggle_theme",
    "меню": "open_menu"
}

class SimpleVoiceTest(App):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.recognition_enabled = False
        self.current_system = "android"
        self.android_available = False
        self.check_android_speech()
        
    def check_android_speech(self):
        """Перевіряє чи доступний Android SpeechRecognizer"""
        try:
            from jnius import autoclass
            self.SpeechRecognizer = autoclass('android.speech.SpeechRecognizer')
            self.RecognizerIntent = autoclass('android.speech.RecognizerIntent')
            self.Intent = autoclass('android.content.Intent')
            self.PythonActivity = autoclass('org.kivy.android.PythonActivity')
            
            # Перевірка доступності
            if self.SpeechRecognizer.isRecognitionAvailable(self.PythonActivity.mActivity):
                self.android_available = True
                print("✅ Android SpeechRecognizer доступний")
            else:
                print("❌ Android SpeechRecognizer не доступний")
                
        except Exception as e:
            print(f"❌ Помилка перевірки Android Speech: {e}")
            self.android_available = False
    
    def build(self):
        """Побудова інтерфейсу"""
        Window.clearcolor = (0.1, 0.1, 0.1, 1)
        
        root = BoxLayout(orientation='vertical', spacing=10, padding=20)
        
        # Заголовок
        title = Label(
            text="ПРОСТИЙ ТЕСТ ГОЛОСОВОГО УПРАВЛІННЯ",
            font_size=40,
            size_hint_y=None,
            height=100,
            color=(1, 1, 1, 1)
        )
        root.add_widget(title)
        
        # Статус Android
        android_status = "Доступний" if self.android_available else "Недоступний"
        android_label = Label(
            text=f"Android SpeechRecognizer: {android_status}",
            font_size=40,
            size_hint_y=None,
            height=100,
            color=(0, 1, 0, 1) if self.android_available else (1, 0, 0, 1)
        )
        root.add_widget(android_label)
        
        # Статус розпізнавання
        self.status_label = Label(
            text="Розпізнавання: ВИМКНЕНО",
            font_size=40,
            size_hint_y=None,
            height=100,
            color=(1, 0.5, 0.5, 1)
        )
        root.add_widget(self.status_label)
        
        # Остання команда
        self.command_label = Label(
            text="Остання команда: ---",
            font_size=40,
            size_hint_y=None,
            height=100,
            color=(0.8, 0.8, 1, 1)
        )
        root.add_widget(self.command_label)
        
        # Кнопка перемикача
        self.toggle_btn = ToggleButton(
            text='УВІМКНУТИ РОЗПІЗНАВАННЯ' if self.android_available else 'ANDROID SPEECH НЕДОСТУПНИЙ',
            font_size=40,
            size_hint_y=None,
            height=100,
            disabled=not self.android_available
        )
        self.toggle_btn.bind(on_press=self.toggle_recognition)
        root.add_widget(self.toggle_btn)
        
        # Кнопки тестових команд
        commands_layout = BoxLayout(orientation='horizontal', size_hint_y=None, height=100, spacing=5)
        
        test_commands = ["слухати", "наступний", "пауза", "тема"]
        for cmd in test_commands:
            btn = Button(
                text=cmd,
                font_size=40,
                size_hint_x=0.25
            )
            btn.bind(on_press=lambda x, c=cmd: self.mock_voice_command(c))
            commands_layout.add_widget(btn)
        
        root.add_widget(commands_layout)
        
        # Кнопка випадкової команди
        random_btn = Button(
            text='ВИПАДКОВА КОМАНДА',
            font_size=40,
            size_hint_y=None,
            height=100
        )
        random_btn.bind(on_press=lambda x: self.mock_voice_command())
        root.add_widget(random_btn)
        
        # Лейбл для логу
        log_label = Label(
            text="Лог подій:",
            font_size=40,
            size_hint_y=None,
            height=100,
            color=(0.9, 0.9, 0.5, 1)
        )
        root.add_widget(log_label)
        
        # ScrollView для TextInput логу
        scroll_view = ScrollView(size_hint=(1, 1))
        
        # TextInput для логу (multiline, readonly)
        self.log_input = TextInput(
            text="Тут будуть повідомлення...\n",
            font_size=40,
            size_hint_y=None,
            readonly=False,
            background_color=(0.05, 0.05, 0.05, 1),
            foreground_color=(0.9, 0.9, 0.9, 1),
            cursor_color=(0.3, 0.7, 1, 1),
            multiline=True
        )
        
        # Встановлюємо мінімальну висоту для TextInput
        self.log_input.height = 800
        scroll_view.add_widget(self.log_input)
        root.add_widget(scroll_view)
        
        # Кнопка очищення логу
        clear_btn = Button(
            text='ОЧИСТИТИ ЛОГ',
            font_size=40,
            size_hint_y=None,
            height=100
        )
        clear_btn.bind(on_press=self.clear_log)
        root.add_widget(clear_btn)
        
        self.log_message("Готовий до тестування!")
        if not self.android_available:
            self.log_message("Використовуйте кнопки для імітації команд")
        
        return root
    
    def clear_log(self, instance=None):
        """Очищає лог"""
        self.log_input.text = ""
        self.log_message("Лог очищено")
    
    def log_message(self, message):
        """Додає повідомлення до логу в TextInput"""
        print(f"LOG: {message}")
        
        # Додаємо нове повідомлення зверху
  #      timestamp = Clock.get_strftime("%H:%M:%S")
        log_entry = f" {message}\n"
        
        # Додаємо новий запис на початок
        current_text = self.log_input.text
        new_text = log_entry + current_text
        
        # Обмежуємо кількість рядків (необов'язково)
        lines = new_text.split('\n')
        if len(lines) > 100:  # Максимум 100 рядків
            new_text = '\n'.join(lines[:100])
        
        self.log_input.text = new_text
        
        # Автоматично скролимо до верху
        self.log_input.cursor = (0, 0)
    
    def toggle_recognition(self, instance):
        """Увімкнення/вимкнення розпізнавання"""
        if instance.state == 'down' and self.android_available:
            self.start_android_recognition()
        else:
            self.stop_recognition()
    
    def start_android_recognition(self):
        """Запуск Android SpeechRecognizer"""
        try:
            self.speech_recognizer = self.SpeechRecognizer.createSpeechRecognizer(self.PythonActivity.mActivity)
            
            # Створюємо обробник подій
            class RecognitionListener(autoclass('android.speech.RecognitionListener')):
                def __init__(self, parent):
                    super().__init__()
                    self.parent = parent
                
                def onResults(self, results):
                    self.parent.on_recognition_results(results)
                
                def onError(self, error):
                    self.parent.on_recognition_error(error)
                
                def onReadyForSpeech(self, params):
                    self.parent.log_message("🎤 Готовий до розпізнавання...")
                
                def onBeginningOfSpeech(self):
                    self.parent.log_message("🔊 Початок мовлення")
                
                def onEndOfSpeech(self):
                    self.parent.log_message("🔇 Кінець мовлення")
            
            self.listener = RecognitionListener(self)
            self.speech_recognizer.setRecognitionListener(self.listener)
            
            # Налаштовуємо Intent
            intent = self.Intent(self.RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            intent.putExtra(self.RecognizerIntent.EXTRA_LANGUAGE_MODEL, 
                          self.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            intent.putExtra(self.RecognizerIntent.EXTRA_LANGUAGE, "uk-UA")
            intent.putExtra(self.RecognizerIntent.EXTRA_PROMPT, "Скажіть команду...")
            intent.putExtra(self.RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            
            # Запускаємо
            self.speech_recognizer.startListening(intent)
            
            self.recognition_enabled = True
            self.status_label.text = "Розпізнавання: УВІМКНЕНО"
            self.status_label.color = (0.5, 1, 0.5, 1)
            self.toggle_btn.text = "ВИМКНУТИ РОЗПІЗНАВАННЯ"
            
            self.log_message("🎤 Android Speech: Слухаю...")
            
        except Exception as e:
            self.log_message(f"❌ Помилка: {str(e)}")
            self.show_popup("Помилка", f"Не вдалося запустити:\n{str(e)}")
    
    def on_recognition_results(self, results):
        """Обробка результатів розпізнавання"""
        try:
            from jnius import cast
            ArrayList = autoclass('java.util.ArrayList')
            array_list = cast(ArrayList, results.getStringArrayList(self.SpeechRecognizer.RESULTS_RECOGNITION))
            
            if array_list and array_list.size() > 0:
                best_result = array_list.get(0)
                self.log_message(f"🎯 Розпізнано: '{best_result}'")
                self.process_voice_command(best_result)
            else:
                self.log_message("❌ Нічого не розпізнано")
                
        except Exception as e:
            self.log_message(f"❌ Помилка обробки результатів: {e}")
    
    def on_recognition_error(self, error):
        """Обробка помилок розпізнавання"""
        error_codes = {
            1: "Аудіо не записано",
            2: "Помилка сервера", 
            3: "Помилка мережі",
            4: "Неправильна мова",
            5: "Неправильна конфігурація",
            6: "Немає відповіді",
            7: "Слухання зупинено",
            8: "Занадто багато запитів",
            9: "Недостатньо дозволів"
        }
        error_msg = error_codes.get(error, f"Невідома помилка: {error}")
        self.log_message(f"❌ Помилка розпізнавання: {error_msg}")
        
        # Автоматично перезапускаємо, якщо це тимчасова помилка
        if error in [2, 3, 6] and self.recognition_enabled:
            self.log_message("🔄 Перезапуск розпізнавання...")
            Clock.schedule_once(lambda dt: self.start_android_recognition(), 1)
    
    def stop_recognition(self):
        """Зупинка розпізнавання"""
        if hasattr(self, 'speech_recognizer'):
            try:
                self.speech_recognizer.stopListening()
                self.speech_recognizer.destroy()
            except:
                pass
        
        self.recognition_enabled = False
        self.status_label.text = "Розпізнавання: ВИМКНЕНО"
        self.status_label.color = (1, 0.5, 0.5, 1)
        if self.android_available:
            self.toggle_btn.text = "УВІМКНУТИ РОЗПІЗНАВАННЯ"
        
        self.log_message("⏹️ Розпізнавання зупинено")
    
    def mock_voice_command(self, command=None):
        """Імітація голосової команди (для тесту)"""
        if command is None:
            command = random.choice(list(VOICE_COMMANDS.keys()))
        
        self.log_message(f"🎯 Тестова команда: '{command}'")
        self.process_voice_command(command)
    
    def process_voice_command(self, command_text):
        """Обробка команди"""
        command_text = command_text.lower().strip()
        self.command_label.text = f"Остання команда: {command_text}"
        
        if command_text in VOICE_COMMANDS:
            action = VOICE_COMMANDS[command_text]
            self.log_message(f"✅ Виконано: {command_text}")
            
            # Виконуємо дію
            self.execute_command(action)
        else:
            self.log_message(f"❌ Невідома команда: '{command_text}'")
    
    def execute_command(self, action):
        """Виконує дію"""
        actions = {
            "next_paragraph": lambda: self.log_message("📖 Наступний абзац"),
            "prev_paragraph": lambda: self.log_message("📖 Попередній абзац"),
            "to_start": lambda: self.log_message("🔙 До початку"),
            "listen": lambda: self.log_message("🔊 Слухати"),
            "pause": lambda: self.log_message("⏸️ Пауза"),
            "stop": lambda: self.log_message("⏹️ Стоп"),
            "edit_word": lambda: self.log_message("✏️ Правити слово"),
            "insert_accent": lambda: self.log_message("́ Наголос"),
            "save": lambda: self.log_message("💾 Зберегти"),
            "toggle_theme": lambda: self.log_message("🌙 Тема"),
            "open_menu": lambda: self.log_message("📋 Меню")
        }
        
        if action in actions:
            actions[action]()
        else:
            self.log_message(f"⚠️ Дія '{action}' не знайдена")
    
    def show_popup(self, title, message):
        """Показує спливаюче повідомлення"""
        popup = Popup(
            title=title,
            content=Label(text=message),
            size_hint=(0.8, 0.4)
        )
        popup.open()
    
    def on_stop(self):
        """При закритті додатка"""
        self.stop_recognition()

# Глобальні змінні для Android
autoclass = None
try:
    from jnius import autoclass
except:
    pass

if __name__ == "__main__":
    SimpleVoiceTest().run()