#оновлений коре конфіг менеджер пу

import json
import os
from pathlib import Path

BOOKMARK_JSON_PATH = "/storage/emulated/0/a0_sb1_book_editors_suite/Configs/jsons/config_migration3.py"
TESTING_TEXT_PATH = "/storage/emulated/0/a0_sb1_book_editors_suite/test_functions/testing_bookmarks.txt"

class ConfigManager:
    def __init__(self, config_path=None):
        if config_path is None:
            config_path = BOOKMARK_JSON_PATH
        self.config_path = Path(config_path)
        self.config = self.load_config()
    
    def load_config(self):
        """Завантажує конфігурацію з JSON файлу"""
        try:
            if self.config_path.exists():
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            else:
                # Створюємо директорію, якщо її немає
                self.config_path.parent.mkdir(parents=True, exist_ok=True)
                return {}
        except Exception as e:
            print(f"Помилка завантаження конфігурації: {e}")
            return {}
    
    def save_config(self):
        """Зберігає конфігурацію в JSON файл"""
        try:
            with open(self.config_path, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=4, ensure_ascii=False)
            return True
        except Exception as e:
            print(f"Помилка збереження конфігурації: {e}")
            return False
    
    def create_bookmark(self, editor_name, cursor_pos, scroll_y):
        """
        Створює закладку для редактора у конфіг файлі
        """
        bookmark_key = f"{editor_name.upper()}_BOOKMARK"
        
        self.config[bookmark_key] = {
            'cursor': cursor_pos,
            'scroll': scroll_y
        }
        
        return self.save_config()
    
    def get_bookmark(self, editor_name):
        """Отримує закладку для редактора"""
        bookmark_key = f"{editor_name.upper()}_BOOKMARK"
        return self.config.get(bookmark_key, {'cursor': 0, 'scroll': 0.0})
    
    def init_all_bookmarks(self):
        """Ініціалізує закладки для всіх редакторів"""
        editors_list = ('accent_editor', 'voice_tags_editor', 'sound_effects_editor', 'multispeaker_tts')
        
        for editor_name in editors_list:
            self.create_bookmark(editor_name, 0, 0.0)