Тепер можна імпортувати трьома способами:

Спосіб 1: З головного пакету

```python
from book_editors_suite import get_config_manager, reset_config_manager
```

Спосіб 2: З core модуля

```python
from book_editors_suite.core import get_config_manager, reset_config_manager
```

Спосіб 3: Безпосередньо з config_manager

```python
from book_editors_suite.core.config_manager import get_config_manager, reset_config_manager
```

Переваги такої структури: 🎯

1. ✅ Чіткий експорт - всі функції доступні з різних рівнів
2. ✅ Зручність використання - можна імпортувати так, як зручно
3. ✅ Модульність - кожен рівень має свої відповідності
4. ✅ Тестування - reset_config_manager доступна для тестів

Тепер структура повністю готова! 🚀 Функція reset_config_manager буде доступна з будь-якого місця проекту