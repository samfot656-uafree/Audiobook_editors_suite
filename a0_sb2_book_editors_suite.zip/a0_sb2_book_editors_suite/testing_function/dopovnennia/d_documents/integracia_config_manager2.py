# book_editors_suite/editors/accent_editor/main.py
from book_editors_suite.core.config_manager import get_config_manager

class AccentEditor:
    def __init__(self):
        self.config = get_config_manager("/storage/emulated/0/a0_sb2_book_editors_suite/testing_function/testing_config1.json")
        self.editor_config = self.config.load_for_editor("accent_editor")
        
    def get_current_settings(self):
        return {
            'tts_mode': self.editor_config.get('TTS_MODE'),
            'accents_file': self.editor_config.get('ACCENTS_FILE'),
            'bookmark': self.config.get_bookmark('accent_editor')
        }
    
    def save_position(self, cursor_pos, scroll_y):
        self.config.update_bookmark('accent_editor', cursor_pos, scroll_y)