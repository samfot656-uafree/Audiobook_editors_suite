from book_editors_suite.core.config_manager import get_config_manager

class YourEditor:
    def __init__(self):
        self.config = get_config_manager("/path/to/config.json")
        self.editor_config = self.config.load_for_editor("your_editor_name")