# Створіть порожні файли для майбутніх модулів
#touch /storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite/core/tts_manager.py
#touch /storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite/core/text_processor.py
#touch /storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite/core/file_manager.py