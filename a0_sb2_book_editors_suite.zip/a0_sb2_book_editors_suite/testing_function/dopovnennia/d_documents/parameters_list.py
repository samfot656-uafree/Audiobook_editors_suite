#---------------common_params-------
 self.common_params = {
            'params': [
                'CONFIG_VERSION',
                'INPUT_TEXT_FILE',
                'OUTPUT_FOLDER',
              
            ],
            'defaults': {
                'CONFIG_VERSION': '0_0_0_2',
                'INPUT_TEXT_FILE': '/storage/emulated/0/Documents/pidgotovka_knigi/txt/Чекаючий.1.1.Шлях_до_заснування.S-t-i-k-s.txt',
                'OUTPUT_FOLDER': '/storage/emulated/0/Documents/pidgotovka_knigi/txt',


#---------------accent_editor-------

'params': [
                    'ACCENTS_FILE',
                    'OUTPUT_MP3_FOLDER', 
                    'TTS_MODE', 
                    'DO_SPLIT',
                    'BOOKMARK'
                ],
                'defaults': {
                    'TTS_MODE': 'gTTS', 
                    'DO_SPLIT': False,
                    'ACCENTS_FILE': '/storage/emulated/0/Documents/pidgotovka_knigi/jsons/accents_probl.json',
                    'OUTPUT_MP3_FOLDER': '/storage/emulated/0/Documents/pidgotovka_knigi/output_mp3',
                    'BOOKMARK': {'cursor': 0, 'scroll': 0.0}
                    




            
#-----------voice_tags_editor----------------            
            'voice_tags_editor': {
                'params': [
                    'voice_dict', 
                    'pause_dict',
                    'TAGS_EDITOR_SCROLL_Y', 
                    'TAGS_EDITOR_CURSOR_POS',
                    'RTG_BOOKMARK',
                    'PAUSE_4_mp3',
                    'PAUSE_7_mp3', 
                    'PAUSE_1_mp3', 
                    'PAUSE_2_mp3',
                    'BOOKMARK'
                ],
                'defaults': {
                    'voice_dict': {
                        "g1": "Розповідач", 
                        "g2": "Чоловік1", 
                        "g3": "Чоловік2",
                        "g4": "Жінка1", 
                        "g5": "Жінка2", 
                        "g6": "Хлопець",
                        "g7": "Дівчина", 
                        "g8": "Думки чол", 
                        "g9": "Думки жін"
                    },
                    'pause_dict': {
                        "P4": "PAUSE_4", 
                        "P7": "PAUSE_7", 
                        "P1": "PAUSE_1", 
                        "P2": "PAUSE_2"
                    },
                    'TAGS_EDITOR_SCROLL_Y': 1.0,
                    'TAGS_EDITOR_CURSOR_POS': 0,
                    'RTG_BOOKMARK': {'cursor': 0, 'scroll': 1.0},
                    'BOOKMARK': {'cursor': 0, 'scroll': 0.0}
                }
            },
            
#-----------sound_effects_editor----------------           
            'sound_effects_editor': {
                'params': [
                    'SOUNDS_EFFECTS_LIST', 
                    'SOUNDS_EFFECTS_FILES',
                    'SOUNDS_EFFECTS_INPUT_FOLDER',
                    'sound_dict',
                    'BOOKMARK'
                ],
                'defaults': {
                    'sound_dict': {
                        "S1": "Звук_пострілу_part_022",                        
                        "S2": "Машина_гальмує_part_027", 
                        "S3": "Гарчання_мутанта1_part_047"
                    },
                    'SOUNDS_EFFECTS_LIST': '/storage/emulated/0/Documents/pidgotovka_knigi/jsons/scenarios_ozvuch_c4.json',
                    'SOUNDS_EFFECTS_FILES': '/storage/emulated/0/Documents/pidgotovka_knigi/jsons/sounds_effect_files_dict.json',
                    'SOUNDS_EFFECTS_INPUT_FOLDER': '/storage/emulated/0/Documents/pidgotovka_knigi/input_sounds_effects',
                    'BOOKMARK': {'cursor': 0, 'scroll': 0.0}
                }
            },
            
#-----------multispeaker_tts----------------            
            'multispeaker_tts': {
                'params': [
                    'INPUT_SOUNDS_FOLDER',
                    'FRAGMENT_SOFT_LIMIT',
                    'FRAGMENT_HARD_LIMIT', 
                    'DO_SPLIT',
                    'DO_MERGE',
                    'PAUSE_4_mp3',
                    'PAUSE_7_mp3',
                    'PAUSE_1_mp3',
                    'PAUSE_2_mp3',
                    'PAUSE_4_wav',
                    'PAUSE_7_wav',
                    'PAUSE_1_wav',
                    'PAUSE_2_wav',
                    'MELODY_START_mp3',
                    'MELODY_END_mp3', 
                    'MELODY_START_wav', 
                    'MELODY_END_wav',
                    'TEST_wav', 
                    'voice_dict', 
                    'pause_dict', 
                    'sound_dict', 
                    'TTS_MODE',
                    'BOOKMARK'
                ],
                'defaults': {
                    'FRAGMENT_SOFT_LIMIT': 900,
                    'FRAGMENT_HARD_LIMIT': 1000,
                    'DO_SPLIT': True,
                    'DO_MERGE': False,
                    'TTS_MODE': 'TFile',
                    'INPUT_SOUNDS_FOLDER': '/storage/emulated/0/Documents/pidgotovka_knigi/input_melodu',
                    'voice_dict': {
                        "g1": "Розповідач", 
                        "g2": "Чоловік1", 
                        "g3": "Чоловік2",
                        "g4": "Жінка1", 
                        "g5": "Жінка2", 
                        "g6": "Хлопець",
                        "g7": "Дівчина", 
                        "g8": "Думки чол", 
                        "g9": "Думки жін"
                    },
                    'pause_dict': {
                        "P4": "PAUSE_4", 
                        "P7": "PAUSE_7", 
                        "P1": "PAUSE_1", 
                        "P2": "PAUSE_2"
                    },
                    'sound_dict': {
                        "S1": "Звук_пострілу_part_022",
                        "S2": "Машина_гальмує_part_027", 
                        "S3": "Гарчання_мутанта1_part_047"
                    },
                    'BOOKMARK': {'cursor': 0, 'scroll': 0.0}
                }
            }
        }
        
#---------------color tems-------

                    edit_input.cursor_color = (0.03, 0.85, 0.53 ,1)
                    edit_input.background_color
                    'BATT_25' : (1, 0.2, 0.2, 1)
                    'BATT_30' : (1, 0.6, 0.6, 1)'
                

#---------------common_params-------



#---------------common_params-------











