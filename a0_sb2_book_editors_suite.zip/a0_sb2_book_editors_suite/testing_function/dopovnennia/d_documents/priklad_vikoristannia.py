# Тепер можна імпортувати зручними способами:

# Спосіб 1: Прямий імпорт з головного пакету
from book_editors_suite import ModularConfigManager, get_config_manager

# Спосіб 2: Імпорт з конкретного модуля
from book_editors_suite.core import ModularConfigManager
from book_editors_suite.editors.accent_editor import AccentEditor

# Спосіб 3: Повний імпорт пакету
import book_editors_suite as bes

config = bes.get_config_manager("/path/to/config.json")
editor = bes.AccentEditor()# Тепер можна імпортувати зручними способами:

# Спосіб 1: Прямий імпорт з головного пакету
from book_editors_suite import ModularConfigManager, get_config_manager

# Спосіб 2: Імпорт з конкретного модуля
from book_editors_suite.core import ModularConfigManager
from book_editors_suite.editors.accent_editor import AccentEditor

# Спосіб 3: Повний імпорт пакету
import book_editors_suite as bes

config = bes.get_config_manager("/path/to/config.json")
editor = bes.AccentEditor()