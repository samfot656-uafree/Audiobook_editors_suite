/storage/emulated/0/a0_sb2_book_editors_suite/
├── book_editors_suite/
│   ├── __init__.py
│   ├── core/
│   │   ├── __init__.py
│   │   └── config_manager.py
│   ├── editors/
│   │   ├── accent_editor/
│   │   ├── voice_tags_editor/
│   │   ├── sound_effects_editor/
│   │   └── multispeaker_tts/
│   ├── ui/
│   └── utils/
└── testing_function/
    └── test_config_manager.py  # <-- цей файл