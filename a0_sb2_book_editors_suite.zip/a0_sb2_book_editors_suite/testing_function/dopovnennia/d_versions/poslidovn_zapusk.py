#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Скрипт для запуску всього workflow послідовно
"""

import sys
from pathlib import Path

sys.path.append('/storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite')
from core.config_manager import get_config_manager, WorkflowStage

def run_workflow(project_config_path: str):
    """Запускає весь workflow послідовно"""
    config_manager = get_config_manager(project_config_path, auto_create=True)
    
    editors = {
        WorkflowStage.ACCENTS: "accent_editor",
        WorkflowStage.VOICE_TAGS: "voice_tags_editor", 
        WorkflowStage.SOUND_EFFECTS: "sound_effects_editor",
        WorkflowStage.MULTISPEAKER_TTS: "multispeaker_tts"
    }
    
    for stage, editor_name in editors.items():
        current_stage = config_manager.get_current_stage()
        if current_stage != stage:
            print(f"⏭️  Пропускаємо {editor_name}, поточний етап: {current_stage.value}")
            continue
            
        print(f"\n🎬 Запускаємо {editor_name}...")
        
        # Завантажуємо конфіг для поточного редактора
        config = config_manager.load_for_editor(editor_name)
        
        # Тут запускаємо відповідний редактор
        # run_editor(editor_name, config)
        
        print(f"✅ {editor_name} завершено")
        
        # Переходимо до наступного етапу
        if not config_manager.advance_to_next_stage():
            print("🏁 Workflow завершено!")
            break

if __name__ == '__main__':
    project_config_path = sys.argv[1] if len(sys.argv) > 1 else None
    if not project_config_path:
        project_name = "Чекаючий_1_1_Шлях_до_заснування"
        project_config_path = f"/storage/emulated/0/projects/{project_name}/{project_name}_config.json"
    
    run_workflow(project_config_path)