# -*- coding: utf-8 -*-
# Стабільна базова версія редактора наголосів

import sys
import os
from pathlib import Path

sys.path.insert(0, '/storage/emulated/0/a0_sb2_book_editors_suite')
sys.path.insert(0, '/storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite')

from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.popup import Popup
from kivy.uix.label import Label
from kivy.core.window import Window
from kivy.clock import Clock

from book_editors_suite.core.config_manager import get_config_manager
from book_editors_suite.core.tts_manager import TTSManager
from book_editors_suite.core.file_manager import FileManager
from book_editors_suite.core.text_processor import TextProcessor
from book_editors_suite.core.logging_manager import LoggingManager
from book_editors_suite.ui.popups.edit_word_popup import EditWordPopup
from book_editors_suite.ui.popups.extra_buttons_popup import ExtraButtonsPopup
from book_editors_suite.ui.themes import ThemeManager
from book_editors_suite.utils.helpers import WORD_RE

class AccentEditorApp(App):
    """Стабільна версія редактора наголосів"""

    def __init__(self, book_project_name: str, input_text_file: str = None, **kwargs):
        super().__init__(**kwargs)
        self.book_project_name = book_project_name
        self.input_text_file = input_text_file
        self.app_name = "accent_editor"
        
        # === ВЛАСТИВОСТІ ===
        self.config_manager = None
        self.config = {}
        self.accents = {}
        self.text_for_correction = []
        self.fixed_text = []
        self.current_idx = -1
        self.selected_word = None
        self.tts_manager = None
        self.file_manager = None
        self.text_processor = None
        self.logger = None
        self.theme_manager = None
        
        # Закладка
        self.current_scroll_y = 0.0
        self.current_cursor_pos = 0
        self.current_paragraph_index = 0

    def build(self):
        """Побудова інтерфейсу"""
        self._init_managers()
        Window.softinput_mode = "below_target"
        return self._build_interface()

    def _init_managers(self):
        """Ініціалізація менеджерів"""
        try:
            self.config_manager = get_config_manager(
                book_project_name=self.book_project_name,
                input_text_file=self.input_text_file
            )
            self.config = self.config_manager.load_for_editor('accent_editor')
            project_info = self.config_manager.get_project_info()
            
            self.logger = LoggingManager(
                log_dir=project_info['base_path'] + f"/{self.book_project_name}/temp_folder/logs",
                app_name="accent_editor"
            )
            self.file_manager = FileManager(self.config_manager, 'accent_editor', self.logger)
            self.text_processor = TextProcessor(self.logger)
            self.tts_manager = TTSManager()
            self.theme_manager = ThemeManager()
            
            self.accents = self.file_manager.load_accents()
            self.logger.info("Менеджери ініціалізовані")
            
        except Exception as e:
            self.show_popup("Помилка", f"Помилка ініціалізації:\n{e}")

    def _build_interface(self):
        """Побудова інтерфейсу"""
        # Налаштування розмірів
        bbtn_font_size = self.config_manager.get_common_param('BBTN_FONT_SIZE', 38)
        text_widget_font_size = self.config_manager.get_common_param('TEXT_WIDGET_FONT_SIZE', 56)
        bbtn_height = self.config_manager.get_common_param('BBTN_HEIGHT', 120)
            
        root = BoxLayout(orientation='vertical', spacing=8, padding=22)

        # === ВЕРХНІЙ РЯД КНОПОК ===
        top_row = BoxLayout(orientation='horizontal', size_hint_y=None, height=bbtn_height, spacing=8)
        self.btn_listen = Button(text="Слухати", font_size=bbtn_font_size)
        self.btn_pause = Button(text="Пауза", font_size=bbtn_font_size)
        self.btn_edit = Button(text="Правити", font_size=bbtn_font_size, disabled=True)
        self.btn_next = Button(text="Наступний", font_size=bbtn_font_size)
        self.btn_extra = Button(text="  . . .  ", font_size=bbtn_font_size)
        
        for btn in (self.btn_listen, self.btn_pause, self.btn_edit, self.btn_next, self.btn_extra):
            top_row.add_widget(btn)

        # === ТЕКСТОВЕ ПОЛЕ ===
        self.text_input = TextInput(font_size=text_widget_font_size, multiline=True)
        self.text_input.bind(on_touch_down=self.on_text_touch)

        # Додавання до інтерфейсу
        root.add_widget(top_row)
        root.add_widget(self.text_input)
        self._bind_events()

        # Автоматичні дії
        Clock.schedule_once(lambda *_: self.open_and_prepare_text(), 0.1)
        Clock.schedule_once(lambda *_: self.apply_theme(), 0)
        Clock.schedule_once(lambda *_: self.restore_bookmark(), 0.2)

        return root

    def _bind_events(self):
        """Прив'язка подій до кнопок"""
        self.btn_listen.bind(on_press=lambda *_: self.listen_current_paragraph())
        self.btn_pause.bind(on_press=lambda *_: self.stop_tts())
        self.btn_edit.bind(on_press=self.open_edit_popup)
        self.btn_next.bind(on_press=lambda *_: self.go_next_paragraph())
        self.btn_extra.bind(on_press=lambda *_: ExtraButtonsPopup(main_app=self, editor_name=self.app_name).open())

    # === МЕТОДИ РОБОТИ З ТЕКСТОМ ===

    def open_and_prepare_text(self):
        """Завантажує текст і відновлює закладку"""
        try:
            raw_text = self.file_manager.load_input_text()
            if raw_text is None:
                self.logger.warning("Текст не знайдено")
                return

            # Обробка тексту
            accented_text = self.text_processor.add_accents_to_text(raw_text, self.accents)
            paragraphs = accented_text.split("\n")
            self.text_for_correction = paragraphs
            self.fixed_text = []

            # Відновлення закладки
            self.restore_bookmark()
            target_index = self.current_paragraph_index

            # Додаємо абзаци до закладки
            for i in range(target_index):
                self.fixed_text.append(self.text_for_correction[i])

            # Пропускаємо порожні абзаци
            while (target_index < len(paragraphs) and not paragraphs[target_index].strip()):
                self.fixed_text.append("")
                target_index += 1

            # Встановлюємо поточний абзац
            if target_index < len(paragraphs):
                self.text_input.text = paragraphs[target_index]
                self.current_paragraph_index = target_index
            else:
                self.text_input.text = ""
                self.current_paragraph_index = len(paragraphs)

            # Оновлюємо кнопку
            total_paragraphs = len(paragraphs)
            self.btn_extra.text = f"   . . .   \n{self.current_paragraph_index+1}/{total_paragraphs}"
            self.clear_selection_state()

        except Exception as e:
            self.logger.error(f"Помилка підготовки тексту: {e}")
            self.show_popup("Помилка", f"Не вдалося підготувати текст:\n{e}")

    def go_next_paragraph(self):
        """Перехід до наступного абзацу"""
        self.stop_tts()

        # Зберігаємо поточний абзац
        current_text = self.text_input.text
        if self.current_paragraph_index < len(self.text_for_correction):
            self.fixed_text.append(current_text)
            self.current_paragraph_index += 1
            
            # Пропускаємо порожні абзаци
            while (self.current_paragraph_index < len(self.text_for_correction) and 
                   not self.text_for_correction[self.current_paragraph_index].strip()):
                self.fixed_text.append("")
                self.current_paragraph_index += 1

            # Встановлюємо наступний абзац
            if self.current_paragraph_index < len(self.text_for_correction):
                self.text_input.text = self.text_for_correction[self.current_paragraph_index]
            else:
                self.text_input.text = ""
                self.show_popup("Кінець", "Досягнуто кінця тексту")
        else:
            self.logger.warning("Немає більше абзаців")

        # Оновлюємо інтерфейс
        self.btn_extra.text = f"   . . .   \n{self.current_paragraph_index+1}/{len(self.text_for_correction)}"
        self.move_bookmark()
        self.clear_selection_state()

    def build_full_text(self) -> str:
        """Побудова повного тексту"""
        parts = []
        parts.extend(self.fixed_text)
        
        if self.current_paragraph_index < len(self.text_for_correction):
            parts.append(self.text_input.text)
            if self.current_paragraph_index + 1 < len(self.text_for_correction):
                parts.extend(self.text_for_correction[self.current_paragraph_index + 1:])
        
        return "\n".join(parts)

    # === МЕТОДИ РОБОТИ З ЗАКЛАДКАМИ ===

    def move_bookmark(self):
        """Оновлює закладку у властивостях класу"""
        try:
            if self.text_input:
                self.current_cursor_pos = self.text_input.cursor_index()
                self.current_scroll_y = self.text_input.scroll_y
        except Exception as e:
            self.logger.error(f"Помилка оновлення закладки: {e}")

    def save_bookmark(self):
        """Зберігає закладку в конфіг"""
        try:
            if hasattr(self, 'config_manager'):
                self.config_manager.update_bookmark(
                    'accent_editor', 
                    self.current_cursor_pos, 
                    self.current_scroll_y,
                    self.current_paragraph_index
                )
        except Exception as e:
            self.logger.error(f"Помилка збереження закладки: {e}")

    def restore_bookmark(self):
        """Відновлює закладку з конфігу"""
        try:
            if hasattr(self, 'config_manager'):
                bookmark = self.config_manager.get_bookmark('accent_editor')
                if bookmark:
                    self.current_scroll_y = bookmark.get('scroll_y', 0.0)
                    self.current_cursor_pos = bookmark.get('cursor_pos', 0)
                    self.current_paragraph_index = bookmark.get('paragraph_index', 0)
        except Exception as e:
            self.logger.error(f"Помилка відновлення закладки: {e}")

    # === МЕТОДИ РОБОТИ З ВИДІЛЕННЯМ СЛІВ ===

    def on_text_touch(self, instance, touch):
        """Обробка торкання текстового поля"""
        if not instance.collide_point(*touch.pos):
            return False
        Clock.schedule_once(lambda *_: self.detect_word_at_cursor(), 0.01)
        return False

    def detect_word_at_cursor(self):
        """Визначення слова під курсором"""
        try:
            cursor_idx = self.text_input.cursor_index()
        except Exception as e:
            self.clear_selection_state()
            return

        text = self.text_input.text
        if not text:
            self.clear_selection_state()
            return

        # Знаходимо межі слова
        start = cursor_idx
        while start > 0 and self.is_word_char(text[start - 1]):
            start -= 1

        end = cursor_idx
        while end < len(text) and self.is_word_char(text[end]):
            end += 1

        word = text[start:end]
        if WORD_RE.fullmatch(word):
            self.selected_word = word
            self.btn_edit.disabled = False
        else:
            self.clear_selection_state()

    def is_word_char(self, char: str) -> bool:
        """Перевірка чи символ є частиною слова"""
        return char.isalpha() or char == '\u0301' or char == "'"

    def clear_selection_state(self):
        """Очищення виділення"""
        self.selected_word = None
        self.btn_edit.disabled = True

    def open_edit_popup(self, *_):
        """Відкриття попапу редагування слова"""
        if self.selected_word:
            self.stop_tts()
            EditWordPopup(self, self.selected_word, self.app_name).open()

    def replace_word_in_current_paragraph(self, old_word: str, new_word: str):
        """Заміна слова в поточному абзаці"""
        if self.current_paragraph_index < 0:
            return
            
        current_text = self.text_input.text
        replaced_text = current_text.replace(old_word, new_word, 1)
        self.text_input.text = replaced_text

    # === TTS МЕТОДИ ===

    def listen_current_paragraph(self):
        """Відтворення поточного абзацу"""
        text = self.text_input.text.strip()
        if text:
            self.tts_manager.safe_tts_speak(text)

    def stop_tts(self):
        """Зупинка TTS"""
        if self.tts_manager:
            self.tts_manager.stop_tts()

    # === МЕТОДИ ЗБЕРЕЖЕННЯ ===

    def save_full_text(self):
        """Збереження повного тексту"""
        self.stop_tts()
        content = self.build_full_text()
        success = self.file_manager.save_output_text(content)
        self.save_bookmark()
        
        if success:
            self.logger.info("Текст успішно збережено")
        else:
            self.logger.error("Помилка збереження тексту")

    def save_full_mp3(self):
        """Збереження тексту в MP3"""
        self.stop_tts()
        content = self.build_full_text().strip()
        if not content:
            self.show_popup("Помилка", "Текст порожній")
            return

        try:
            project_info = self.config_manager.get_project_info()
            project_name = project_info['project_name']
            project_path = project_info['base_path'] + f"/{project_name}"
            
            mp3_folder = f"{project_path}/outputs/output_mp3"
            os.makedirs(mp3_folder, exist_ok=True)
            
            out_f_path = f"{mp3_folder}/{project_name}.mp3"
            
            from gtts import gTTS
            tts = gTTS(text=content, lang="uk")
            tts.save(out_f_path)
            
            self.show_popup("MP3 збережено", f"MP3 збережено:\n{out_f_path}")
            
        except Exception as e:
            self.show_popup("Помилка gTTS", f"Помилка конвертації: {str(e)}")

    # === ТЕМА ІНТЕРФЕЙСУ ===

    def get_theme_colors(self):
        """Отримання кольорів теми"""
        return self.theme_manager.get_colors()

    def apply_theme(self):
        """Застосування теми"""
        try:
            widgets_dict = {
                'buttons': [self.btn_listen, self.btn_pause, self.btn_edit, self.btn_next, self.btn_extra],
                'text_inputs': [self.text_input],
                'window': Window
            }
            self.theme_manager.apply_theme_to_widgets(widgets_dict)
        except Exception as e:
            self.logger.error(f"Помилка застосування теми: {e}")

    def toggle_theme(self):
        """Перемикання теми"""
        self.stop_tts()
        self.theme_manager.toggle_theme()
        self.apply_theme()

    # === УТИЛІТИ ===

    def show_popup(self, title: str, message: str):
        """Показ спливаючого повідомлення"""
        popup = Popup(title=title, content=Label(text=message), size_hint=(0.8, 0.4))
        popup.open()

    def on_stop(self):
        """Дія при закритті додатку"""
        self.save_bookmark()
        self.stop_tts()
        self.logger.info("Редактор наголосів закрито")

# === ЗАПУСК ===
if __name__ == "__main__":
    input_text_file = "/storage/emulated/0/Documents/Inp_txt/Чекаючий_1_1.txt"
    book_project_name = "Чекаючий_1_1"
    
    app = AccentEditorApp(
        book_project_name=book_project_name,
        input_text_file=input_text_file
    )
    app.run()