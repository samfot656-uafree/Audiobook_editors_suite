#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Скрипт для моніторингу прогресу всіх проектів
"""

import sys
from pathlib import Path
from datetime import datetime

sys.path.append('/storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite')
from core.config_manager import get_config_manager

def monitor_projects():
    """Моніторить всі проекти і показує статус"""
    base_path = "/storage/emulated/0/projects"
    projects_path = Path(base_path)
    
    if not projects_path.exists():
        print("📁 Папка проектів не знайдена")
        return
    
    projects = [d for d in projects_path.iterdir() if d.is_dir()]
    
    print(f"\n📊 Моніторинг проектів ({len(projects)} знайдено):")
    print("=" * 80)
    
    for project_dir in projects:
        config_path = project_dir / f"{project_dir.name}_config.json"
        
        if config_path.exists():
            try:
                config_manager = get_config_manager(str(config_path), auto_create=False)
                project_info = config_manager.get_project_info()
                progress_stats = config_manager.get_progress_stats()
                
                print(f"\n📂 Проект: {project_info.get('project_name', project_dir.name)}")
                print(f"🔄 Статус: {project_info.get('status', 'unknown')}")
                print(f"🎯 Поточний етап: {progress_stats.get('current_stage', 'unknown')}")
                print(f"📈 Прогрес: {progress_stats.get('stage_progress', {})}")
                print(f"⏱️  Остання активність: {progress_stats.get('last_activity', 'немає даних')}")
                print(f"📅 Заплановане завершення: {progress_stats.get('estimated_completion', 'не визначено')}")
                
            except Exception as e:
                print(f"\n❌ Помилка читання проекту {project_dir.name}: {e}")
    
    print("\n" + "=" * 80)

if __name__ == '__main__':
    monitor_projects()