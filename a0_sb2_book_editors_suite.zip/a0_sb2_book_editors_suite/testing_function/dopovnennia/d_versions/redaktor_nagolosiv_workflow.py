#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Редактор наголосів - перший етап workflow
Завжди запускається першим для додавання наголосів
"""

import sys
from pathlib import Path

sys.path.append('/storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite')
from core.config_manager import get_config_manager, WorkflowStage

def main():
    # Отримуємо шлях до проекту
    if len(sys.argv) > 1:
        project_config_path = sys.argv[1]
    else:
        # Створюємо/використовуємо проект за замовчуванням
        project_name = "Чекаючий_1_1_Шлях_до_заснування"
        project_config_path = f"/storage/emulated/0/projects/{project_name}/{project_name}_config.json"
    
    # Ініціалізуємо конфіг менеджер
    config_manager = get_config_manager(project_config_path, auto_create=True)
    
    # Перевіряємо, що ми на правильному етапі
    current_stage = config_manager.get_current_stage()
    if current_stage != WorkflowStage.ACCENTS:
        print(f"⚠️  Увага: поточний етап - {current_stage.value}, але редактор наголосів завжди починає workflow!")
        print("📋 Використовується текст з поточного етапу")
    
    # Отримуємо інформацію про проект
    project_info = config_manager.get_current_project_info()
    print(f"📂 Проект: {project_info['name']}")
    print(f"🎯 Поточний етап: {project_info['current_stage']}")
    print(f"📊 Прогрес: {project_info['progress']}%")
    
    # Завантажуємо конфіг для редактора наголосів
    config = config_manager.load_for_editor('accent_editor')
    
    print(f"📄 Робочий текст: {config.get('CURRENT_TEXT_FILE', '')}")
    print(f"🎵 Режим TTS: {config.get('TTS_MODE')}")
    
    # Тут запускаємо GUI редактора наголосів...
    # accent_editor_gui = AccentEditorGUI(config)
    # accent_editor_gui.run()
    
    # Після завершення роботи переходимо до наступного етапу
    if input("\nПерейти до наступного етапу (редактор голосів)? (y/n): ").lower() == 'y':
        if config_manager.advance_to_next_stage():
            print("✅ Успішно перейшли до редактора голосів!")
        else:
            print("❌ Не вдалося перейти до наступного етапу")

if __name__ == '__main__':
    main()