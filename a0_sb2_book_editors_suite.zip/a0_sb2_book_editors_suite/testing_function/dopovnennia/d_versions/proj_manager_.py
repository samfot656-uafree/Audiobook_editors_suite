import os
import shutil
import json
from pathlib import Path

class ProjectManager:
    """Менеджер для створення структури проекту"""
    
    @staticmethod
    def create_project_structure(project_name, input_text_path=None, config_template=None, base_path="/storage/emulated/0/projects"):
        """
        Створює структуру проекту з усіма необхідними папками та файлами
        
        Args:
            project_name (str): Назва проекту
            input_text_path (str, optional): Шлях до вихідного текстового файлу
            config_template (dict, optional): Шаблон конфігурації
            base_path (str): Базова папка для проектів
            
        Returns:
            str: Шлях до конфігураційного файлу проекту
        """
        # Створюємо основні шляхи
        project_path = f"{base_path}/{project_name}"
        text_file_path = f"{project_path}/{project_name}.txt"
        config_file_path = f"{project_path}/{project_name}_config.json"
        
        # Створюємо структуру папок
        folders = [
            project_path,
            f"{project_path}/outputs",
            f"{project_path}/temp",
            f"{project_path}/temp/input_sound"
        ]
        
        for folder in folders:
            os.makedirs(folder, exist_ok=True)
            print(f"Створено папку: {folder}")
        
        # Копіюємо/створюємо текстовий файл
        if input_text_path and os.path.exists(input_text_path):
            shutil.copy2(input_text_path, text_file_path)
            print(f"Скопійовано текстовий файл: {text_file_path}")
        else:
            # Створюємо порожній текстовий файл
            with open(text_file_path, 'w', encoding='utf-8') as f:
                f.write("# Вхідний текст проекту\n\n")
            print(f"Створено порожній текстовий файл: {text_file_path}")
        
        # Створюємо конфігураційний файл
        config = ProjectManager.create_project_config(project_path, project_name, config_template)
        
        with open(config_file_path, 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        
        print(f"Створено конфігураційний файл: {config_file_path}")
        print(f"Структура проекту '{project_name}' успішно створена!")
        
        return config_file_path
    
    @staticmethod
    def create_project_config(project_path, project_name, config_template=None):
        """
        Створює конфігурацію проекту з правильними шляхами
        
        Args:
            project_path (str): Шлях до проекту
            project_name (str): Назва проекту
            config_template (dict, optional): Базовий шаблон конфігурації
            
        Returns:
            dict: Конфігурація проекту
        """
        base_path = f"{project_path}/{project_name}"
        
        # Базова конфігурація
        config = {
            "COMMON_CONFIG_VERSION": "0_0_0_2",
            "COMMON_TEXT_WIDGET_FONT_SIZE": 56,
            "COMMON_BBTN_FONT_SIZE": 38,
            "COMMON_BBTN_HEIGHT": 120,
            "COMMON_ACCENT_CHAR": "́",
            "COMMON_INPUT_TEXT_FILE": f"{base_path}.txt",
            "COMMON_OUTPUT_FOLDER": f"{base_path}/outputs",
            "COMMON_TEMP_FOLDER": f"{base_path}/temp",
            "COMMON_VOICE_DICT": {
                "G1": "Розповідач",
                "G2": "Чоловік1", 
                "G3": "Чоловік2",
                "G4": "Жінка1",
                "G5": "Жінка2",
                "G6": "Хлопець",
                "G7": "Дівчина",
                "G8": "Думки чол",
                "G9": "Думки жін"
            },
            "COMMON_PAUSE_DICT": {
                "P4": "PAUSE_4",
                "P7": "PAUSE_7", 
                "P1": "PAUSE_1",
                "P2": "PAUSE_2"
            },
            "ACCENT_EDITOR_ACCENTS_FILE": f"{base_path}/accents.json",
            "ACCENT_EDITOR_OUTPUT_MP3_FOLDER": f"{base_path}/outputs",
            "ACCENT_EDITOR_TTS_MODE": "gTTS",
            "ACCENT_EDITOR_DO_SPLIT": False,
            "ACCENT_EDITOR_BOOKMARK": {
                "cursor": 0,
                "scroll": 0.0,
                "paragraph_index": 0
            },
            # Інші параметри можна додати за потреби
        }
        
        # Додаємо кастомні налаштування з шаблону
        if config_template:
            config.update(config_template)
        
        return config

    @staticmethod
    def list_projects(base_path="/storage/emulated/0/projects"):
        """
        Показує список існуючих проектів
        
        Args:
            base_path (str): Базова папка проектів
            
        Returns:
            list: Список назв проектів
        """
        if not os.path.exists(base_path):
            return []
        
        projects = [d for d in os.listdir(base_path) 
                   if os.path.isdir(os.path.join(base_path, d))]
        return sorted(projects)

    @staticmethod
    def validate_project_structure(project_name, base_path="/storage/emulated/0/projects"):
        """
        Перевіряє коректність структури проекту
        
        Args:
            project_name (str): Назва проекту
            base_path (str): Базова папка проектів
            
        Returns:
            tuple: (bool, list) - Статус валідації та список проблем
        """
        project_path = f"{base_path}/{project_name}"
        problems = []
        
        required_files = [
            f"{project_path}/{project_name}.txt",
            f"{project_path}/{project_name}_config.json"
        ]
        
        required_folders = [
            f"{project_path}/outputs",
            f"{project_path}/temp/input_sound"
        ]
        
        for file_path in required_files:
            if not os.path.exists(file_path):
                problems.append(f"Відсутній файл: {file_path}")
        
        for folder_path in required_folders:
            if not os.path.exists(folder_path):
                problems.append(f"Відсутня папка: {folder_path}")
        
        return len(problems) == 0, problems


# Приклад використання
def main():
    # Створення нового проекту
    project_name = "Чекаючий_1_1_Шлях_до_заснування"
    
    # Опціонально: шлях до існуючого текстового файлу
    input_text_path = "/storage/emulated/0/Documents/pidgotovka_knigi/txt/Чекаючий.1.1.Шлях_до_заснування.S-t-i-k-s.txt"
    
    # Опціонально: кастомний шаблон конфігурації
    custom_config = {
        "COMMON_TEXT_WIDGET_FONT_SIZE": 48,
        "ACCENT_EDITOR_TTS_MODE": "TFile"
    }
    
    # Створюємо проект
    config_path = ProjectManager.create_project_structure(
        project_name=project_name,
        input_text_path=input_text_path,
        config_template=custom_config
    )
    
    print(f"Конфіг створено: {config_path}")
    
    # Перевіряємо структуру
    is_valid, problems = ProjectManager.validate_project_structure(project_name)
    if is_valid:
        print("Структура проекту валідна!")
    else:
        print("Проблеми з структурою проекту:")
        for problem in problems:
            print(f" - {problem}")
    
    # Показуємо список проектів
    projects = ProjectManager.list_projects()
    print(f"Доступні проекти: {projects}")
    
    return config_path


# Інтеграція з основним додатком
def start_app_with_project(project_name, create_if_missing=True):
    """
    Запускає додаток з указаним проектом
    
    Args:
        project_name (str): Назва проекту
        create_if_missing (bool): Створювати проект, якщо не існує
    """
    base_path = "/storage/emulated/0/projects"
    config_path = f"{base_path}/{project_name}/{project_name}_config.json"
    
    # Перевіряємо чи існує проект
    if not os.path.exists(config_path) and create_if_missing:
        print(f"Проект '{project_name}' не знайдено, створюємо...")
        config_path = ProjectManager.create_project_structure(project_name)
    
    if os.path.exists(config_path):
        # Запускаємо додаток
        app = AccentEditorApp(config_path)
        app.run()
    else:
        print(f"Помилка: проект '{project_name}' не існує")


# Якщо використовуємо як окремий модуль
if __name__ == "__main__":
    # Тестуємо створення проекту
    config_path = main()
    
    # Можна одразу запустити додаток
    # start_app_with_project("Чекаючий_1_1_Шлях_до_заснування")