# -*- coding: utf-8 -*-

"""
Попап з додатковими кнопками для редактора наголосів.
"""
from kivy.uix.popup import Popup
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.clock import Clock
from kivy.uix.gridlayout import GridLayout


class ExtraButtonsPopup(Popup):
    """Попап з додатковими функціями редактора."""
    
    def __init__(self, main_app, editor_name, **kwargs):
        super().__init__(**kwargs)
        self.main_app = main_app
        self.editor_name = editor_name  # Додаємо збереження імені редактора
        self.title = "Додаткові кнопки"
        self.size_hint = (0.95, 0.6)
        self.auto_dismiss = True
        
        self._build_interface()
        Clock.schedule_once(lambda *_: self.apply_theme_from_app(), 0)

    def _build_interface(self):
        """Побудова інтерфейсу попапу з горизонтальним розташуванням кнопок."""
        # Отримуємо налаштування з конфігурації через data атрибут
        config_data = self.main_app.config_manager.data  # Використовуємо data атрибут замість get_config()
        bbtn_font_size = config_data.get('BBTN_FONT_SIZE', 42)
        bbtn_height = config_data.get('BBTN_HEIGHT', 120)
        self.editor_name = "voice_tags_editor"
      
        # Основний контейнер
        root = BoxLayout(orientation='vertical', spacing=8, padding=8)

#        # Горизонтальний ряд кнопок зверху
#        btn_row = BoxLayout(
#            size_hint_y=None, 
#            height=bbtn_height, 
#            spacing=8
#        )
         # Горизонтальна сітка кнопок зверху
        btn_grid = GridLayout(cols=2, size_hint_y=None, height=3*(8+bbtn_height), spacing=8)

# список кнопок залежить від self.editor_name
        
        if self.editor_name == "accent_editor":
        	# Створюємо кнопки
        	self.btn_save_txt = Button(text="До txt", font_size=bbtn_font_size)
        	self.btn_save_mp3 = Button(text="До mp3", font_size=bbtn_font_size)
        	self.btn_theme = Button(text="День-ніч", font_size=bbtn_font_size)
        	self.btn_sort_dict = Button(text="Сортуй", font_size=bbtn_font_size)
        	self.btn_bookmark_start = Button(text="Закладку на початок", font_size=bbtn_font_size)
        	self.btn_back = Button(text="Назад", font_size=bbtn_font_size)
        	# Додаємо кнопки до сітки
        	for btn in (self.btn_save_txt, self.btn_save_mp3, self.btn_theme, self.btn_sort_dict, self.btn_bookmark_start, self.btn_back):
        		btn_grid.add_widget(btn)
        	
        	self.extra_button_list = (self.btn_save_txt, self.btn_save_mp3, self.btn_theme, self.btn_sort_dict, self.btn_bookmark_start, self.btn_back)
        
        elif self.editor_name == "voice_tags_editor":
        	# Створюємо кнопки
        	self.btn_save_txt = Button(text="До txt", font_size=bbtn_font_size)

        	self.btn_theme = Button(text="День-ніч", font_size=bbtn_font_size)
 
        	self.btn_bookmark_start = Button(text="Закладку на початок", font_size=bbtn_font_size)
        	self.btn_back = Button(text="Повернутися", font_size=bbtn_font_size)
        	# Додаємо кнопки до сітки
        	for btn in (self.btn_save_txt, self.btn_theme, self.btn_bookmark_start, self.btn_back):
        		btn_grid.add_widget(btn)
        	
        	self.extra_button_list = (self.btn_save_txt,  self.btn_theme, self.btn_bookmark_start, self.btn_back)
        
        # Додаємо сітку кнопок до основного контейнера
        root.add_widget(btn_grid)
        # Label без тексту (порожній простір під кнопками)
        root.add_widget(Label())
        self.content = root
        	# Прив'язка кнопок
        self.btn_save_txt.bind(on_press=self.on_save_txt)
        if self.editor_name == "accent_editor":
        	self.btn_save_mp3.bind(on_press=self.on_save_mp3)
        	self.btn_sort_dict.bind(on_press=self.on_sort_dict)
        self.btn_theme.bind(on_press=self.on_toggle_theme)
        
        self.btn_bookmark_start.bind(on_press=self.on_bookmark_start)
        self.btn_back.bind(on_press=lambda *_: self.dismiss())

    def apply_theme_from_app(self):
        """Застосовує тему з головного додатку."""
        colors = self.main_app.get_theme_colors()
#        for b in (self.btn_save_txt, self.btn_save_mp3, self.btn_theme, 
#                 self.btn_sort_dict, self.btn_bookmark_start, self.btn_back):
#        
        for b in self.extra_button_list:
            b.background_normal = ""
            b.background_color = colors["button_bg"]
            b.color = colors["button_fg"]

    def on_save_txt(self, *_):
        """Зберігає текст у txt файл."""
        try:
            self.main_app.save_full_text()
            # Додаткове повідомлення для користувача
            Popup(
                title="Збереження", 
                content=Label(text=f"Збережено TXT:\n"), 
                size_hint=(0.8, 0.3)
            ).open()
            self.dismiss()
        except Exception as e:
            if hasattr(self.main_app, 'logger'):
                self.main_app.logger.error(f"❌ Помилка збереження txt: {e}")
            # Додаткове повідомлення для користувача
            Popup(
                title="Помилка збереження", 
                content=Label(text=f"Не вдалося зберегти TXT:\n{e}"), 
                size_hint=(0.8, 0.3)
            ).open()

    def on_save_mp3(self, *_):
        """Зберігає текст у mp3 файл."""
        try:
            self.main_app.save_full_mp3()
            self.dismiss()
        except Exception as e:
            if hasattr(self.main_app, 'logger'):
                self.main_app.logger.error(f"❌ Помилка збереження mp3: {e}")
            # Додаткове повідомлення для користувача
            Popup(
                title="Помилка збереження", 
                content=Label(text=f"Не вдалося зберегти MP3:\n{e}"), 
                size_hint=(0.8, 0.3)
            ).open()

    def on_toggle_theme(self, *_):
        """Перемикає тему."""
        try:
            self.main_app.toggle_theme()
            self.dismiss()
        except Exception as e:
            if hasattr(self.main_app, 'logger'):
                self.main_app.logger.error(f"❌ Помилка перемикання теми: {e}")

    def on_sort_dict(self, *_):
        """Сортує словник наголосів."""
        try:
            # Перевіряємо, чи є словник наголосів у поточному редакторі
            if hasattr(self.main_app, 'accents'):
                self.main_app.accents = dict(sorted(self.main_app.accents.items()))
                self.main_app.save_accents()
                
                # Повідомлення про успішне сортування
                Popup(
                    title="Словник", 
                    content=Label(text="Словник відсортовано"), 
                    size_hint=(0.7, 0.3)
                ).open()
            else:
                Popup(
                    title="Помилка", 
                    content=Label(text="Цей редактор не має словника для сортування"), 
                    size_hint=(0.7, 0.3)
                ).open()
            
        except Exception as e:
            if hasattr(self.main_app, 'logger'):
                self.main_app.logger.error(f"❌ Помилка сортування словника: {e}")
            Popup(
                title="Помилка сортування", 
                content=Label(text=f"Не вдалося відсортувати словник:\n{e}"), 
                size_hint=(0.8, 0.3)
            ).open()

    def on_bookmark_start(self, *_):
        """Встановлює закладку на початок тексту."""
        try:
            # Викликаємо метод конфіг менеджера для оновлення закладки з усіма параметрами
            self.main_app.config_manager.update_bookmark(
                editor_name=self.editor_name,
                cursor_pos=0,
                scroll_y=0.0,
                paragraph_index=0
            )
            
            # Оновлюємо поточні значення в головному додатку
            self.main_app.current_cursor_pos = 0
            self.main_app.current_scroll_y = 0.0
            self.main_app.current_paragraph_index = 0
            self.main_app.current_idx = 0
            
            # Встановлюємо текст першого абзацу
            if self.main_app.text_for_correction:
                self.main_app.text_input.text = self.main_app.text_for_correction[0]
                self.main_app.text_input.cursor = (0, 0)
                self.main_app.text_input.scroll_y = 0.0
            
            if hasattr(self.main_app, 'logger'):
                self.main_app.logger.info(f"🔖 Закладку встановлено на початок тексту для {self.editor_name}")
            
            # Повідомлення про успішне встановлення закладки
            Popup(
                title="Закладка", 
                content=Label(text=f"Закладку для {self.editor_name} встановлено на початок тексту"), 
                size_hint=(0.7, 0.3)
            ).open()
                
        except Exception as e:
            if hasattr(self.main_app, 'logger'):
                self.main_app.logger.error(f"❌ Помилка встановлення закладки для {self.editor_name}: {e}")
            Popup(
                title="Помилка закладки", 
                content=Label(text=f"Не вдалося встановити закладку:\n{e}"), 
                size_hint=(0.8, 0.3)
            ).open()