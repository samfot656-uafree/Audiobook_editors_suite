"""
/storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite/core/config_manager.py

Менеджер конфігурації з підтримкою тривалої роботи над проектом.
Кожен редактор працює тижнями, потім передає текст наступному.
"""

import json
import re
import os
import logging
import shutil
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple
from enum import Enum
from datetime import datetime, timedelta
import hashlib

class WorkflowStage(Enum):
    """Етапи workflow з підтримкою тривалої роботи"""
    ACCENTS = "accent_editor"
    VOICE_TAGS = "voice_tags_editor" 
    SOUND_EFFECTS = "sound_effects_editor"
    MULTISPEAKER_TTS = "multispeaker_tts"
    FINAL = "final"

class ProjectStatus(Enum):
    """Статуси проекту"""
    DRAFT = "draft"
    IN_PROGRESS = "in_progress"
    PAUSED = "paused"
    COMPLETED = "completed"
    ARCHIVED = "archived"

class ProjectManager:
    """Менеджер проектів з підтримкою тривалої роботи"""
    
    # Розширена структура для тривалої роботи
    PROJECT_STRUCTURE = {
        "folders": [
            "outputs",
            "temp/input_sound",
            "temp/input_melodu",
            "workflow/accent_editor/backups",
            "workflow/voice_tags_editor/backups", 
            "workflow/sound_effects_editor/backups",
            "workflow/multispeaker_tts/backups",
            "logs",
            "exports"
        ],
        "files": {
            # Основні файли
            "input_text": "{project_name}.txt",
            "config": "{project_name}_config.json",
            "project_info": "project_info.json",
            
            # Workflow файли (кожен редактор має свій робочий файл)
            "accented_text": "workflow/accent_editor/{project_name}_with_accents.txt",
            "voice_tags_text": "workflow/voice_tags_editor/{project_name}_with_voice_tags.txt",
            "sound_effects_text": "workflow/sound_effects_editor/{project_name}_with_sound_effects.txt",
            "final_text": "workflow/multispeaker_tts/{project_name}_final.txt",
            
            # JSON файли
            "accents_json": "workflow/accent_editor/accents.json",
            "scenarios_json": "workflow/sound_effects_editor/scenarios_ozvuch.json",
            "sounds_dict_json": "workflow/sound_effects_editor/sounds_effect_files_dict.json",
            
            # Статусні файли
            "progress_tracker": "progress_tracker.json"
        }
    }

    @staticmethod
    def create_project_structure(project_name: str, source_config: Dict[str, Any] = None,
                               input_text_path: str = None, 
                               base_path: str = "/storage/emulated/0/projects") -> str:
        """
        Створює повну структуру проекту для тривалої роботи
        """
        project_path = Path(base_path) / project_name
        
        # Створюємо структуру папок
        for folder in ProjectManager.PROJECT_STRUCTURE["folders"]:
            folder_path = project_path / folder
            folder_path.mkdir(parents=True, exist_ok=True)
            print(f"📁 Створено папку: {folder_path}")

        # Копіюємо/створюємо текстовий файл
        input_text_file = project_path / ProjectManager.PROJECT_STRUCTURE["files"]["input_text"].format(project_name=project_name)
        if input_text_path and Path(input_text_path).exists():
            shutil.copy2(input_text_path, input_text_file)
            print(f"📄 Скопійовано текст: {input_text_file}")
        else:
            input_text_file.write_text("# Вхідний текст проекту\n\n", encoding="utf-8")
            print(f"📄 Створено текстовий файл: {input_text_file}")

        # Створюємо workflow файли (копіюємо текст на кожен етап)
        for file_key in ["accented_text", "voice_tags_text", "sound_effects_text", "final_text"]:
            file_path = project_path / ProjectManager.PROJECT_STRUCTURE["files"][file_key].format(project_name=project_name)
            if input_text_file.exists():
                shutil.copy2(input_text_file, file_path)
                print(f"🔗 Створено workflow файл: {file_path}")

        # Копіюємо необхідні звукові файли
        copied_files = ProjectManager._copy_required_files(source_config, str(project_path))

        # Створюємо конфігурацію
        config = ProjectManager.create_project_config(str(project_path), project_name, copied_files)
        config_file = project_path / ProjectManager.PROJECT_STRUCTURE["files"]["config"].format(project_name=project_name)
        
        with open(config_file, 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)

        # Створюємо інформацію про проект
        project_info = ProjectManager._create_project_info(project_name, input_text_path)
        project_info_file = project_path / ProjectManager.PROJECT_STRUCTURE["files"]["project_info"]
        with open(project_info_file, 'w', encoding='utf-8') as f:
            json.dump(project_info, f, ensure_ascii=False, indent=2)

        # Створюємо трекер прогресу
        progress_tracker = ProjectManager._create_progress_tracker()
        progress_file = project_path / ProjectManager.PROJECT_STRUCTURE["files"]["progress_tracker"]
        with open(progress_file, 'w', encoding='utf-8') as f:
            json.dump(progress_tracker, f, ensure_ascii=False, indent=2)

        print(f"⚙️ Створено конфіг: {config_file}")
        print(f"✅ Проект '{project_name}' готовий до тривалої роботи!")
        
        return str(config_file)

    @staticmethod
    def _create_project_info(project_name: str, input_text_path: str = None) -> Dict[str, Any]:
        """Створює інформацію про проект для тривалої роботи"""
        creation_date = datetime.now().isoformat()
        
        # Оцінюємо приблизний час роботи (на основі досвіду)
        estimated_times = {
            "accent_editor": "1-3 тижні",
            "voice_tags_editor": "1-2 тижні", 
            "sound_effects_editor": "3-7 днів",
            "multispeaker_tts": "2-5 днів"
        }
        
        return {
            "project_name": project_name,
            "created_date": creation_date,
            "last_modified": creation_date,
            "status": ProjectStatus.DRAFT.value,
            "current_stage": WorkflowStage.ACCENTS.value,
            "estimated_times": estimated_times,
            "source_text": input_text_path or "",
            "total_work_days": 0,
            "work_sessions": [],
            "notes": "",
            "version": "1.0"
        }

    @staticmethod
    def _create_progress_tracker() -> Dict[str, Any]:
        """Створює трекер прогресу для кожного етапу"""
        return {
            "accent_editor": {
                "status": "not_started",
                "start_date": None,
                "end_date": None,
                "last_work_date": None,
                "total_work_hours": 0,
                "progress_percent": 0,
                "last_position": {"cursor": 0, "paragraph": 0},
                "backups": []
            },
            "voice_tags_editor": {
                "status": "not_started", 
                "start_date": None,
                "end_date": None,
                "last_work_date": None,
                "total_work_hours": 0,
                "progress_percent": 0,
                "last_position": {"cursor": 0, "paragraph": 0},
                "backups": []
            },
            "sound_effects_editor": {
                "status": "not_started",
                "start_date": None,
                "end_date": None, 
                "last_work_date": None,
                "total_work_hours": 0,
                "progress_percent": 0,
                "last_position": {"cursor": 0, "paragraph": 0},
                "backups": []
            },
            "multispeaker_tts": {
                "status": "not_started",
                "start_date": None,
                "end_date": None,
                "last_work_hours": 0,
                "progress_percent": 0,
                "audio_files_generated": 0,
                "backups": []
            }
        }

    @staticmethod
    def update_progress(project_path: str, editor_name: str, progress_data: Dict[str, Any]):
        """Оновлює прогрес роботи редактора"""
        progress_file = Path(project_path) / ProjectManager.PROJECT_STRUCTURE["files"]["progress_tracker"]
        
        if progress_file.exists():
            with open(progress_file, 'r', encoding='utf-8') as f:
                progress = json.load(f)
            
            if editor_name in progress:
                progress[editor_name].update(progress_data)
                progress[editor_name]["last_work_date"] = datetime.now().isoformat()
                
                with open(progress_file, 'w', encoding='utf-8') as f:
                    json.dump(progress, f, ensure_ascii=False, indent=2)

    @staticmethod
    def create_backup(project_path: str, editor_name: str, backup_reason: str = "manual"):
        """Створює backup файлу редактора"""
        try:
            project_name = Path(project_path).name
            source_file = Path(project_path) / f"workflow/{editor_name}/{project_name}_{editor_name}.txt"
            backup_folder = Path(project_path) / f"workflow/{editor_name}/backups"
            
            if source_file.exists():
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                backup_file = backup_folder / f"{project_name}_{editor_name}_{timestamp}_{backup_reason}.txt"
                
                shutil.copy2(source_file, backup_file)
                
                # Оновлюємо список backup'ів у прогрессі
                progress_file = Path(project_path) / ProjectManager.PROJECT_STRUCTURE["files"]["progress_tracker"]
                if progress_file.exists():
                    with open(progress_file, 'r', encoding='utf-8') as f:
                        progress = json.load(f)
                    
                    if editor_name in progress:
                        backup_info = {
                            "file": str(backup_file),
                            "timestamp": datetime.now().isoformat(),
                            "reason": backup_reason,
                            "size": source_file.stat().st_size
                        }
                        progress[editor_name]["backups"].append(backup_info)
                        
                        # Зберігаємо тільки останні 10 backup'ів
                        if len(progress[editor_name]["backups"]) > 10:
                            progress[editor_name]["backups"] = progress[editor_name]["backups"][-10:]
                        
                        with open(progress_file, 'w', encoding='utf-8') as f:
                            json.dump(progress, f, ensure_ascii=False, indent=2)
                
                return str(backup_file)
        except Exception as e:
            print(f"❌ Помилка створення backup: {e}")
        
        return None

    @staticmethod
    def get_work_session_stats(project_path: str) -> Dict[str, Any]:
        """Повертає статистику робочих сесій"""
        progress_file = Path(project_path) / ProjectManager.PROJECT_STRUCTURE["files"]["progress_tracker"]
        
        if progress_file.exists():
            with open(progress_file, 'r', encoding='utf-8') as f:
                progress = json.load(f)
            
            stats = {
                "total_work_hours": 0,
                "current_stage": "",
                "stage_progress": {},
                "last_activity": None,
                "estimated_completion": None
            }
            
            latest_date = None
            for editor, data in progress.items():
                stats["total_work_hours"] += data.get("total_work_hours", 0)
                stats["stage_progress"][editor] = data.get("progress_percent", 0)
                
                last_work = data.get("last_work_date")
                if last_work:
                    last_dt = datetime.fromisoformat(last_work)
                    if not latest_date or last_dt > latest_date:
                        latest_date = last_dt
                        stats["current_stage"] = editor
            
            if latest_date:
                stats["last_activity"] = latest_date.isoformat()
                # Приблизна дата завершення (на основі середньої продуктивності)
                remaining_hours = (100 - stats["stage_progress"].get(stats["current_stage"], 0)) * 2  # Припущення: 2 години на 1%
                if remaining_hours > 0:
                    completion_date = latest_date + timedelta(hours=remaining_hours)
                    stats["estimated_completion"] = completion_date.isoformat()
            
            return stats
        
        return {}

    @staticmethod
    def transfer_to_next_stage(project_path: str, current_editor: str, force: bool = False) -> bool:
        """
        Передає роботу наступному редактору після завершення поточного
        
        Args:
            project_path: Шлях до проекту
            current_editor: Поточний редактор, що завершив роботу
            force: Примусово передати, навіть якщо наступний редактор вже працював
        
        Returns:
            bool: Успішність передачі
        """
        try:
            project_name = Path(project_path).name
            editors_sequence = ["accent_editor", "voice_tags_editor", "sound_effects_editor", "multispeaker_tts"]
            
            if current_editor not in editors_sequence:
                return False
            
            current_index = editors_sequence.index(current_editor)
            if current_index >= len(editors_sequence) - 1:
                print("🎉 Останній етап завершено!")
                return True
            
            next_editor = editors_sequence[current_index + 1]
            
            # Шляхи до файлів
            current_file = Path(project_path) / f"workflow/{current_editor}/{project_name}_{current_editor}.txt"
            next_file = Path(project_path) / f"workflow/{next_editor}/{project_name}_{next_editor}.txt"
            
            if not current_file.exists():
                print(f"❌ Поточний файл не знайдено: {current_file}")
                return False
            
            # Перевіряємо, чи наступний редактор вже почав роботу
            if next_file.exists() and not force:
                print(f"⚠️  {next_editor} вже почав роботу. Використовуйте force=True для перезапису")
                return False
            
            # Копіюємо файл
            shutil.copy2(current_file, next_file)
            
            # Оновлюємо прогрес
            progress_file = Path(project_path) / ProjectManager.PROJECT_STRUCTURE["files"]["progress_tracker"]
            if progress_file.exists():
                with open(progress_file, 'r', encoding='utf-8') as f:
                    progress = json.load(f)
                
                # Завершуємо поточний етап
                progress[current_editor]["status"] = "completed"
                progress[current_editor]["end_date"] = datetime.now().isoformat()
                progress[current_editor]["progress_percent"] = 100
                
                # Починаємо наступний етап
                progress[next_editor]["status"] = "in_progress" 
                progress[next_editor]["start_date"] = datetime.now().isoformat()
                
                with open(progress_file, 'w', encoding='utf-8') as f:
                    json.dump(progress, f, ensure_ascii=False, indent=2)
            
            # Оновлюємо інформацію про проект
            ProjectManager._update_project_info(project_path, next_editor)
            
            print(f"✅ Успішно передано з {current_editor} до {next_editor}")
            return True
            
        except Exception as e:
            print(f"❌ Помилка передачі: {e}")
            return False

    @staticmethod
    def _update_project_info(project_path: str, current_editor: str):
        """Оновлює інформацію про проект"""
        project_info_file = Path(project_path) / ProjectManager.PROJECT_STRUCTURE["files"]["project_info"]
        
        if project_info_file.exists():
            with open(project_info_file, 'r', encoding='utf-8') as f:
                project_info = json.load(f)
            
            project_info["current_stage"] = current_editor
            project_info["last_modified"] = datetime.now().isoformat()
            project_info["status"] = ProjectStatus.IN_PROGRESS.value
            
            with open(project_info_file, 'w', encoding='utf-8') as f:
                json.dump(project_info, f, ensure_ascii=False, indent=2)

    # ... (інші методи залишаються аналогічними, але з покращеннями для тривалої роботи)


class ModularConfigManager:
    """
    Менеджер конфігурації з розширеною підтримкою тривалої роботи
    """

    def __init__(self, config_path: str = None, auto_create: bool = True):
        self.config_file = Path(config_path) if config_path else None
        self.data = {}
        self.project_manager = ProjectManager()
        self.current_workflow_stage = WorkflowStage.ACCENTS
        
        # Налаштування логування
        self.logger = self._setup_logging()

        # Ініціалізація параметрів
        self.common_params = {
            'params': ['CONFIG_VERSION', 'TEXT_WIDGET_FONT_SIZE', 'BBTN_FONT_SIZE', 'BBTN_HEIGHT', 
                      'ACCENT_CHAR', 'INPUT_TEXT_FILE', 'OUTPUT_FOLDER', 'TEMP_FOLDER', 
                      'VOICE_DICT', 'PAUSE_DICT'],
            'defaults': {
                'CONFIG_VERSION': '0_0_0_2',
                'TEXT_WIDGET_FONT_SIZE': 56,
                'BBTN_FONT_SIZE': 38,
                'BBTN_HEIGHT': 120,
                'ACCENT_CHAR': '\u0301',
                'INPUT_TEXT_FILE': '',
                'OUTPUT_FOLDER': '',
                'TEMP_FOLDER': '',
                'VOICE_DICT': {
                    "G1": "Розповідач", "G2": "Чоловік1", "G3": "Чоловік2",
                    "G4": "Жінка1", "G5": "Жінка2", "G6": "Хлопець",
                    "G7": "Дівчина", "G8": "Думки чол", "G9": "Думки жін"
                },
                'PAUSE_DICT': {
                    "P4": "PAUSE_4", "P7": "PAUSE_7", "P1": "PAUSE_1", "P2": "PAUSE_2"
                },
            }
        }
        
        # Особисті параметри редакторів
        self.editor_registry = {
            'accent_editor': {
                'params': ['ACCENTS_FILE', 'OUTPUT_MP3_FOLDER', 'TTS_MODE', 'DO_SPLIT', 'BOOKMARK', 'CURRENT_TEXT_FILE'],
                'defaults': {
                    'ACCENTS_FILE': '', 'OUTPUT_MP3_FOLDER': '', 'TTS_MODE': 'gTTS', 
                    'DO_SPLIT': False, 'BOOKMARK': {'cursor': 0, 'scroll': 0.0, 'paragraph_index': 0},
                    'CURRENT_TEXT_FILE': ''
                }
            },
            'voice_tags_editor': {
                'params': ['PAUSE_4_MP3', 'PAUSE_7_MP3', 'PAUSE_1_MP3', 'PAUSE_2_MP3',
                          'PAUSE_4_WAV', 'PAUSE_7_WAV', 'PAUSE_1_WAV', 'PAUSE_2_WAV',
                          'MELODY_START_MP3', 'MELODY_END_MP3', 'MELODY_START_WAV', 
                          'MELODY_END_WAV', 'TEST_WAV', 'BOOKMARK', 'CURRENT_TEXT_FILE'],
                'defaults': {
                    'PAUSE_4_MP3': '', 'PAUSE_7_MP3': '', 'PAUSE_1_MP3': '', 'PAUSE_2_MP3': '',
                    'PAUSE_4_WAV': '', 'PAUSE_7_WAV': '', 'PAUSE_1_WAV': '', 'PAUSE_2_WAV': '',
                    'MELODY_START_MP3': '', 'MELODY_END_MP3': '', 'MELODY_START_WAV': '',
                    'MELODY_END_WAV': '', 'TEST_WAV': '', 
                    'BOOKMARK': {'cursor': 0, 'scroll': 0.0, 'paragraph_index': 0},
                    'CURRENT_TEXT_FILE': ''
                }
            },
            'sound_effects_editor': {
                'params': ['SOUNDS_EFFECTS_LIST', 'SOUNDS_EFFECTS_FILES', 'SOUNDS_EFFECTS_INPUT_FOLDER',
                          'SOUND_DICT', 'BOOKMARK', 'CURRENT_TEXT_FILE'],
                'defaults': {
                    'SOUND_DICT': {
                        "S1": "Звук_пострілу_part_022", "S2": "Машина_гальмує_part_027", 
                        "S3": "Гарчання_мутанта1_part_047"
                    },
                    'SOUNDS_EFFECTS_LIST': '', 'SOUNDS_EFFECTS_FILES': '', 
                    'SOUNDS_EFFECTS_INPUT_FOLDER': '',
                    'BOOKMARK': {'cursor': 0, 'scroll': 0.0, 'paragraph_index': 0},
                    'CURRENT_TEXT_FILE': ''
                }
            },
            'multispeaker_tts': {
                'params': ['INPUT_SOUNDS_FOLDER', 'FRAGMENT_SOFT_LIMIT', 'FRAGMENT_HARD_LIMIT', 
                          'DO_SPLIT', 'DO_MERGE', 'TTS_MODE', 'SOUND_DICT', 'BOOKMARK', 'CURRENT_TEXT_FILE'],
                'defaults': {
                    'INPUT_SOUNDS_FOLDER': '', 'FRAGMENT_SOFT_LIMIT': 900, 'FRAGMENT_HARD_LIMIT': 1000,
                    'DO_SPLIT': True, 'DO_MERGE': False, 'TTS_MODE': 'TFile',
                    'SOUND_DICT': {
                        "S1": "Звук_пострілу_part_022", "S2": "Машина_гальмує_part_027", 
                        "S3": "Гарчання_мутанта1_part_047"
                    },
                    'BOOKMARK': {'cursor': 0, 'scroll': 0.0, 'paragraph_index': 0},
                    'CURRENT_TEXT_FILE': ''
                }
            }
        }
        
        # Автоматичне створення проекту
        if auto_create and config_path:
            self._auto_create_project_structure()

    def _auto_create_project_structure(self):
        """Автоматично створює структуру проекту для тривалої роботи"""
        try:
            if not self.config_file.exists():
                self.logger.info("Автоматичне створення структури проекту для тривалої роботи...")
                
                project_name = self.config_file.parent.name
                base_path = self.config_file.parent.parent
                
                # Завантажуємо вихідний конфіг для копіювання файлів
                source_config = self._load_source_config()
                
                # Створюємо проект
                new_config_path = self.project_manager.create_project_structure(
                    project_name=project_name,
                    source_config=source_config,
                    base_path=str(base_path)
                )
                
                self.config_file = Path(new_config_path)
            
            # Завантажуємо конфіг
            self.load_full_config()
            
            # Встановлюємо поточний етап з інформації про проект
            project_info = self.get_project_info()
            current_stage_name = project_info.get('current_stage', 'accent_editor')
            self.current_workflow_stage = WorkflowStage(current_stage_name)
            
        except Exception as e:
            self.logger.error(f"Помилка створення проекту: {e}")

    # ===========================
    # Розширені методи для тривалої роботи
    # ===========================

    def get_project_info(self) -> Dict[str, Any]:
        """Повертає детальну інформацію про проект"""
        if not self.config_file.exists():
            return {}
        
        project_info_file = self.config_file.parent / ProjectManager.PROJECT_STRUCTURE["files"]["project_info"]
        if project_info_file.exists():
            with open(project_info_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        
        return {}

    def get_progress_stats(self) -> Dict[str, Any]:
        """Повертає детальну статистику прогресу"""
        if not self.config_file.exists():
            return {}
        
        return self.project_manager.get_work_session_stats(str(self.config_file.parent))

    def update_editor_progress(self, editor_name: str, progress_data: Dict[str, Any]):
        """Оновлює прогрес конкретного редактора"""
        if not self.config_file.exists():
            return
        
        self.project_manager.update_progress(str(self.config_file.parent), editor_name, progress_data)

    def create_editor_backup(self, editor_name: str, reason: str = "manual") -> str:
        """Створює backup для редактора"""
        if not self.config_file.exists():
            return ""
        
        return self.project_manager.create_backup(str(self.config_file.parent), editor_name, reason) or ""

    def transfer_to_next_editor(self, current_editor: str, force: bool = False) -> bool:
        """Передає роботу наступному редактору"""
        if not self.config_file.exists():
            return False
        
        success = self.project_manager.transfer_to_next_stage(
            str(self.config_file.parent), current_editor, force
        )
        
        if success:
            # Оновлюємо поточний етап
            project_info = self.get_project_info()
            current_stage_name = project_info.get('current_stage', 'accent_editor')
            self.current_workflow_stage = WorkflowStage(current_stage_name)
            
            self.logger.info(f"Передано роботу від {current_editor} до {current_stage_name}")
        
        return success

    def get_work_recommendations(self) -> Dict[str, Any]:
        """Повертає рекомендації для роботи на основі статистики"""
        stats = self.get_progress_stats()
        project_info = self.get_project_info()
        
        recommendations = {
            "current_focus": f"Зосередьтеся на {self.current_workflow_stage.value}",
            "estimated_completion": stats.get('estimated_completion'),
            "suggested_work_hours": "2-4 години на сесію",
            "backup_advice": "Створіть backup перед довгою перервою",
            "next_steps": []
        }
        
        # Додаємо специфічні рекомендації для поточного етапу
        if self.current_workflow_stage == WorkflowStage.ACCENTS:
            recommendations["next_steps"] = [
                "Перевірте наголоси в складних словах",
                "Зберіть список проблемних слів для майбутніх проектів"
            ]
        elif self.current_workflow_stage == WorkflowStage.VOICE_TAGS:
            recommendations["next_steps"] = [
                "Переконайтеся, що всі персонажі мають теги голосів",
                "Додайте паузи для природності мовлення"
            ]
        
        return recommendations

    def get_editor_session_summary(self, editor_name: str) -> Dict[str, Any]:
        """Повертає зведення по робочій сесії редактора"""
        progress_file = self.config_file.parent / ProjectManager.PROJECT_STRUCTURE["files"]["progress_tracker"]
        
        if progress_file.exists():
            with open(progress_file, 'r', encoding='utf-8') as f:
                progress = json.load(f)
            
            if editor_name in progress:
                editor_data = progress[editor_name]
                return {
                    "status": editor_data.get("status", "unknown"),
                    "progress": editor_data.get("progress_percent", 0),
                    "work_hours": editor_data.get("total_work_hours", 0),
                    "last_work": editor_data.get("last_work_date"),
                    "backups_count": len(editor_data.get("backups", [])),
                    "current_position": editor_data.get("last_position", {})
                }
        
        return {}

    # ... (інші методи залишаються аналогічними)

# Синглтон
_global_config_manager = None

def get_config_manager(config_path: str = None, auto_create: bool = True) -> ModularConfigManager:
    global _global_config_manager
    if _global_config_manager is None and config_path:
        _global_config_manager = ModularConfigManager(config_path, auto_create)
    return _global_config_manager

def reset_config_manager():
    global _global_config_manager
    _global_config_manager = None

__all__ = ['ModularConfigManager', 'ProjectManager', 'WorkflowStage', 'ProjectStatus', 
           'get_config_manager', 'reset_config_manager']