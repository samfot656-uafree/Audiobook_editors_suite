#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Скрипт для створення нової книги
"""

import sys
from pathlib import Path

sys.path.append('/storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite')
from core.simple_config_manager import create_new_book

def create_book():
    """Створює нову книгу"""
    if len(sys.argv) > 1:
        book_name = sys.argv[1]
    else:
        book_name = input("Введіть назву нової книги: ")
    
    original_text = None
    if len(sys.argv) > 2:
        original_text = sys.argv[2]
    else:
        text_input = input("Шлях до оригінального тексту (Enter - створити пустий): ").strip()
        if text_input:
            original_text = text_input
    
    try:
        config_manager = create_new_book(book_name, original_text)
        print(f"✅ Книга '{book_name}' успішно створена!")
        
        project_info = config_manager.get_project_info()
        print(f"📁 Папка проекту: {config_manager.config_file.parent}")
        print(f"🎯 Початок роботи з: {project_info.get('current_stage')}")
        
    except Exception as e:
        print(f"❌ Помилка створення книги: {e}")

if __name__ == '__main__':
    create_book()