#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Редактор наголосів - підтримка тривалої роботи (тижні/місяці)
"""

import sys
from pathlib import Path
from datetime import datetime

sys.path.append('/storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite')
from core.config_manager import get_config_manager, WorkflowStage

class LongTermAccentEditor:
    def __init__(self, config_path: str):
        self.config_manager = get_config_manager(config_path, auto_create=True)
        self.project_info = self.config_manager.get_project_info()
        self.progress_stats = self.config_manager.get_progress_stats()
        
    def start_work_session(self):
        """Початок робочої сесії"""
        print(f"\n🎯 Початок роботи над проектом: {self.project_info['project_name']}")
        print(f"📊 Поточний прогрес: {self.progress_stats.get('stage_progress', {}).get('accent_editor', 0)}%")
        print(f"⏱️  Загальний час роботи: {self.progress_stats.get('total_work_hours', 0)} годин")
        
        # Оновлюємо статус
        self.config_manager.update_editor_progress('accent_editor', {
            "status": "in_progress",
            "last_work_date": datetime.now().isoformat()
        })
        
    def save_progress(self, cursor_pos: int, paragraph: int, progress_percent: int):
        """Зберігає прогрес роботи"""
        progress_data = {
            "progress_percent": progress_percent,
            "last_position": {"cursor": cursor_pos, "paragraph": paragraph},
            "last_work_date": datetime.now().isoformat()
        }
        
        self.config_manager.update_editor_progress('accent_editor', progress_data)
        print(f"💾 Збережено прогрес: {progress_percent}%")
        
    def create_backup(self, reason: str = "session_end"):
        """Створює backup"""
        backup_path = self.config_manager.create_editor_backup('accent_editor', reason)
        if backup_path:
            print(f"📦 Створено backup: {Path(backup_path).name}")
        
    def complete_stage(self):
        """Завершує етап і передає наступному редактору"""
        # Створюємо фінальний backup
        self.create_backup("stage_complete")
        
        # Оновлюємо прогрес до 100%
        self.save_progress(0, 0, 100)
        
        # Передаємо наступному редактору
        if self.config_manager.transfer_to_next_editor('accent_editor'):
            print("✅ Етап наголосів завершено! Передано редактору голосів.")
        else:
            print("⚠️  Не вдалося автоматично передати роботу. Зробіть це вручну.")
            
    def show_recommendations(self):
        """Показує рекомендації для роботи"""
        recommendations = self.config_manager.get_work_recommendations()
        print("\n💡 Рекомендації для роботи:")
        print(f"Фокус: {recommendations['current_focus']}")
        for step in recommendations.get('next_steps', []):
            print(f"• {step}")

def main():
    # Отримуємо шлях до проекту
    if len(sys.argv) > 1:
        project_config_path = sys.argv[1]
    else:
        project_name = "Чекаючий_1_1_Шлях_до_заснування"
        project_config_path = f"/storage/emulated/0/projects/{project_name}/{project_name}_config.json"
    
    # Ініціалізуємо редактор
    editor = LongTermAccentEditor(project_config_path)
    editor.start_work_session()
    editor.show_recommendations()
    
    # Тут буде основний цикл роботи редактора...
    # Наприклад, GUI або консольний інтерфейс
    
    # Приклад роботи:
    try:
        # Симуляція роботи
        input("\n⏎ Натисніть Enter для симуляції роботи...")
        
        # Зберігаємо прогрес
        editor.save_progress(cursor_pos=1500, paragraph=45, progress_percent=65)
        
        # Створюємо backup
        editor.create_backup("manual_save")
        
        # Перевіряємо статистику
        session_summary = editor.config_manager.get_editor_session_summary('accent_editor')
        print(f"\n📈 Зведення сесії: {session_summary}")
        
        # Запитуємо чи завершити етап
        if input("\nЗавершити етап наголосів? (y/n): ").lower() == 'y':
            editor.complete_stage()
        else:
            print("Продовжуйте роботу! Не забувайте зберігати прогрес.")
            
    except KeyboardInterrupt:
        print("\n\n⏸️  Сесію перервано. Прогрес збережено.")
        editor.create_backup("session_interrupted")

if __name__ == '__main__':
    main()