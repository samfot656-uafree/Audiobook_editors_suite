#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Редактор голосів та пауз
"""

import sys
from pathlib import Path

sys.path.append('/storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite')
from core.simple_config_manager import set_current_book, get_current_book

def main():
    if len(sys.argv) > 1:
        book_name = sys.argv[1]
    else:
        book_name = "Чекаючий_1_1_Шлях_до_заснування"
    
    config_manager = set_current_book(book_name)
    project_info = config_manager.get_project_info()
    current_stage = config_manager.get_current_stage()
    
    print(f"📚 Книга: {project_info.get('name', book_name)}")
    print(f"🎯 Поточний етап: {current_stage}")
    
    # Завантажуємо конфіг для редактора голосів
    editor_config = config_manager.get_editor_config("voice_tags_editor")
    
    print(f"📄 Робочий файл: {editor_config.get('current_file')}")
    print(f"🎙️  Словник голосів: {list(editor_config.get('voice_dict', {}).keys())}")
    
    if current_stage != "voice_tags_editor":
        print(f"⚠️  Увага: зараз має працювати {current_stage}")
        response = input("Продовжити роботу? (y/n): ")
        if response.lower() != 'y':
            return
    
    print("\n🔧 Редактор голосів та пауз готовий до роботи...")
    
    # Симуляція роботи
    input("Натисніть Enter для симуляції роботи...")
    
    # Оновлюємо закладку
    config_manager.update_bookmark("voice_tags_editor", cursor=5678, paragraph=89, scroll=0.42)
    
    response = input("\nЗавершити роботу з голосами та перейти до звукових ефектів? (y/n): ")
    if response.lower() == 'y':
        next_stage = config_manager.advance_to_next_stage()
        print(f"✅ Перейшли до етапу: {next_stage}")
        config_manager.create_backup("voice_editor_complete")

if __name__ == '__main__':
    main()