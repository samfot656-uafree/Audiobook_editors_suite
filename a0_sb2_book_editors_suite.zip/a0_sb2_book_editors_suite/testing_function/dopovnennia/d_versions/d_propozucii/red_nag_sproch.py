#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Простий редактор наголосів для одного користувача
"""

import sys
from pathlib import Path

sys.path.append('/storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite')
from core.simple_config_manager import set_current_book, get_current_book

def main():
    # Назва книги (можна передати як аргумент)
    if len(sys.argv) > 1:
        book_name = sys.argv[1]
    else:
        book_name = "Чекаючий_1_1_Шлях_до_заснування"
    
    # Встановлюємо поточну книгу
    config_manager = set_current_book(book_name)
    
    # Отримуємо інформацію про проект
    project_info = config_manager.get_project_info()
    current_stage = config_manager.get_current_stage()
    
    print(f"📚 Книга: {project_info.get('name', book_name)}")
    print(f"🎯 Поточний етап: {current_stage}")
    print(f"📅 Створено: {project_info.get('created_date', 'невідомо')}")
    
    # Завантажуємо конфіг для редактора наголосів
    editor_config = config_manager.get_editor_config("accent_editor")
    
    print(f"📄 Робочий файл: {editor_config.get('current_file')}")
    print(f"📍 Закладка: {editor_config.get('bookmark', {})}")
    
    # Перевіряємо, чи ми на правильному етапі
    if current_stage != "accent_editor":
        print(f"⚠️  Увага: зараз має працювати {current_stage}, але ви запустили редактор наголосів")
        response = input("Продовжити роботу? (y/n): ")
        if response.lower() != 'y':
            return
    
    # Тут починається робота редактора наголосів...
    # accent_editor = AccentEditor(editor_config)
    # accent_editor.run()
    
    # Приклад роботи:
    print("\n🔧 Редактор наголосів готовий до роботи...")
    
    # Симуляція роботи
    input("Натисніть Enter для симуляції роботи...")
    
    # Оновлюємо закладку
    config_manager.update_bookmark("accent_editor", cursor=1234, paragraph=56, scroll=0.75)
    
    # Пропонуємо перейти до наступного етапу
    response = input("\nЗавершити роботу з наголосами та перейти до редактора голосів? (y/n): ")
    if response.lower() == 'y':
        next_stage = config_manager.advance_to_next_stage()
        print(f"✅ Перейшли до етапу: {next_stage}")
        
        # Створюємо backup
        config_manager.create_backup("accent_editor_complete")
    else:
        print("💾 Прогрес збережено. Можете продовжити пізніше.")

if __name__ == '__main__':
    main()