"""
/storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite/core/simple_config_manager.py

Спрощений менеджер конфігурації для одного користувача з одним телефоном.
Один конфіг на книгу для всіх чотирьох програм.
"""

import json
import os
import logging
import shutil
from pathlib import Path
from typing import Dict, Any, List, Optional
from datetime import datetime

class SimpleBookProject:
    """
    Проста структура проекту для однієї книги
    Користувач працює з програмами послідовно в довільний час
    """
    
    # Стандартна структура для однієї книги
    PROJECT_TEMPLATE = {
        "folders": [
            "texts",           # Текстові файли на різних етапах
            "audio",           # Аудіо файли
            "temp",            # Тимчасові файли
            "backups"          # Резервні копії
        ],
        "files": {
            "original_text": "texts/original.txt",
            "accented_text": "texts/with_accents.txt", 
            "voice_tags_text": "texts/with_voice_tags.txt",
            "sound_effects_text": "texts/with_sound_effects.txt",
            "final_text": "texts/final_for_tts.txt",
            "project_config": "book_config.json"
        }
    }
    
    @staticmethod
    def create_book_project(book_name: str, original_text_path: str = None,
                          base_path: str = "/storage/emulated/0/projects") -> str:
        """
        Створює просту структуру проекту для книги
        """
        project_path = Path(base_path) / book_name
        
        # Створюємо папки
        for folder in SimpleBookProject.PROJECT_TEMPLATE["folders"]:
            (project_path / folder).mkdir(parents=True, exist_ok=True)
        
        # Копіюємо оригінальний текст
        original_file = project_path / SimpleBookProject.PROJECT_TEMPLATE["files"]["original_text"]
        if original_text_path and Path(original_text_path).exists():
            shutil.copy2(original_text_path, original_file)
            print(f"📖 Скопійовано оригінальний текст: {original_file}")
        else:
            original_file.write_text("# Оригінальний текст книги\n\n", encoding="utf-8")
            print(f"📖 Створено оригінальний текст: {original_file}")
        
        # Створюємо копії для кожного етапу
        text_files = [
            "accented_text", "voice_tags_text", "sound_effects_text", "final_text"
        ]
        
        for file_key in text_files:
            file_path = project_path / SimpleBookProject.PROJECT_TEMPLATE["files"][file_key]
            shutil.copy2(original_file, file_path)
            print(f"📝 Створено файл для етапу: {file_path}")
        
        # Створюємо конфігураційний файл
        config = SimpleBookProject.create_book_config(project_path, book_name)
        config_file = project_path / SimpleBookProject.PROJECT_TEMPLATE["files"]["project_config"]
        
        with open(config_file, 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        
        print(f"⚙️ Створено конфіг книги: {config_file}")
        print(f"✅ Проект '{book_name}' готовий до роботи!")
        
        return str(config_file)
    
    @staticmethod
    def create_book_config(project_path: Path, book_name: str) -> Dict[str, Any]:
        """
        Створює єдиний конфіг для всіх програм
        """
        return {
            # Загальна інформація про проект
            "book_info": {
                "name": book_name,
                "created_date": datetime.now().isoformat(),
                "last_modified": datetime.now().isoformat(),
                "current_stage": "accent_editor",  # Починаємо з редактора наголосів
                "work_days": 0,
                "notes": ""
            },
            
            # Шляхи до файлів
            "paths": {
                "project_root": str(project_path),
                "original_text": str(project_path / "texts/original.txt"),
                "accented_text": str(project_path / "texts/with_accents.txt"),
                "voice_tags_text": str(project_path / "texts/with_voice_tags.txt"), 
                "sound_effects_text": str(project_path / "texts/with_sound_effects.txt"),
                "final_text": str(project_path / "texts/final_for_tts.txt"),
                "audio_folder": str(project_path / "audio"),
                "temp_folder": str(project_path / "temp"),
                "backups_folder": str(project_path / "backups")
            },
            
            # Налаштування для редактора наголосів
            "accent_editor": {
                "current_file": str(project_path / "texts/with_accents.txt"),
                "accents_file": str(project_path / "texts/accents.json"),
                "bookmark": {"cursor": 0, "paragraph": 0, "scroll": 0.0},
                "tts_mode": "gTTS",
                "do_split": False
            },
            
            # Налаштування для редактора голосів та пауз
            "voice_tags_editor": {
                "current_file": str(project_path / "texts/with_voice_tags.txt"),
                "bookmark": {"cursor": 0, "paragraph": 0, "scroll": 0.0},
                "voice_dict": {
                    "G1": "Розповідач", "G2": "Чоловік1", "G3": "Чоловік2",
                    "G4": "Жінка1", "G5": "Жінка2", "G6": "Хлопець",
                    "G7": "Дівчина", "G8": "Думки чол", "G9": "Думки жін"
                },
                "pause_dict": {
                    "P4": "PAUSE_4", "P7": "PAUSE_7", "P1": "PAUSE_1", "P2": "PAUSE_2"
                }
            },
            
            # Налаштування для редактора звукових ефектів
            "sound_effects_editor": {
                "current_file": str(project_path / "texts/with_sound_effects.txt"),
                "bookmark": {"cursor": 0, "paragraph": 0, "scroll": 0.0},
                "sound_dict": {
                    "S1": "Звук_пострілу", "S2": "Машина_гальмує", "S3": "Гарчання_мутанта"
                },
                "sounds_folder": str(project_path / "temp/sounds")
            },
            
            # Налаштування для мультиспікера TTS
            "multispeaker_tts": {
                "current_file": str(project_path / "texts/final_for_tts.txt"),
                "bookmark": {"cursor": 0, "paragraph": 0, "scroll": 0.0},
                "output_folder": str(project_path / "audio"),
                "fragment_soft_limit": 900,
                "fragment_hard_limit": 1000,
                "do_split": True,
                "do_merge": False,
                "tts_mode": "TFile"
            },
            
            # Спільні налаштування
            "common": {
                "text_widget_font_size": 56,
                "button_font_size": 38,
                "button_height": 120,
                "accent_char": "́"
            }
        }


class SimpleConfigManager:
    """
    Простий менеджер конфігурації для одного користувача
    """
    
    def __init__(self, config_path: str):
        self.config_file = Path(config_path)
        self.config_data = {}
        self.logger = self._setup_logging()
        self.load_config()
    
    def _setup_logging(self):
        """Налаштовує просте логування"""
        logger = logging.getLogger('simple_config')
        logger.setLevel(logging.INFO)
        
        if not logger.handlers:
            # Консольний вивід
            handler = logging.StreamHandler()
            formatter = logging.Formatter('%(message)s')
            handler.setFormatter(formatter)
            logger.addHandler(handler)
        
        return logger
    
    def load_config(self):
        """Завантажує конфігурацію"""
        if self.config_file.exists():
            try:
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    self.config_data = json.load(f)
                self.logger.info(f"📂 Завантажено конфіг: {self.config_file}")
            except Exception as e:
                self.logger.error(f"❌ Помилка завантаження конфігу: {e}")
                self.config_data = {}
        else:
            self.logger.warning(f"⚠️ Конфіг не знайдено: {self.config_file}")
    
    def save_config(self):
        """Зберігає конфігурацію"""
        try:
            self.config_file.parent.mkdir(parents=True, exist_ok=True)
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(self.config_data, f, ensure_ascii=False, indent=2)
            self.logger.info(f"💾 Збережено конфіг: {self.config_file}")
            return True
        except Exception as e:
            self.logger.error(f"❌ Помилка збереження конфігу: {e}")
            return False
    
    def get_editor_config(self, editor_name: str) -> Dict[str, Any]:
        """Отримує конфіг для конкретного редактора"""
        editor_config = self.config_data.get(editor_name, {})
        
        # Додаємо загальну інформацію
        editor_config["book_info"] = self.config_data.get("book_info", {})
        editor_config["common"] = self.config_data.get("common", {})
        editor_config["paths"] = self.config_data.get("paths", {})
        
        return editor_config
    
    def update_editor_config(self, editor_name: str, updates: Dict[str, Any]):
        """Оновлює конфіг редактора"""
        if editor_name not in self.config_data:
            self.config_data[editor_name] = {}
        
        self.config_data[editor_name].update(updates)
        self.config_data["book_info"]["last_modified"] = datetime.now().isoformat()
        self.save_config()
    
    def get_current_stage(self) -> str:
        """Отримує поточний етап роботи"""
        return self.config_data.get("book_info", {}).get("current_stage", "accent_editor")
    
    def set_current_stage(self, stage: str):
        """Встановлює поточний етап роботи"""
        if "book_info" not in self.config_data:
            self.config_data["book_info"] = {}
        
        self.config_data["book_info"]["current_stage"] = stage
        self.config_data["book_info"]["last_modified"] = datetime.now().isoformat()
        self.save_config()
        self.logger.info(f"🔄 Перейшли на етап: {stage}")
    
    def advance_to_next_stage(self) -> str:
        """Переходить до наступного етапу"""
        stages = ["accent_editor", "voice_tags_editor", "sound_effects_editor", "multispeaker_tts"]
        current = self.get_current_stage()
        
        try:
            current_index = stages.index(current)
            if current_index < len(stages) - 1:
                next_stage = stages[current_index + 1]
                self.set_current_stage(next_stage)
                return next_stage
            else:
                self.logger.info("🎉 Всі етапи завершено!")
                return "completed"
        except ValueError:
            self.set_current_stage("accent_editor")
            return "accent_editor"
    
    def get_project_info(self) -> Dict[str, Any]:
        """Отримує інформацію про проект"""
        return self.config_data.get("book_info", {})
    
    def update_bookmark(self, editor_name: str, cursor: int, paragraph: int, scroll: float = 0.0):
        """Оновлює закладку для редактора"""
        bookmark = {"cursor": cursor, "paragraph": paragraph, "scroll": scroll}
        self.update_editor_config(editor_name, {"bookmark": bookmark})
    
    def create_backup(self, backup_name: str = None):
        """Створює резервну копію проекту"""
        if not backup_name:
            backup_name = f"backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        backup_folder = Path(self.config_data.get("paths", {}).get("backups_folder", "."))
        backup_folder.mkdir(exist_ok=True)
        
        # Копіюємо конфіг
        backup_config = backup_folder / f"{backup_name}_config.json"
        shutil.copy2(self.config_file, backup_config)
        
        # Копіюємо поточний текстовий файл
        current_stage = self.get_current_stage()
        current_file = self.config_data.get(current_stage, {}).get("current_file")
        if current_file and Path(current_file).exists():
            backup_text = backup_folder / f"{backup_name}_text.txt"
            shutil.copy2(current_file, backup_text)
        
        self.logger.info(f"📦 Створено backup: {backup_name}")
        return str(backup_config)


# Функції для роботи з проектами
def create_new_book(book_name: str, original_text_path: str = None) -> SimpleConfigManager:
    """Створює нову книгу та повертає менеджер конфігурації"""
    config_path = SimpleBookProject.create_book_project(book_name, original_text_path)
    return SimpleConfigManager(config_path)

def list_existing_books(base_path: str = "/storage/emulated/0/projects") -> List[str]:
    """Повертає список існуючих книг"""
    projects_path = Path(base_path)
    if not projects_path.exists():
        return []
    
    books = []
    for item in projects_path.iterdir():
        if item.is_dir():
            config_file = item / "book_config.json"
            if config_file.exists():
                books.append(item.name)
    
    return sorted(books)

def load_book(book_name: str, base_path: str = "/storage/emulated/0/projects") -> SimpleConfigManager:
    """Завантажує існуючу книгу"""
    config_path = Path(base_path) / book_name / "book_config.json"
    return SimpleConfigManager(str(config_path))


# Глобальний менеджер для поточної книги
_current_book_manager = None

def set_current_book(book_name: str, original_text_path: str = None) -> SimpleConfigManager:
    """Встановлює поточну книгу для роботи"""
    global _current_book_manager
    
    # Спочатку шукаємо існуючу книгу
    existing_books = list_existing_books()
    if book_name in existing_books:
        _current_book_manager = load_book(book_name)
    else:
        # Створюємо нову книгу
        _current_book_manager = create_new_book(book_name, original_text_path)
    
    return _current_book_manager

def get_current_book() -> SimpleConfigManager:
    """Повертає поточну книгу"""
    global _current_book_manager
    return _current_book_manager