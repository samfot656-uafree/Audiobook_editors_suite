#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Скрипт для перегляду статусу всіх книг
"""

import sys
from pathlib import Path
from datetime import datetime

sys.path.append('/storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite')
from core.simple_config_manager import list_existing_books, load_book

def show_books_status():
    """Показує статус всіх книг"""
    books = list_existing_books()
    
    print(f"\n📚 Ваші книги ({len(books)} знайдено):")
    print("=" * 60)
    
    for book_name in books:
        try:
            config_manager = load_book(book_name)
            project_info = config_manager.get_project_info()
            
            print(f"\n📖 {book_name}")
            print(f"   🎯 Етап: {project_info.get('current_stage', 'невідомо')}")
            print(f"   📅 Остання зміна: {project_info.get('last_modified', 'невідомо')}")
            print(f"   📝 Нотатки: {project_info.get('notes', 'немає')}")
            
        except Exception as e:
            print(f"\n❌ Помилка читання {book_name}: {e}")
    
    print("\n" + "=" * 60)

if __name__ == '__main__':
    show_books_status()