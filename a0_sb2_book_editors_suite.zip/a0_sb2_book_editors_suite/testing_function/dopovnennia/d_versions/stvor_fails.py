# Створення проекту з додатковими файлами
config_manager = get_config_manager()

# Створюємо проект
project_path = config_manager.create_project(
    project_name="Новий_роман",
    input_text_path="/storage/emulated/0/Documents/оригінал.txt",
    source_config_path="/storage/emulated/0/Documents/Json/config_m5_3.json"
)

# Додаємо додаткові файли
additional_files = {
    "/storage/emulated/0/Documents/додатковий_звук.wav": "temp/input_sound/додатковий_звук.wav",
    "/storage/emulated/0/Documents/додаткова_мелодія.mp3": "temp/input_melodu/додаткова_мелодія.mp3"
}

config_manager.add_files_to_project(additional_files)