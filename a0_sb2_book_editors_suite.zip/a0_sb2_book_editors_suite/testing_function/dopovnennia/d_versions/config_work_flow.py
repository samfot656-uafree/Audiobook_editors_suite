"""
/storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite/core/config_manager.py

Менеджер конфігурації з підтримкою стандартного workflow аудіокниги.
"""

import json
import re
import os
import logging
import shutil
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple
from enum import Enum

class WorkflowStage(Enum):
    """Етапи workflow створення аудіокниги"""
    ACCENTS = "accent_editor"
    VOICE_TAGS = "voice_tags_editor" 
    SOUND_EFFECTS = "sound_effects_editor"
    MULTISPEAKER_TTS = "multispeaker_tts"
    FINAL = "final"

class ProjectManager:
    """Менеджер проектів з підтримкою workflow"""
    
    # Стандартна структура папок проекту
    PROJECT_STRUCTURE = {
        "folders": [
            "outputs",
            "temp/input_sound",
            "temp/input_melodu",
            "workflow/accent_editor",
            "workflow/voice_tags_editor", 
            "workflow/sound_effects_editor",
            "workflow/multispeaker_tts"
        ],
        "files": {
            # Основні файли
            "input_text": "{project_name}.txt",
            "config": "{project_name}_config.json",
            
            # Workflow файли
            "accented_text": "workflow/accent_editor/{project_name}_with_accents.txt",
            "voice_tags_text": "workflow/voice_tags_editor/{project_name}_with_voice_tags.txt",
            "sound_effects_text": "workflow/sound_effects_editor/{project_name}_with_sound_effects.txt",
            "final_text": "workflow/multispeaker_tts/{project_name}_final.txt",
            
            # JSON файли
            "accents_json": "workflow/accent_editor/accents.json",
            "scenarios_json": "workflow/sound_effects_editor/scenarios_ozvuch.json",
            "sounds_dict_json": "workflow/sound_effects_editor/sounds_effect_files_dict.json"
        }
    }
    
    # Файли для копіювання з джерельних конфігів
    REQUIRED_FILES_TO_COPY = {
        "PAUSE_FILES": [
            "PAUSE_4_mp3", "PAUSE_7_mp3", "PAUSE_1_mp3", "PAUSE_2_mp3",
            "PAUSE_4_wav", "PAUSE_7_wav", "PAUSE_1_wav", "PAUSE_2_wav"
        ],
        "MELODY_FILES": [
            "MELODY_START_mp3", "MELODY_END_mp3", 
            "MELODY_START_wav", "MELODY_END_wav", "TEST_wav"
        ]
    }

    @staticmethod
    def create_project_structure(project_name: str, source_config: Dict[str, Any] = None,
                               input_text_path: str = None, 
                               base_path: str = "/storage/emulated/0/projects") -> str:
        """
        Створює повну структуру проекту з workflow папками
        
        Args:
            project_name (str): Назва проекту
            source_config (dict): Вихідний конфіг для копіювання файлів
            input_text_path (str): Шлях до вихідного тексту
            base_path (str): Базова папка проектів
            
        Returns:
            str: Шлях до конфігураційного файлу проекту
        """
        project_path = Path(base_path) / project_name
        
        # Створюємо структуру папок
        for folder in ProjectManager.PROJECT_STRUCTURE["folders"]:
            folder_path = project_path / folder
            folder_path.mkdir(parents=True, exist_ok=True)
            print(f"📁 Створено папку: {folder_path}")

        # Копіюємо/створюємо текстовий файл
        input_text_file = project_path / ProjectManager.PROJECT_STRUCTURE["files"]["input_text"].format(project_name=project_name)
        if input_text_path and Path(input_text_path).exists():
            shutil.copy2(input_text_path, input_text_file)
            print(f"📄 Скопійовано текст: {input_text_file}")
        else:
            input_text_file.write_text("# Вхідний текст проекту\n\n", encoding="utf-8")
            print(f"📄 Створено текстовий файл: {input_text_file}")

        # Створюємо workflow файли (копіюємо текст на кожен етап)
        workflow_files = [
            "accented_text",
            "voice_tags_text", 
            "sound_effects_text",
            "final_text"
        ]
        
        for file_key in workflow_files:
            file_path = project_path / ProjectManager.PROJECT_STRUCTURE["files"][file_key].format(project_name=project_name)
            if input_text_file.exists():
                shutil.copy2(input_text_file, file_path)
                print(f"🔗 Створено workflow файл: {file_path}")

        # Копіюємо необхідні звукові файли
        copied_files = ProjectManager._copy_required_files(source_config, str(project_path))

        # Створюємо конфігурацію
        config = ProjectManager.create_project_config(str(project_path), project_name, copied_files)
        config_file = project_path / ProjectManager.PROJECT_STRUCTURE["files"]["config"].format(project_name=project_name)
        
        with open(config_file, 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)

        print(f"⚙️ Створено конфіг: {config_file}")
        print(f"✅ Проект '{project_name}' готовий до роботи!")
        
        return str(config_file)

    @staticmethod
    def _copy_required_files(source_config: Dict[str, Any], project_path: str) -> Dict[str, str]:
        """Копіює необхідні файли у проект"""
        if not source_config:
            return {}
            
        copied_files = {}
        project_path_obj = Path(project_path)
        
        try:
            # Копіюємо звукові файли та мелодії
            for file_type, file_keys in ProjectManager.REQUIRED_FILES_TO_COPY.items():
                for file_key in file_keys:
                    config_key = f"VOICE_TAGS_EDITOR_{file_key}"
                    
                    if config_key in source_config:
                        source_file = source_config[config_key]
                        if source_file and Path(source_file).exists():
                            dest_folder = project_path_obj / "temp/input_melodu"
                            dest_folder.mkdir(parents=True, exist_ok=True)
                            
                            filename = Path(source_file).name
                            dest_file = dest_folder / filename
                            
                            shutil.copy2(source_file, dest_file)
                            copied_files[source_file] = str(dest_file)
                            print(f"🔊 Скопійовано: {source_file} -> {dest_file}")
        
        except Exception as e:
            print(f"❌ Помилка копіювання файлів: {e}")
        
        return copied_files

    @staticmethod
    def create_project_config(project_path: str, project_name: str, 
                            copied_files: Dict[str, str] = None) -> Dict[str, Any]:
        """Створює конфігурацію проекту з правильними шляхами"""
        base_path = f"{project_path}/{project_name}"
        
        # Базова конфігурація з workflow шляхами
        config = {
            # Спільні параметри
            "COMMON_CONFIG_VERSION": "0_0_0_2",
            "COMMON_TEXT_WIDGET_FONT_SIZE": 56,
            "COMMON_BBTN_FONT_SIZE": 38,
            "COMMON_BBTN_HEIGHT": 120,
            "COMMON_ACCENT_CHAR": "́",
            "COMMON_INPUT_TEXT_FILE": f"{base_path}/{project_name}.txt",
            "COMMON_OUTPUT_FOLDER": f"{base_path}/outputs",
            "COMMON_TEMP_FOLDER": f"{base_path}/temp",
            "COMMON_VOICE_DICT": {
                "G1": "Розповідач", "G2": "Чоловік1", "G3": "Чоловік2",
                "G4": "Жінка1", "G5": "Жінка2", "G6": "Хлопець",
                "G7": "Дівчина", "G8": "Думки чол", "G9": "Думки жін"
            },
            "COMMON_PAUSE_DICT": {
                "P4": "PAUSE_4", "P7": "PAUSE_7", "P1": "PAUSE_1", "P2": "PAUSE_2"
            },
            
            # Редактор наголосів
            "ACCENT_EDITOR_ACCENTS_FILE": f"{base_path}/workflow/accent_editor/accents.json",
            "ACCENT_EDITOR_OUTPUT_MP3_FOLDER": f"{base_path}/outputs",
            "ACCENT_EDITOR_TTS_MODE": "gTTS",
            "ACCENT_EDITOR_DO_SPLIT": False,
            "ACCENT_EDITOR_BOOKMARK": {"cursor": 0, "scroll": 0.0, "paragraph_index": 0},
            "ACCENT_EDITOR_CURRENT_TEXT_FILE": f"{base_path}/workflow/accent_editor/{project_name}_with_accents.txt",
            
            # Редактор голосів та пауз
            "VOICE_TAGS_EDITOR_PAUSE_4_MP3": f"{base_path}/temp/input_melodu/PAUSE_4.mp3",
            "VOICE_TAGS_EDITOR_PAUSE_7_MP3": f"{base_path}/temp/input_melodu/PAUSE_7.mp3",
            "VOICE_TAGS_EDITOR_PAUSE_1_MP3": f"{base_path}/temp/input_melodu/PAUSE_1.mp3",
            "VOICE_TAGS_EDITOR_PAUSE_2_MP3": f"{base_path}/temp/input_melodu/PAUSE_2.mp3",
            "VOICE_TAGS_EDITOR_PAUSE_4_WAV": f"{base_path}/temp/input_melodu/PAUSE_4.wav",
            "VOICE_TAGS_EDITOR_PAUSE_7_WAV": f"{base_path}/temp/input_melodu/PAUSE_7.wav",
            "VOICE_TAGS_EDITOR_PAUSE_1_WAV": f"{base_path}/temp/input_melodu/PAUSE_1.wav",
            "VOICE_TAGS_EDITOR_PAUSE_2_WAV": f"{base_path}/temp/input_melodu/PAUSE_2.wav",
            "VOICE_TAGS_EDITOR_MELODY_START_MP3": f"{base_path}/temp/input_melodu/MELODY_START.mp3",
            "VOICE_TAGS_EDITOR_MELODY_END_MP3": f"{base_path}/temp/input_melodu/MELODY_END.mp3",
            "VOICE_TAGS_EDITOR_MELODY_START_WAV": f"{base_path}/temp/input_melodu/MELODY_START.wav",
            "VOICE_TAGS_EDITOR_MELODY_END_WAV": f"{base_path}/temp/input_melodu/MELODY_END.wav",
            "VOICE_TAGS_EDITOR_TEST_WAV": f"{base_path}/temp/input_melodu/TEST.wav",
            "VOICE_TAGS_EDITOR_BOOKMARK": {"cursor": 0, "scroll": 0.0, "paragraph_index": 0},
            "VOICE_TAGS_EDITOR_CURRENT_TEXT_FILE": f"{base_path}/workflow/voice_tags_editor/{project_name}_with_voice_tags.txt",
            
            # Редактор звукових ефектів
            "SOUND_EFFECTS_EDITOR_SOUND_DICT": {
                "S1": "Звук_пострілу_part_022",
                "S2": "Машина_гальмує_part_027", 
                "S3": "Гарчання_мутанта1_part_047"
            },
            "SOUND_EFFECTS_EDITOR_SOUNDS_EFFECTS_LIST": f"{base_path}/workflow/sound_effects_editor/scenarios_ozvuch.json",
            "SOUND_EFFECTS_EDITOR_SOUNDS_EFFECTS_FILES": f"{base_path}/workflow/sound_effects_editor/sounds_effect_files_dict.json",
            "SOUND_EFFECTS_EDITOR_SOUNDS_EFFECTS_INPUT_FOLDER": f"{base_path}/temp/input_sound",
            "SOUND_EFFECTS_EDITOR_BOOKMARK": {"cursor": 0, "scroll": 0.0, "paragraph_index": 0},
            "SOUND_EFFECTS_EDITOR_CURRENT_TEXT_FILE": f"{base_path}/workflow/sound_effects_editor/{project_name}_with_sound_effects.txt",
            
            # Мультиспікер TTS
            "MULTISPEAKER_TTS_INPUT_SOUNDS_FOLDER": f"{base_path}/temp/input_melodu",
            "MULTISPEAKER_TTS_FRAGMENT_SOFT_LIMIT": 900,
            "MULTISPEAKER_TTS_FRAGMENT_HARD_LIMIT": 1000,
            "MULTISPEAKER_TTS_DO_SPLIT": True,
            "MULTISPEAKER_TTS_DO_MERGE": False,
            "MULTISPEAKER_TTS_TTS_MODE": "TFile",
            "MULTISPEAKER_TTS_SOUND_DICT": {
                "S1": "Звук_пострілу_part_022",
                "S2": "Машина_гальмує_part_027", 
                "S3": "Гарчання_мутанта1_part_047"
            },
            "MULTISPEAKER_TTS_BOOKMARK": {"cursor": 0, "scroll": 0.0, "paragraph_index": 0},
            "MULTISPEAKER_TTS_CURRENT_TEXT_FILE": f"{base_path}/workflow/multispeaker_tts/{project_name}_final.txt"
        }
        
        # Оновлюємо шляхи на основі скопійованих файлів
        if copied_files:
            config = ProjectManager._update_config_paths(config, copied_files)
        
        return config

    @staticmethod
    def _update_config_paths(config: Dict[str, Any], copied_files: Dict[str, str]) -> Dict[str, Any]:
        """Оновлює шляхи у конфігурації"""
        old_to_new = copied_files
        
        for config_key, config_value in config.items():
            if isinstance(config_value, str) and config_value in old_to_new:
                config[config_key] = old_to_new[config_value]
        
        return config

    @staticmethod
    def get_next_stage(current_stage: WorkflowStage) -> Optional[WorkflowStage]:
        """Повертає наступний етап workflow"""
        stages = list(WorkflowStage)
        current_index = stages.index(current_stage)
        return stages[current_index + 1] if current_index + 1 < len(stages) else None

    @staticmethod
    def get_workflow_file(project_path: str, project_name: str, stage: WorkflowStage) -> str:
        """Повертає шлях до файлу для конкретного етапу workflow"""
        file_mapping = {
            WorkflowStage.ACCENTS: f"workflow/accent_editor/{project_name}_with_accents.txt",
            WorkflowStage.VOICE_TAGS: f"workflow/voice_tags_editor/{project_name}_with_voice_tags.txt",
            WorkflowStage.SOUND_EFFECTS: f"workflow/sound_effects_editor/{project_name}_with_sound_effects.txt",
            WorkflowStage.MULTISPEAKER_TTS: f"workflow/multispeaker_tts/{project_name}_final.txt"
        }
        
        return f"{project_path}/{project_name}/{file_mapping[stage]}"

    @staticmethod
    def advance_workflow_stage(project_path: str, project_name: str, current_stage: WorkflowStage) -> bool:
        """Переміщує текст на наступний етап workflow"""
        try:
            current_file = ProjectManager.get_workflow_file(project_path, project_name, current_stage)
            next_stage = ProjectManager.get_next_stage(current_stage)
            
            if next_stage and Path(current_file).exists():
                next_file = ProjectManager.get_workflow_file(project_path, project_name, next_stage)
                shutil.copy2(current_file, next_file)
                print(f"🔄 Переміщено з {current_stage.value} до {next_stage.value}")
                return True
            else:
                print(f"ℹ️  {current_stage.value} завершено")
                return False
                
        except Exception as e:
            print(f"❌ Помилка переходу між етапами: {e}")
            return False


class ModularConfigManager:
    """
    Менеджер конфігурації з підтримкою workflow аудіокниги
    """

    def __init__(self, config_path: str = None, auto_create: bool = True):
        self.config_file = Path(config_path) if config_path else None
        self.data = {}
        self.project_manager = ProjectManager()
        self.current_workflow_stage = WorkflowStage.ACCENTS  # Завжди починаємо з редактора наголосів
        
        # Налаштування логування
        self.logger = self._setup_logging()

        # Ініціалізація параметрів (скорочено для читабельності)
        self.common_params = {
            'params': ['CONFIG_VERSION', 'TEXT_WIDGET_FONT_SIZE', 'BBTN_FONT_SIZE', 'BBTN_HEIGHT', 
                      'ACCENT_CHAR', 'INPUT_TEXT_FILE', 'OUTPUT_FOLDER', 'TEMP_FOLDER', 
                      'VOICE_DICT', 'PAUSE_DICT'],
            'defaults': {
                'CONFIG_VERSION': '0_0_0_2',
                'TEXT_WIDGET_FONT_SIZE': 56,
                'BBTN_FONT_SIZE': 38,
                'BBTN_HEIGHT': 120,
                'ACCENT_CHAR': '\u0301',
                'INPUT_TEXT_FILE': '',
                'OUTPUT_FOLDER': '',
                'TEMP_FOLDER': '',
                'VOICE_DICT': {
                    "G1": "Розповідач", "G2": "Чоловік1", "G3": "Чоловік2",
                    "G4": "Жінка1", "G5": "Жінка2", "G6": "Хлопець",
                    "G7": "Дівчина", "G8": "Думки чол", "G9": "Думки жін"
                },
                'PAUSE_DICT': {
                    "P4": "PAUSE_4", "P7": "PAUSE_7", "P1": "PAUSE_1", "P2": "PAUSE_2"
                },
            }
        }
        
        # Особисті параметри редакторів
        self.editor_registry = {
            'accent_editor': {
                'params': ['ACCENTS_FILE', 'OUTPUT_MP3_FOLDER', 'TTS_MODE', 'DO_SPLIT', 'BOOKMARK', 'CURRENT_TEXT_FILE'],
                'defaults': {
                    'ACCENTS_FILE': '', 'OUTPUT_MP3_FOLDER': '', 'TTS_MODE': 'gTTS', 
                    'DO_SPLIT': False, 'BOOKMARK': {'cursor': 0, 'scroll': 0.0, 'paragraph_index': 0},
                    'CURRENT_TEXT_FILE': ''
                }
            },
            'voice_tags_editor': {
                'params': ['PAUSE_4_MP3', 'PAUSE_7_MP3', 'PAUSE_1_MP3', 'PAUSE_2_MP3',
                          'PAUSE_4_WAV', 'PAUSE_7_WAV', 'PAUSE_1_WAV', 'PAUSE_2_WAV',
                          'MELODY_START_MP3', 'MELODY_END_MP3', 'MELODY_START_WAV', 
                          'MELODY_END_WAV', 'TEST_WAV', 'BOOKMARK', 'CURRENT_TEXT_FILE'],
                'defaults': {
                    'PAUSE_4_MP3': '', 'PAUSE_7_MP3': '', 'PAUSE_1_MP3': '', 'PAUSE_2_MP3': '',
                    'PAUSE_4_WAV': '', 'PAUSE_7_WAV': '', 'PAUSE_1_WAV': '', 'PAUSE_2_WAV': '',
                    'MELODY_START_MP3': '', 'MELODY_END_MP3': '', 'MELODY_START_WAV': '',
                    'MELODY_END_WAV': '', 'TEST_WAV': '', 
                    'BOOKMARK': {'cursor': 0, 'scroll': 0.0, 'paragraph_index': 0},
                    'CURRENT_TEXT_FILE': ''
                }
            },
            'sound_effects_editor': {
                'params': ['SOUNDS_EFFECTS_LIST', 'SOUNDS_EFFECTS_FILES', 'SOUNDS_EFFECTS_INPUT_FOLDER',
                          'SOUND_DICT', 'BOOKMARK', 'CURRENT_TEXT_FILE'],
                'defaults': {
                    'SOUND_DICT': {
                        "S1": "Звук_пострілу_part_022", "S2": "Машина_гальмує_part_027", 
                        "S3": "Гарчання_мутанта1_part_047"
                    },
                    'SOUNDS_EFFECTS_LIST': '', 'SOUNDS_EFFECTS_FILES': '', 
                    'SOUNDS_EFFECTS_INPUT_FOLDER': '',
                    'BOOKMARK': {'cursor': 0, 'scroll': 0.0, 'paragraph_index': 0},
                    'CURRENT_TEXT_FILE': ''
                }
            },
            'multispeaker_tts': {
                'params': ['INPUT_SOUNDS_FOLDER', 'FRAGMENT_SOFT_LIMIT', 'FRAGMENT_HARD_LIMIT', 
                          'DO_SPLIT', 'DO_MERGE', 'TTS_MODE', 'SOUND_DICT', 'BOOKMARK', 'CURRENT_TEXT_FILE'],
                'defaults': {
                    'INPUT_SOUNDS_FOLDER': '', 'FRAGMENT_SOFT_LIMIT': 900, 'FRAGMENT_HARD_LIMIT': 1000,
                    'DO_SPLIT': True, 'DO_MERGE': False, 'TTS_MODE': 'TFile',
                    'SOUND_DICT': {
                        "S1": "Звук_пострілу_part_022", "S2": "Машина_гальмує_part_027", 
                        "S3": "Гарчання_мутанта1_part_047"
                    },
                    'BOOKMARK': {'cursor': 0, 'scroll': 0.0, 'paragraph_index': 0},
                    'CURRENT_TEXT_FILE': ''
                }
            }
        }
        
        # Автоматичне створення проекту
        if auto_create and config_path:
            self._auto_create_project_structure()

    def _auto_create_project_structure(self):
        """Автоматично створює структуру проекту"""
        try:
            if not self.config_file.exists():
                self.logger.info("Автоматичне створення структури проекту...")
                
                project_name = self.config_file.parent.name
                base_path = self.config_file.parent.parent
                
                # Завантажуємо вихідний конфіг для копіювання файлів
                source_config = self._load_source_config()
                
                # Створюємо проект
                new_config_path = self.project_manager.create_project_structure(
                    project_name=project_name,
                    source_config=source_config,
                    base_path=str(base_path)
                )
                
                self.config_file = Path(new_config_path)
            
            # Завантажуємо конфіг та встановлюємо початковий етап
            self.load_full_config()
            self.current_workflow_stage = WorkflowStage.ACCENTS
            
        except Exception as e:
            self.logger.error(f"Помилка створення проекту: {e}")

    def _load_source_config(self) -> Dict[str, Any]:
        """Завантажує вихідний конфіг"""
        possible_configs = [
            "/storage/emulated/0/Documents/Json/config_m5_3.json",
            "/storage/emulated/0/Documents/pidgotovka_knigi/project_config.json",
        ]
        
        for config_path in possible_configs:
            if os.path.exists(config_path):
                try:
                    with open(config_path, 'r', encoding='utf-8') as f:
                        return json.load(f)
                except Exception as e:
                    self.logger.warning(f"Помилка завантаження {config_path}: {e}")
        
        return {}

    # ===========================
    # Workflow Management Methods
    # ===========================

    def get_current_stage(self) -> WorkflowStage:
        """Повертає поточний етап workflow"""
        return self.current_workflow_stage

    def advance_to_next_stage(self) -> bool:
        """Переходить до наступного етапу workflow"""
        if not self.config_file.exists():
            return False
            
        project_name = self.config_file.parent.name
        project_path = self.config_file.parent.parent
        
        success = self.project_manager.advance_workflow_stage(
            str(project_path), project_name, self.current_workflow_stage
        )
        
        if success:
            next_stage = self.project_manager.get_next_stage(self.current_workflow_stage)
            if next_stage:
                self.current_workflow_stage = next_stage
                self.logger.info(f"Перейшли до етапу: {self.current_workflow_stage.value}")
                return True
        
        return False

    def get_stage_progress(self) -> Dict[str, Any]:
        """Повертає прогрес по workflow"""
        stages = list(WorkflowStage)
        current_index = stages.index(self.current_workflow_stage)
        total_stages = len([s for s in stages if s != WorkflowStage.FINAL])
        
        return {
            'current_stage': self.current_workflow_stage.value,
            'current_stage_name': self.current_workflow_stage.name,
            'progress_percent': int((current_index / total_stages) * 100) if total_stages > 0 else 0,
            'current_step': current_index + 1,
            'total_steps': total_stages,
            'next_stage': self.project_manager.get_next_stage(self.current_workflow_stage)
        }

    def get_editor_for_current_stage(self) -> str:
        """Повертає назву редактора для поточного етапу"""
        return self.current_workflow_stage.value

    # ===========================
    # Project Management Methods
    # ===========================

    def create_project(self, project_name: str, input_text_path: str = None,
                      source_config_path: str = None) -> str:
        """Створює новий проект"""
        try:
            source_config = {}
            if source_config_path and os.path.exists(source_config_path):
                with open(source_config_path, 'r', encoding='utf-8') as f:
                    source_config = json.load(f)
            
            config_path = self.project_manager.create_project_structure(
                project_name=project_name,
                source_config=source_config,
                input_text_path=input_text_path
            )
            
            self.config_file = Path(config_path)
            self.load_full_config()
            self.current_workflow_stage = WorkflowStage.ACCENTS
            
            self.logger.info(f"Створено проект: {project_name}")
            return config_path
            
        except Exception as e:
            self.logger.error(f"Помилка створення проекту: {e}")
            raise

    def list_projects(self) -> List[str]:
        return self.project_manager.list_projects()

    def validate_current_project(self) -> Tuple[bool, List[str]]:
        if not self.config_file.exists():
            return False, ["Конфігураційний файл не існує"]
        
        project_name = self.config_file.parent.name
        return self.project_manager.validate_project_structure(project_name)

    def get_current_project_info(self) -> Dict[str, Any]:
        if not self.config_file.exists():
            return {}
        
        project_name = self.config_file.parent.name
        project_path = self.config_file.parent
        
        is_valid, problems = self.validate_current_project()
        progress = self.get_stage_progress()
        
        return {
            'name': project_name,
            'path': str(project_path),
            'config_path': str(self.config_file),
            'is_valid': is_valid,
            'problems': problems,
            'current_stage': progress['current_stage'],
            'progress': progress['progress_percent'],
            'current_editor': self.get_editor_for_current_stage()
        }

    # ... (інші методи залишаються аналогічними)

# Додаємо методи до ProjectManager для сумісності
ProjectManager.list_projects = staticmethod(lambda base_path="/storage/emulated/0/projects": 
    [d for d in os.listdir(base_path) if os.path.isdir(os.path.join(base_path, d))] if os.path.exists(base_path) else [])

ProjectManager.validate_project_structure = staticmethod(lambda project_name, base_path="/storage/emulated/0/projects": 
    (True, []) if os.path.exists(f"{base_path}/{project_name}") else (False, ["Проект не існує"]))

ProjectManager.get_project_config_path = staticmethod(lambda project_name, base_path="/storage/emulated/0/projects": 
    f"{base_path}/{project_name}/{project_name}_config.json")

# Синглтон
_global_config_manager = None

def get_config_manager(config_path: str = None, auto_create: bool = True) -> ModularConfigManager:
    global _global_config_manager
    if _global_config_manager is None and config_path:
        _global_config_manager = ModularConfigManager(config_path, auto_create)
    return _global_config_manager

def reset_config_manager():
    global _global_config_manager
    _global_config_manager = None

__all__ = ['ModularConfigManager', 'ProjectManager', 'WorkflowStage', 'get_config_manager', 'reset_config_manager']