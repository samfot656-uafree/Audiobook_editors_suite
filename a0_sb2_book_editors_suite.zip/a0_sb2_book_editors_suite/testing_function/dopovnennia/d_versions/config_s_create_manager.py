"""
/storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite/core/config_manager.py

Менеджер конфігурації з автоматичним створенням структури проекту при запуску.
"""
#змінити структуру проекту книги, доповнити відсутні частини з більш ранньої версії config_manager.py, оновити методи,


import json
import re
import os
import logging
import shutil
from pathlib import Path
from typing import Dict, Any, List, Optional, Set

class ProjectManager:
    """Менеджер для створення структури проекту"""
    
    # Список файлів, які потрібно скопіювати з старих шляхів у нову структуру проекту
    REQUIRED_FILES_TO_COPY = {
        # Звукові файли для voice_tags_editor
        "PAUSE_FILES": [
            "PAUSE_4_mp3", 
            "PAUSE_7_mp3", 
            "PAUSE_1_mp3", 
            "PAUSE_2_mp3",
            "PAUSE_4_wav", 
            "PAUSE_7_wav", 
            "PAUSE_1_wav", 
            "PAUSE_2_wav"
        ],
        # Мелодії
        "MELODY_FILES": [
            "MELODY_START_mp3", 
            "MELODY_END_mp3", 
            "MELODY_START_wav", 
            "MELODY_END_wav", 
            "TEST_wav"
        ],
        # JSON файли
        "JSON_FILES": [
            "ACCENTS_FILE", 
            "SOUNDS_EFFECTS_LIST", 
            "SOUNDS_EFFECTS_FILES"
        ]
    }
    
    @staticmethod
    def create_project_structure(project_name: str, source_config: Dict[str, Any] = None, 
                               input_text_path: str = None, base_path: str = "/storage/emulated/0/book_projects") -> str:
        """
        Створює структуру проекту та копіює необхідні файли
        
        Args:
            project_name (str): Назва проекту
            source_config (dict): Вхідний конфіг для отримання шляхів до файлів
            input_text_path (str, optional): Шлях до вхідного текстового файлу
            base_path (str): Базова папка для проектів
            
        Returns:
            str: Шлях до конфігураційного файлу проекту
        """
        # Створюємо основні шляхи
        project_path = f"{base_path}/{project_name}"
        text_file_path = f"{project_path}/{project_name}.txt"
        config_file_path = f"{project_path}/{project_name}_config.json"
        
        # Створюємо структуру папок
        folders = [
            project_path,
            f"{project_path}/outputs",
            f"{project_path}/temp",
            f"{project_path}/temp/input_sound",
            f"{project_path}/temp/input_melodu"
        ]
        
        for folder in folders:
            os.makedirs(folder, exist_ok=True)
            print(f"Створено папку: {folder}")
        
        # Копіюємо/створюємо текстовий файл
        if input_text_path and os.path.exists(input_text_path):
            shutil.copy2(input_text_path, text_file_path)
            print(f"Скопійовано текстовий файл: {text_file_path}")
        else:
            # Створюємо порожній текстовий файл
            with open(text_file_path, 'w', encoding='utf-8') as f:
                f.write("# Вхідний текст проекту\n\n")
            print(f"Створено порожній текстовий файл: {text_file_path}")
        
        # Копіюємо необхідні файли з source_config
        copied_files = ProjectManager._copy_required_files(source_config, project_path)
        
        # Створюємо конфігураційний файл з оновленими шляхами
        config = ProjectManager.create_project_config(project_path, project_name, copied_files)
        
        with open(config_file_path, 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        
        print(f"Створено конфігураційний файл: {config_file_path}")
        print(f"Структура проекту '{project_name}' успішно створена!")
        print(f"Скопійовано файлів: {len(copied_files)}")
        
        return config_file_path
    
    @staticmethod
    def _copy_required_files(source_config: Dict[str, Any], project_path: str) -> Dict[str, str]:
        """
        Копіює необхідні файли з source_config у проект
        
        Args:
            source_config (dict): Вихідний конфіг з шляхами до файлів
            project_path (str): Шлях до проекту
            
        Returns:
            dict: Словник {старий_шлях: новий_шлях} скопійованих файлів
        """
        if not source_config:
            return {}
            
        copied_files = {}
        
        try:
            # Копіюємо звукові файли
            for file_type, file_keys in ProjectManager.REQUIRED_FILES_TO_COPY.items():
                for file_key in file_keys:
                    config_key = None
                    
                    # Визначаємо правильний ключ у конфігу
                    if file_key in ["ACCENTS_FILE"]:
                        config_key = f"ACCENT_EDITOR_{file_key}"
                    elif file_key.startswith(("PAUSE_", "MELODY_", "TEST_")):
                        config_key = f"VOICE_TAGS_EDITOR_{file_key}"
                    elif file_key in ["SOUNDS_EFFECTS_LIST", "SOUNDS_EFFECTS_FILES"]:
                        config_key = f"SOUND_EFFECTS_EDITOR_{file_key}"
                    
                    if config_key and config_key in source_config:
                        source_file = source_config[config_key]
                        if source_file and os.path.exists(source_file):
                            # Визначаємо цільову папку
                            if file_key.startswith("PAUSE_") or file_key.startswith("MELODY_") or file_key == "TEST_wav":
                                dest_folder = f"{project_path}/temp/input_melodu"
                            elif file_key.endswith(".json"):
                                dest_folder = project_path
                            else:
                                dest_folder = f"{project_path}/temp/input_sound"
                            
                            os.makedirs(dest_folder, exist_ok=True)
                            
                            # Ім'я файлу в проекті
                            filename = os.path.basename(source_file)
                            dest_file = os.path.join(dest_folder, filename)
                            
                            # Копіюємо файл
                            shutil.copy2(source_file, dest_file)
                            copied_files[source_file] = dest_file
                            print(f"Скопійовано: {source_file} -> {dest_file}")
        
        except Exception as e:
            print(f"Помилка копіювання файлів: {e}")
        
        return copied_files
    
    @staticmethod
    def create_project_config(project_path: str, project_name: str, 
                            copied_files: Dict[str, str] = None) -> Dict[str, Any]:
        """
        Створює конфігурацію проекту з правильними шляхами
        
        Args:
            project_path (str): Шлях до проекту
            project_name (str): Назва проекту
            copied_files (dict): Словник скопійованих файлів {старий_шлях: новий_шлях}
            
        Returns:
            dict: Конфігурація проекту
        """
        base_path = f"{project_path}/{project_name}"
        
        # Базова конфігурація проекту
        config = {
            "COMMON_CONFIG_VERSION": "0_0_0_3",
            "COMMON_TEXT_WIDGET_FONT_SIZE": 56,
            "COMMON_BBTN_FONT_SIZE": 38,
            "COMMON_BBTN_HEIGHT": 120,
            "COMMON_ACCENT_CHAR": "́",
            "COMMON_INPUT_TEXT_FILE": f"{base_path}.txt",
            "COMMON_OUTPUT_FOLDER": f"{base_path}/outputs",
            "COMMON_TEMP_FOLDER": f"{base_path}/temp",
            "COMMON_VOICE_DICT": {
                "G1": "Розповідач",
                "G2": "Чоловік1", 
                "G3": "Чоловік2",
                "G4": "Жінка1",
                "G5": "Жінка2",
                "G6": "Хлопець",
                "G7": "Дівчина",
                "G8": "Думки чол",
                "G9": "Думки жін"
            },
            "COMMON_PAUSE_DICT": {
                "P4": "PAUSE_4",
                "P7": "PAUSE_7", 
                "P1": "PAUSE_1",
                "P2": "PAUSE_2"
            },
            "ACCENT_EDITOR_ACCENTS_FILE": f"{base_path}/accents.json",
            "ACCENT_EDITOR_OUTPUT_MP3_FOLDER": f"{base_path}/outputs",
            "ACCENT_EDITOR_TTS_MODE": "gTTS",
            "ACCENT_EDITOR_DO_SPLIT": False,
            "ACCENT_EDITOR_BOOKMARK": {
                "cursor": 0,
                "scroll": 0.0,
                "paragraph_index": 0
            },
            "VOICE_TAGS_EDITOR_PAUSE_4_MP3": f"{base_path}/temp/input_melodu/PAUSE_4.mp3",
            "VOICE_TAGS_EDITOR_PAUSE_7_MP3": f"{base_path}/temp/input_melodu/PAUSE_7.mp3",
            "VOICE_TAGS_EDITOR_PAUSE_1_MP3": f"{base_path}/temp/input_melodu/PAUSE_1.mp3",
            "VOICE_TAGS_EDITOR_PAUSE_2_MP3": f"{base_path}/temp/input_melodu/PAUSE_2.mp3",
            "VOICE_TAGS_EDITOR_PAUSE_4_WAV": f"{base_path}/temp/input_melodu/PAUSE_4.wav",
            "VOICE_TAGS_EDITOR_PAUSE_7_WAV": f"{base_path}/temp/input_melodu/PAUSE_7.wav",
            "VOICE_TAGS_EDITOR_PAUSE_1_WAV": f"{base_path}/temp/input_melodu/PAUSE_1.wav",
            "VOICE_TAGS_EDITOR_PAUSE_2_WAV": f"{base_path}/temp/input_melodu/PAUSE_2.wav",
            "VOICE_TAGS_EDITOR_MELODY_START_MP3": f"{base_path}/temp/input_melodu/MELODY_START.mp3",
            "VOICE_TAGS_EDITOR_MELODY_END_MP3": f"{base_path}/temp/input_melodu/MELODY_END.mp3",
            "VOICE_TAGS_EDITOR_MELODY_START_WAV": f"{base_path}/temp/input_melodu/MELODY_START.wav",
            "VOICE_TAGS_EDITOR_MELODY_END_WAV": f"{base_path}/temp/input_melodu/MELODY_END.wav",
            "VOICE_TAGS_EDITOR_TEST_WAV": f"{base_path}/temp/input_melodu/TEST.wav",
            "VOICE_TAGS_EDITOR_BOOKMARK": {
                "cursor": 0,
                "scroll": 0.0,
                "paragraph_index": 0
            },
            "SOUND_EFFECTS_EDITOR_SOUND_DICT": {
                "S1": "Звук_пострілу_part_022",
                "S2": "Машина_гальмує_part_027", 
                "S3": "Гарчання_мутанта1_part_047"
            },
            "SOUND_EFFECTS_EDITOR_SOUNDS_EFFECTS_LIST": f"{base_path}/scenarios_ozvuch.json",
            "SOUND_EFFECTS_EDITOR_SOUNDS_EFFECTS_FILES": f"{base_path}/sounds_effect_files_dict.json",
            "SOUND_EFFECTS_EDITOR_SOUNDS_EFFECTS_INPUT_FOLDER": f"{base_path}/temp/input_sound",
            "SOUND_EFFECTS_EDITOR_BOOKMARK": {
                "cursor": 0,
                "scroll": 0.0,
                "paragraph_index": 0
            },
            "MULTISPEAKER_TTS_INPUT_SOUNDS_FOLDER": f"{base_path}/temp/input_melodu",
            "MULTISPEAKER_TTS_FRAGMENT_SOFT_LIMIT": 900,
            "MULTISPEAKER_TTS_FRAGMENT_HARD_LIMIT": 1000,
            "MULTISPEAKER_TTS_DO_SPLIT": True,
            "MULTISPEAKER_TTS_DO_MERGE": False,
            "MULTISPEAKER_TTS_TTS_MODE": "TFile",
            "MULTISPEAKER_TTS_SOUND_DICT": {
                "S1": "Звук_пострілу_part_022",
                "S2": "Машина_гальмує_part_027", 
                "S3": "Гарчання_мутанта1_part_047"
            },
            "MULTISPEAKER_TTS_BOOKMARK": {
                "cursor": 0,
                "scroll": 0.0,
                "paragraph_index": 0
            }
        }
        
        # Оновлюємо шляхи на основі скопійованих файлів
        if copied_files:
            config = ProjectManager._update_config_paths(config, copied_files)
        
        return config
    
    @staticmethod
    def _update_config_paths(config: Dict[str, Any], copied_files: Dict[str, str]) -> Dict[str, Any]:
        """
        Оновлює шляхи у конфігурації на основі скопійованих файлів
        
        Args:
            config (dict): Початкова конфігурація
            copied_files (dict): Словник скопійованих файлів
            
        Returns:
            dict: Оновлена конфігурація
        """
        # Створюємо зворотній словник для пошуку
        old_to_new = copied_files
        
        for config_key, config_value in config.items():
            if isinstance(config_value, str) and config_value in old_to_new:
                config[config_key] = old_to_new[config_value]
        
        return config

    @staticmethod
    def list_projects(base_path: str = "/storage/emulated/0/projects") -> List[str]:
        """Показує список існуючих проектів"""
        if not os.path.exists(base_path):
            return []
        
        projects = [d for d in os.listdir(base_path) 
                   if os.path.isdir(os.path.join(base_path, d))]
        return sorted(projects)

    @staticmethod
    def validate_project_structure(project_name: str, 
                                 base_path: str = "/storage/emulated/0/book_projects") -> tuple:
        """
        Перевіряє коректність структури проекту
  base_path: str = "/storage/emulated/0/book_projects")      
        Returns:
            tuple: (bool, list) - Статус валідації та список проблем
        """
        project_path = f"{base_path}/{project_name}"
        problems = []
        
        required_files = [
            f"{project_path}/{project_name}.txt",
            f"{project_path}/{project_name}_config.json"
        ]
        
        required_folders = [
            f"{project_path}/outputs",
            f"{project_path}/temp/input_sound",
            f"{project_path}/temp/input_melodu"
        ]
        
        for file_path in required_files:
            if not os.path.exists(file_path):
                problems.append(f"Відсутній файл: {file_path}")
        
        for folder_path in required_folders:
            if not os.path.exists(folder_path):
                problems.append(f"Відсутня папка: {folder_path}")
        
        return len(problems) == 0, problems

    @staticmethod
    def get_project_config_path(project_name: str, base_path: str = "/storage/emulated/0/book_projects") -> str:
        """Повертає шлях до конфігураційного файлу проекту"""
        return f"{base_path}/{project_name}/{project_name}_config.json"


class ModularConfigManager:
    """
    Модульний менеджер конфігурації з автоматичним створенням проекту
    """

    def __init__(self, config_path: str = None, auto_create: bool = True):
        self.config_file = Path(config_path) if config_path else None
        self.data = {}
        self.project_manager = ProjectManager()
        
        # Налаштування логування
        self.logger = self._setup_logging()

        # Спільні параметри
        self.common_params = {
            'params': [
                'CONFIG_VERSION',
                'TEXT_WIDGET_FONT_SIZE',
                'BBTN_FONT_SIZE',
                'BBTN_HEIGHT',
                'ACCENT_CHAR',
                'INPUT_TEXT_FILE',
                'OUTPUT_FOLDER',
                'TEMP_FOLDER',
                'VOICE_DICT',
                'PAUSE_DICT'
            ],
            'defaults': {
                'CONFIG_VERSION': '0_0_0_3',
                'TEXT_WIDGET_FONT_SIZE': 56,
                'BBTN_FONT_SIZE': 38,
                'BBTN_HEIGHT': 120,
                'ACCENT_CHAR': '\u0301',
                'INPUT_TEXT_FILE': '',
                'OUTPUT_FOLDER': '',
                'TEMP_FOLDER': '',
                'VOICE_DICT': {
                    "G1": "Розповідач",
                    "G2": "Чоловік1", 
                    "G3": "Чоловік2",
                    "G4": "Жінка1",
                    "G5": "Жінка2",
                    "G6": "Хлопець",
                    "G7": "Дівчина",
                    "G8": "Думки чол",
                    "G9": "Думки жін"
                },
                'PAUSE_DICT': {
                    "P4": "PAUSE_4",
                    "P7": "PAUSE_7", 
                    "P1": "PAUSE_1",
                    "P2": "PAUSE_2"
                },
            }
        }
        
        # Особисті параметри редакторів
        self.editor_registry = {
            'accent_editor': {
                'params': [
                    'ACCENTS_FILE',
                    'OUTPUT_MP3_FOLDER', 
                    'TTS_MODE', 
                    'DO_SPLIT',
                    'BOOKMARK'
                ],
                'defaults': {
                    'ACCENTS_FILE': '',
                    'OUTPUT_MP3_FOLDER': '',
                    'TTS_MODE': 'gTTS', 
                    'DO_SPLIT': False,
                    'BOOKMARK': {'cursor': 0, 'scroll': 0.0, 'paragraph_index': 0}
                }
            },
            'voice_tags_editor': {
                'params': [
                    'PAUSE_4_MP3',
                    'PAUSE_7_MP3', 
                    'PAUSE_1_MP3', 
                    'PAUSE_2_MP3',
                    'PAUSE_4_WAV',
                    'PAUSE_7_WAV', 
                    'PAUSE_1_WAV', 
                    'PAUSE_2_WAV',
                    "MELODY_START_MP3",
                    "MELODY_END_MP3",
                    "MELODY_START_WAV",
                    "MELODY_END_WAV",
                    "TEST_WAV",                    
                    'BOOKMARK'
                ],
                'defaults': {
                    "PAUSE_4_MP3": "",
                    "PAUSE_7_MP3": "",
                    "PAUSE_1_MP3": "",
                    "PAUSE_2_MP3": "",
                    "PAUSE_4_WAV": "",
                    "PAUSE_7_WAV": "",
                    "PAUSE_1_WAV": "",
                    "PAUSE_2_WAV": "",
                    "MELODY_START_MP3": "",
                    "MELODY_END_MP3": "",
                    "MELODY_START_WAV": "",
                    "MELODY_END_WAV": "",
                    "TEST_WAV": "",
                    'BOOKMARK': {'cursor': 0, 'scroll': 0.0, 'paragraph_index': 0}
                }
            },
            'sound_effects_editor': {
                'params': [
                    'SOUNDS_EFFECTS_LIST', 
                    'SOUNDS_EFFECTS_FILES',
                    'SOUNDS_EFFECTS_INPUT_FOLDER',
                    'SOUND_DICT',
                    'BOOKMARK'
                ],
                'defaults': {
                    'SOUND_DICT': {
                        "S1": "Звук_пострілу_part_022",                        
                        "S2": "Машина_гальмує_part_027", 
                        "S3": "Гарчання_мутанта1_part_047"
                    },
                    'SOUNDS_EFFECTS_LIST': '',
                    'SOUNDS_EFFECTS_FILES': '',
                    'SOUNDS_EFFECTS_INPUT_FOLDER': '',
                    'BOOKMARK': {'cursor': 0, 'scroll': 0.0, 'paragraph_index': 0}
                }
            },
            'multispeaker_tts': {
                'params': [
                    'INPUT_SOUNDS_FOLDER',
                    'FRAGMENT_SOFT_LIMIT',
                    'FRAGMENT_HARD_LIMIT', 
                    'DO_SPLIT',
                    'DO_MERGE',
                    'TTS_MODE',
                    'SOUND_DICT',
                    'BOOKMARK'
                ],
                'defaults': {
                    'INPUT_SOUNDS_FOLDER': '',
                    'FRAGMENT_SOFT_LIMIT': 900,
                    'FRAGMENT_HARD_LIMIT': 1000,
                    'DO_SPLIT': True,
                    'DO_MERGE': False,
                    'TTS_MODE': 'TFile',
                    'SOUND_DICT': {
                        "S1": "Звук_пострілу_part_022",
                        "S2": "Машина_гальмує_part_027", 
                        "S3": "Гарчання_мутанта1_part_047"
                    },
                    'BOOKMARK': {'cursor': 0, 'scroll': 0.0, 'paragraph_index': 0}
                }
            }
        }
        
        # Автоматичне створення проекту при ініціалізації
        if auto_create and config_path:
            self._auto_create_project_structure()

    def _auto_create_project_structure(self):
        """Автоматично створює структуру проекту при ініціалізації"""
        try:
            if not self.config_file.exists():
                self.logger.info(f"_auto_create_project_structure: \nКонфіг не існує, створюємо проект...")
                
                # Отримуємо назву проекту з шляху конфігу
                project_name = self.config_file.parent.name
                base_path = self.config_file.parent.parent
                
                # Завантажуємо вихідний конфіг для копіювання файлів
                source_config = self._load_source_config()
                
                # Створюємо проект
                new_config_path = self.project_manager.create_project_structure(
                    project_name=project_name,
                    source_config=source_config,
                    base_path=str(base_path)
                )
                
                # Оновлюємо шлях до конфігу
                self.config_file = Path(new_config_path)
                
            # Завантажуємо конфіг
            self.load_full_config()
            
        except Exception as e:
            self.logger.error(f"_auto_create_project_structure: \nПомилка створення проекту: \n{e}")

    def _load_source_config(self) -> Dict[str, Any]:
        """
        Завантажує вихідний конфіг для копіювання файлів
        
        Returns:
            dict: Вихідний конфіг з шляхами до файлів
        """
        # Список можливих джерельних конфігів
        possible_configs = [
            "/storage/emulated/0/Documents/Json/config_m5_3.json",
            "/storage/emulated/0/Documents/pidgotovka_knigi/project_config.json",
            "/storage/emulated/0/Documents/config.json"
        ]
        
        for config_path in possible_configs:
            if os.path.exists(config_path):
                try:
                    with open(config_path, 'r', encoding='utf-8') as f:
                        return json.load(f)
                except Exception as e:
                    self.logger.warning(f"_load_source_config: \nПомилка завантаження {config_path}: {e}")
        
        self.logger.warning("_load_source_config: \nНе знайдено жодного вихідного конфігу")
        return {}

    # ===========================
    # Project Management Methods
    # ===========================

    def create_project(self, project_name: str, input_text_path: str = None, 
                      source_config_path: str = None) -> str:
        """
        Створює новий проект з автоматичною структурою
        
        Args:
            project_name (str): Назва проекту
            input_text_path (str, optional): Шлях до вихідного тексту
            source_config_path (str, optional): Шлях до вихідного конфігу для копіювання файлів
            
        Returns:
            str: Шлях до конфігураційного файлу проекту
        """
        try:
            # Завантажуємо вихідний конфіг
            source_config = {}
            if source_config_path and os.path.exists(source_config_path):
                with open(source_config_path, 'r', encoding='utf-8') as f:
                    source_config = json.load(f)
            
            config_path = self.project_manager.create_project_structure(
                project_name=project_name,
                source_config=source_config,
                input_text_path=input_text_path
            )
            
            # Оновлюємо поточний конфіг менеджер на новий проект
            self.config_file = Path(config_path)
            self.load_full_config()
            
            self.logger.info(f"create_project: \nСтворено новий проект: \n{project_name}\nШлях: {config_path}")
            return config_path
            
        except Exception as e:
            self.logger.error(f"create_project: \nПомилка створення проекту: \n{e}")
            raise

    def list_projects(self) -> List[str]:
        """Повертає список доступних проектів"""
        return self.project_manager.list_projects()

    def validate_current_project(self) -> tuple:
        """
        Перевіряє структуру поточного проекту
        
        Returns:
            tuple: (bool, list) - Статус валідації та список проблем
        """
        if not self.config_file.exists():
            return False, ["Конфігураційний файл не існує"]
        
        project_name = self.config_file.parent.name
        return self.project_manager.validate_project_structure(project_name)

    def get_current_project_info(self) -> Dict[str, Any]:
        """
        Повертає інформацію про поточний проект
        
        Returns:
            dict: Інформація про проект
        """
        if not self.config_file.exists():
            return {}
        
        project_name = self.config_file.parent.name
        project_path = self.config_file.parent
        
        is_valid, problems = self.validate_current_project()
        
        return {
            'name': project_name,
            'path': str(project_path),
            'config_path': str(self.config_file),
            'is_valid': is_valid,
            'problems': problems,
            'text_file': self.get_common_param('INPUT_TEXT_FILE', ''),
            'output_folder': self.get_common_param('OUTPUT_FOLDER', '')
        }

    def switch_project(self, project_name: str) -> bool:
        """
        Перемикає на інший проект
        
        Args:
            project_name (str): Назва проекту для перемикання
            
        Returns:
            bool: Успішність перемикання
        """
        base_path = "/storage/emulated/0/book_projects"
        new_config_path = self.project_manager.get_project_config_path(project_name, base_path)
        
        if not os.path.exists(new_config_path):
            self.logger.error(f"switch_project: \nПроект не знайдено: \n{project_name}")
            return False
        
        self.config_file = Path(new_config_path)
        self.load_full_config()
        
        self.logger.info(f"switch_project: \nПереключено на проект: \n{project_name}")
        return True

    def add_files_to_project(self, files_to_copy: Dict[str, str]) -> bool:
        """
        Додає додаткові файли до проекту
        
        Args:
            files_to_copy (dict): Словник {source_path: destination_relative_path}
            
        Returns:
            bool: Успішність операції
        """
        if not self.config_file.exists():
            self.logger.error("add_files_to_project: \nПроект не ініціалізований")
            return False
        
        project_path = self.config_file.parent
        
        try:
            for source_path, dest_rel in files_to_copy.items():
                if os.path.exists(source_path):
                    dest_path = project_path / dest_rel
                    dest_path.parent.mkdir(parents=True, exist_ok=True)
                    
                    shutil.copy2(source_path, dest_path)
                    self.logger.info(f"add_files_to_project: \nСкопійовано: {source_path} -> {dest_path}")
                else:
                    self.logger.warning(f"add_files_to_project: \nФайл не знайдено: {source_path}")
            
            return True
            
        except Exception as e:
            self.logger.error(f"add_files_to_project: \nПомилка копіювання файлів: \n{e}")
            return False

    # ===========================
    # Existing Configuration Methods
    # ===========================

    def _setup_logging(self):
        """Налаштовує логування для config_manager"""
        test_dir = Path('/storage/emulated/0/a0_sb2_book_editors_suite/testing_function')
        log_dir = test_dir / 'logs'
        log_dir.mkdir(parents=True, exist_ok=True)
        
        logger = logging.getLogger('config_manager')
        logger.setLevel(logging.INFO)
        
        if not logger.handlers:
            log_file = log_dir / 'config_manager.log'
            file_handler = logging.FileHandler(log_file, encoding='utf-8')
            file_handler.setLevel(logging.INFO)
            
            formatter = logging.Formatter(
                '\n%(asctime)s | %(levelname)-8s | %(name)s\n%(message)s\n',
                datefmt='%Y-%m-%d %H:%M:%S'
            )
            file_handler.setFormatter(formatter)
            
            logger.addHandler(file_handler)
            
            console_handler = logging.StreamHandler()
            console_handler.setLevel(logging.INFO)
            console_handler.setFormatter(formatter)
            logger.addHandler(console_handler)
        
        return logger

    def ensure_config(self):
        """Створює базовий конфіг, якщо його не існує"""
        if not self.config_file.exists():
            self.config_file.parent.mkdir(parents=True, exist_ok=True)
            
            base_config = {}
            
            # Додаємо спільні параметри
            for param, value in self.common_params['defaults'].items():
                common_param = f"COMMON_{param.upper()}"
                base_config[common_param] = value
            
            # Додаємо особисті параметри кожного редактора
            for editor_name, editor_info in self.editor_registry.items():
                for param, value in editor_info['defaults'].items():
                    personal_param = f"{editor_name.upper()}_{param.upper()}"
                    base_config[personal_param] = value
            
            self.save_full_config(base_config)
            self.logger.info(f"ensure_config: \nСтворено новий конфіг: \n{self.config_file}")

    def load_full_config(self) -> Dict[str, Any]:
        """Завантажує повний конфіг з файлу"""
        self.ensure_config()
        
        if self.config_file.exists():
            try:
                with open(self.config_file, "r", encoding="utf-8") as f:
                    self.data = json.load(f)
                self.logger.info(f"load_full_config: \nЗавантажено конфіг: \n{len(self.data)} параметрів")
            except Exception as e:
                self.logger.error(f"load_full_config: \nПомилка завантаження конфігу: \n{e}")
                self.data = {}
        return self.data

    def load_for_editor(self, editor_name: str) -> Dict[str, Any]:
        """Завантажує тільки параметри потрібні конкретному редактору"""
        if editor_name not in self.editor_registry:
            error_msg = f"load_for_editor: \nНевідомий редактор: \n{editor_name}"
            self.logger.error(error_msg)
            raise ValueError(error_msg)
            
        editor_config = {}
        
        # Завантажуємо спільні параметри
        for param in self.common_params['params']:
            common_key = f"COMMON_{param.upper()}"
            if common_key in self.data:
                editor_config[param] = self.data[common_key]
            elif param in self.common_params['defaults']:
                editor_config[param] = self.common_params['defaults'][param]
        
        # Завантажуємо особисті параметри редактора
        for param in self.editor_registry[editor_name]['params']:
            personal_key = f"{editor_name.upper()}_{param.upper()}"
            if personal_key in self.data:
                editor_config[param] = self.data[personal_key]
            elif param in self.editor_registry[editor_name]['defaults']:
                editor_config[param] = self.editor_registry[editor_name]['defaults'][param]
        
        self.logger.info(f"load_for_editor: \nЗавантажено конфіг для {editor_name}: \n{len(editor_config)} параметрів")
        return editor_config

    def save_from_editor(self, editor_name: str, editor_data: Dict[str, Any]):
        """Зберігає тільки особисті параметри від конкретного редактора"""
        if editor_name not in self.editor_registry:
            error_msg = f"save_from_editor: \nНевідомий редактор: \n{editor_name}"
            self.logger.error(error_msg)
            raise ValueError(error_msg)
            
        updated_params = []
        
        for param, value in editor_data.items():
            if param in self.editor_registry[editor_name]['params']:
                personal_param = f"{editor_name.upper()}_{param.upper()}"
                self.data[personal_param] = value
                updated_params.append(personal_param)
        
        if updated_params:
            self.save_full_config()
            self.logger.info(f"save_from_editor: \nОновлено особисті параметри {editor_name}: \n{len(updated_params)} параметрів")

    def save_full_config(self, data: Dict[str, Any] = None):
        """Зберігає повний конфіг у файл"""
        if data is not None:
            self.data = data
            
        try:
            self.config_file.parent.mkdir(parents=True, exist_ok=True)
            with open(self.config_file, "w", encoding="utf-8") as f:
                json.dump(self.data, f, ensure_ascii=False, indent=2)
            self.logger.info(f"save_full_config: \nУспішно збережено конфіг: \n{self.config_file}")
            return True
        except Exception as e:
            self.logger.error(f"save_full_config: \nПомилка збереження конфігу: \n{e}")
            return False

    # ... (решта методів залишаються незмінними)
# ======================

#-------------------------------------------
    def load_config_dict(self) -> Dict[str, Any]:
        """Завантажує конфіг як словник"""
        if self.config_file.exists():
            try:
                with open(self.config_file, "r", encoding="utf-8") as f:
                    return json.load(f) or {}
            except Exception as e:
                self.logger.error(f"load_config_dict: \nПомилка читання конфігу: \n{e}\n")
                return {}
        return {}

#-------------------------------------------
    def update_bookmark(self, editor_name: str, cursor_pos: int, scroll_y: float, paragraph_index: int):
        """Оновлює закладку для конкретного редактора з новими полями."""
        updates = {
            'BOOKMARK': {
                'cursor': int(cursor_pos),
                'scroll': float(scroll_y),
                'paragraph_index': int(paragraph_index)
            }
        }
        self.save_from_editor(editor_name, updates)
        self.logger.info(f"update_bookmark: \nОновлено закладку для {editor_name}: \nparagraph={paragraph_index}, cursor={cursor_pos}, scroll={scroll_y}\n")

#-------------------------------------------       
    def get_bookmark(self, editor_name: str) -> Dict[str, Any]:
        """Отримує закладку для конкретного редактора з новими полями."""
        editor_config = self.load_for_editor(editor_name)
        bookmark = editor_config.get('BOOKMARK', {'cursor': 0, 'scroll': 0.0, 'paragraph_index': 0})
        return {
            'scroll_y': bookmark.get('scroll', 0.0),
            'cursor_pos': bookmark.get('cursor', 0),
            'paragraph_index': bookmark.get('paragraph_index', 0)
        }

#-------------------------------------------
    def get_common_param(self, param_name: str, default=None):
        """Отримує значення спільного параметра (тільки читання)"""
        common_param = f"COMMON_{param_name.upper()}"
        return self.data.get(common_param, default)

#-------------------------------------------
    def get_personal_param(self, editor_name: str, param_name: str, default=None):
        """Отримує значення особистого параметра"""
        if editor_name not in self.editor_registry:
            error_msg = f"get_personal_param: \nНевідомий редактор: \n{editor_name}\n"
            self.logger.error(error_msg)
            raise ValueError(error_msg)
            
        personal_param = f"{editor_name.upper()}_{param_name.upper()}\n"
        return self.data.get(personal_param, default)

#-------------------------------------------        
    def set_personal_param(self, editor_name: str, param_name: str, value):
        """Встановлює значення особистого параметра"""
        if editor_name not in self.editor_registry:
            error_msg = f"set_personal_param: \nНевідомий редактор: \n{editor_name}\n"
            self.logger.error(error_msg)
            raise ValueError(error_msg)
            
        if param_name not in self.editor_registry[editor_name]['params']:
            self.logger.warning(f"set_personal_param: \nПараметр {param_name} не знайдено в особистих параметрах {editor_name}\n")
            return False
            
        personal_param = f"{editor_name.upper()}_{param_name.upper()}"
        self.data[personal_param] = value
        return self.save_full_config()

#-------------------------------------------
    def update_voice_dict(self, editor_name: str, voice_dict: Dict[str, str]):
        """Оновлює словник голосів для конкретного редактора"""
        self.set_personal_param(editor_name, 'voice_dict', voice_dict)

  #-------------------------------------------       
    def update_sound_dict(self, editor_name: str, sound_dict: Dict[str, str]):
        """Оновлює словник звукових ефектів для конкретного редактора"""
        self.set_personal_param(editor_name, 'sound_dict', sound_dict)

#-------------------------------------------
    def sanitize_name(self, s: str, for_filename: bool = True) -> str:
        """Очищує рядок для використання в назвах файлів"""
        s2 = re.sub(r"^##\s* ", "", s)
        s2 = re.sub(r"#g\d+: ? ", "", s2)
        s2 = re.sub(r"#S\d+: ? ", "", s2)
        s2 = s2.strip()
        
        if for_filename:
            s2 = re.sub(r"[^\w\d_-]", "_", s2)
            if not s2:
                s2 = "Глава"
        return s2

#-------------------------------------------        
    def get_editor_info(self, editor_name: str) -> Dict[str, Any]:
        """Повертає інформацію про редактор та його параметри"""
        if editor_name not in self.editor_registry:
            return {}
        
        info = {
            'name': editor_name,
            'personal_params': self.editor_registry[editor_name]['params'],
            'common_params': self.common_params['params'],
            'loaded_config': self.load_for_editor(editor_name)
        }
        
        self.logger.info(f"get_editor_info: \nОтримано інформацію про редактор: \n{editor_name}\n")
        return info

#-------------------------------------------                
    def list_editors(self) -> List[str]:
        """Повертає список доступних редакторів"""
        editors = list(self.editor_registry.keys())
        self.logger.info(f"list_editors: \nСписок доступних редакторів: \n{editors}\n")
        return editors
# ==================
# ======================
# Синглтон для глобального доступу
_global_config_manager = None

def get_config_manager(config_path: str = None, auto_create: bool = True) -> ModularConfigManager:
    """Повертає глобальний екземпляр менеджера конфігурації"""
    global _global_config_manager
    if _global_config_manager is None and config_path:
        _global_config_manager = ModularConfigManager(config_path, auto_create)
    return _global_config_manager

def reset_config_manager():
    """Скидає глобальний екземпляр менеджера конфігурації"""
    global _global_config_manager
    _global_config_manager = None
    logger = logging.getLogger('config_manager')
    logger.info("reset_config_manager: \nСинглтон конфіг менеджера скинуто")

# Експорт функцій та класів
__all__ = ['ModularConfigManager', 'ProjectManager', 'get_config_manager', 'reset_config_manager']