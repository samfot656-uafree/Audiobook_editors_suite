#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Основний файл multispeaker_tts з автоматичним створенням проекту

import os
import sys
from pathlib import Path

# Додаємо шлях до модулів
sys.path.append('/storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite')

from core.config_manager import get_config_manager

def main():
    # Шлях до проекту (можна отримати з аргументів командного рядка)
    if len(sys.argv) > 1:
        project_config_path = sys.argv[1]
    else:
        # Створюємо проект за замовчуванням
        project_name = "Чекаючий_1_1_Шлях_до_заснування"
        project_config_path = f"/storage/emulated/0/book_projects/{project_name}/{project_name}_config.json"
    
    # Ініціалізуємо конфіг менеджер з автоматичним створенням структури
    config_manager = get_config_manager(project_config_path, auto_create=True)
    
    # Перевіряємо проект
    project_info = config_manager.get_current_project_info()
    print(f"Проект: {project_info['name']}")
    print(f"Валідний: {project_info['is_valid']}")
    
    if not project_info['is_valid']:
        print("Проблеми з проектом:")
        for problem in project_info['problems']:
            print(f" - {problem}")
    
    # Завантажуємо конфіг для multispeaker_tts
    config = config_manager.load_for_editor('multispeaker_tts')
    
    print(f"TTS_MODE: {config.get('TTS_MODE')}")
    print(f"INPUT_TEXT_FILE: {config.get('INPUT_TEXT_FILE')}")
    
    # Тепер можна запускати основний процес...
    # process_input_file(config['INPUT_TEXT_FILE'])

if __name__ == '__main__':
    main()