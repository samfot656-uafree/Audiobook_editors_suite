from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.spinner import Spinner
from kivy.uix.popup import Popup
from kivy.clock import Clock
import threading
from pathlib import Path

from core.text_processor import TextProcessor
from ui.popups import EditWordPopup, ExtraButtonsPopup


class MainLayout(BoxLayout):
    """Головний layout додатку."""
    
    def __init__(self, main_app, **kwargs):
        super().__init__(orientation="vertical", spacing=5, padding=22, **kwargs)
        self.main_app = main_app
        self.config = main_app.config_manager
        self.text_processor = TextProcessor()
        
        # UI елементи
        self.text_widget = None
        self.voice_buttons = []
        self.current_speed = "normal"
        self.current_file = self.config.input_text_file
        
        # Контекст виділеного слова
        self._current_word_context = None
        
        self.build_ui()
        self.apply_theme(self.main_app.theme_mode)

    def build_ui(self):
        """Побудова інтерфейсу."""
        # Верхня панель
        top_row = BoxLayout(
            orientation='horizontal', 
            size_hint_y=None, 
            height=self.config.bbtn_height, 
            spacing=8
        )
        
        self.speed_spinner = Spinner(
            text="normal",
            values=("slow", "normal", "fast"),
            font_size=self.config.bbtn_font_size,
            size_hint_x=None, 
            width=self.config.bbtn_height,
        )
        self.speed_spinner.bind(text=self.set_speed_mode)

        self.btn_listen = Button(text="Слухати", font_size=self.config.bbtn_font_size)
        self.btn_pause = Button(text="Пауза", font_size=self.config.bbtn_font_size)
        self.btn_edit = Button(text="Правити", font_size=self.config.bbtn_font_size, disabled=True)
        self.btn_extra = Button(text=". . .", font_size=self.config.bbtn_font_size)

        for b in (self.speed_spinner, self.btn_listen, self.btn_pause, self.btn_edit, self.btn_extra):
            top_row.add_widget(b)

        # Панель голосів
        gvoices = list(self.config.voice_dict.keys())
        rows = max(1, (len(gvoices) + 2) // 3)
        self.voice_grid = GridLayout(
            cols=3, 
            size_hint_y=None, 
            height=rows * self.config.bbtn_height, 
            spacing=8
        )
        
        if gvoices:
            for tag in gvoices:
                display = f"{self.config.voice_dict.get(tag, '')} {tag}"
                b = Button(text=display, font_size=self.config.bbtn_font_size)
                b.bind(on_release=lambda inst, t=tag: self.add_voice_tag(t))
                self.voice_grid.add_widget(b)
                self.voice_buttons.append(b)
        else:
            self.voice_grid.add_widget(Label(text="Голосів немає", font_size=self.config.bbtn_font_size))

        # Текстове поле
        self.text_widget = TextInput(text="", multiline=True, font_size=58)
        self.text_widget.bind(on_touch_down=self.on_text_touch)

        self.add_widget(top_row)
        self.add_widget(self.voice_grid)
        self.add_widget(self.text_widget)

        # Прив'язки кнопок
        self.btn_listen.bind(on_press=self.listen_tagged_fragment)
        self.btn_pause.bind(on_press=lambda *_: self.main_app.tts_manager.stop())
        self.btn_edit.bind(on_press=self.open_edit_popup)
        self.btn_extra.bind(on_press=lambda *_: ExtraButtonsPopup(self.main_app).open())

    def set_speed_mode(self, spinner, value):
        self.current_speed = value

    def add_voice_tag(self, tag):
        speed = self.current_speed
        full_tag = f"\n#{tag}: " if speed.lower() == "normal" else f"\n#{tag}_{speed.lower()}: "
        
        if not self.text_widget:
            return
            
        try:
            cursor = self.text_widget.cursor_index()
        except Exception:
            cursor = len(self.text_widget.text)
            
        self.text_widget.text = self.text_widget.text[:cursor] + full_tag + self.text_widget.text[cursor:]
        Clock.schedule_once(lambda dt: self._set_cursor_by_index(cursor + len(full_tag)), 0)

    def listen_tagged_fragment(self, *args):
        if not self.text_widget:
            return
            
        try:
            idx = self.text_widget.cursor_index()
        except Exception:
            idx = 0
            
        text = self.text_widget.text or ""
        fragment, speed, _ = self.text_processor.find_tagged_fragment(text, idx)
        
        if fragment:
            self.main_app.tts_manager.speak(fragment, speed)
        else:
            self.show_status("Текст між тегами не знайдено")

    def on_text_touch(self, instance, touch):
        if not instance.collide_point(*touch.pos):
            return False
        Clock.schedule_once(lambda *_: self.detect_word_at_cursor(), 0.03)
        return False

    def detect_word_at_cursor(self):
        if not self.text_widget:
            return
            
        try:
            idx = self.text_widget.cursor_index()
        except Exception:
            idx = len(self.text_widget.text) if self.text_widget.text else 0
            
        text = self.text_widget.text or ""
        word, before, after = self.text_processor.detect_word_at_cursor(text, idx)
        
        if word:
            self.btn_edit.disabled = False
            # Зберігаємо контекст для подальшої заміни
            self._current_word_context = (word, before, after)
        else:
            self.btn_edit.disabled = True
            self._current_word_context = None

    def open_edit_popup(self, *_):
        if self._current_word_context:
            word, _, _ = self._current_word_context
            self.main_app.tts_manager.stop()
            EditWordPopup(self.main_app, word).open()

    def replace_current_word(self, new_word: str):
        """Замінює поточне слово на нове."""
        if not self._current_word_context:
            return
            
        old_word, before, after = self._current_word_context
        replaced = self.text_processor.match_casing(old_word, new_word)
        new_txt = before + replaced + after
        self.text_widget.text = new_txt
        
        # Ставимо курсор після вставленого слова
        new_pos = len(before) + len(replaced)
        Clock.schedule_once(lambda dt: self._set_cursor_by_index(new_pos), 0)

    def _set_cursor_by_index(self, idx: int):
        if not self.text_widget:
            return
        try:
            self.text_widget.cursor = self.text_widget.get_cursor_from_index(idx)
        except Exception:
            try:
                self.text_widget.cursor_index = idx
            except Exception:
                pass

    def _set_cursor_and_scroll(self, cursor_idx: int, scroll_y: float):
        """Встановлює курсор і прокрутку (scroll_y)."""
        if not self.text_widget:
            return
        try:
            # курсор
            self._set_cursor_by_index(int(cursor_idx))
        except Exception:
            pass
        try:
            # scroll_y: TextInput використовує значення від 0..1 (1 - top)
            self.text_widget.scroll_y = float(scroll_y)
        except Exception:
            pass

    def open_file_async(self, *args):
        """Асинхронне відкриття файлу."""
        def load_file(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    content = f.read()
                Clock.schedule_once(lambda dt: self.set_text(content), 0)
            except Exception as e:
                Clock.schedule_once(lambda dt: self.show_error_popup(str(e)), 0)

        if not self.current_file or not Path(self.current_file).exists():
            self.show_error_popup("Файл не вказаний або не існує")
            return
            
        t = threading.Thread(target=load_file, args=(self.current_file,), daemon=True)
        t.start()

    def set_text(self, text):
        """Встановлює текст у віджет та відновлює позицію."""
        if self.text_widget:
            self.text_widget.text = text
            self.open_bookmark()

    def open_bookmark(self):
        """Відновлює позиції із конфіга."""
        try:
            scroll_y = self.config.tags_editor_scroll_y
            cursor_pos = self.config.tags_editor_cursor_pos
            
            # Встановлюємо прокрутку
            self.text_widget.scroll_y = float(scroll_y)
            
            # Встановлюємо курсор
            if cursor_pos > 0:
                Clock.schedule_once(lambda dt: self._set_cursor_by_index(cursor_pos), 0.08)
            else:
                Clock.schedule_once(lambda dt: self._set_cursor_by_index(0), 0.05)
                
        except Exception as e:
            print(f"⚠️ Не вдалося відновити закладку: {e}")
            # Резервний варіант - відкрити з початку
            self.text_widget.scroll_y = 1.0
            self._set_cursor_by_index(0)

    def save_file(self, *args):
        """Зберігає файл та закладку."""
        if not self.current_file:
            self.show_error_popup("Файл не вказаний")
            return
            
        try:
            if not self.text_widget or self.text_widget.text == "":
                self.show_error_popup("Текстове поле порожнє")
                return

            # Записуємо текст у файл
            with open(self.current_file, "w", encoding="utf-8") as f:
                f.write(self.text_widget.text if self.text_widget else "")

            # Зберігаємо закладку з новою структурою
            try:
                cursor_idx = self.text_widget.cursor_index()
            except Exception:
                cursor_idx = 0
                
            try:
                scroll_y = float(getattr(self.text_widget, "scroll_y", 1.0))
            except Exception:
                scroll_y = 1.0

            self.config.save_bookmark(int(cursor_idx), float(scroll_y))

            popup_text = f"Файл збережено:\n{self.current_file}"
            Popup(title="Збережено", content=Label(text=popup_text), size_hint=(0.9, 0.35)).open()
        except Exception as e:
            self.show_error_popup(f"Помилка збереження: {str(e)}")

    def reset_bookmark(self):
        """Скидає закладку в конфіг — відкривати буде з початку."""
        try:
            self.config.reset_bookmark()
            # Оновлюємо UI
            self.text_widget.scroll_y = 1.0
            self._set_cursor_by_index(0)
            
            Popup(title="Закладка скинута", 
                  content=Label(text="Відкриття з початку тексту буде активне."), 
                  size_hint=(0.9, 0.35)).open()
        except Exception as e:
            self.show_error_popup(f"Помилка скидання закладки: {str(e)}")

    def show_error_popup(self, message):
        """Показує popup з помилкою."""
        Popup(title="Помилка", content=Label(text=message), size_hint=(0.9, 0.35)).open()

    def show_status(self, txt: str):
        """Показує статусне повідомлення."""
        Popup(title="Повідомлення", content=Label(text=txt), size_hint=(0.9, 0.35)).open()

    def apply_theme(self, theme_mode):
        """Застосовує тему до всіх віджетів."""
        colors = self.get_theme_colors(theme_mode)
        
        # Застосування кольорів до всіх віджетів
        widgets = [self.speed_spinner, self.btn_listen, self.btn_pause, self.btn_edit, self.btn_extra]
        widgets.extend(self.voice_buttons)
        
        for widget in widgets:
            if widget:
                widget.background_normal = ""
                widget.background_color = colors["button_bg"]
                widget.color = colors["button_fg"]
                
        if self.text_widget:
            self.text_widget.background_color = colors["input_bg"]
            self.text_widget.foreground_color = colors["input_fg"]
            self.text_widget.cursor_color = (0.03, 0.85, 0.53, 1)

    def get_theme_colors(self, theme_mode):
        """Повертає кольори для теми."""
        if theme_mode == "day":
            return {
                "button_bg": (0.5, 0.5, 0.5, 1),
                "button_fg": (1, 1, 1, 1),
                "input_bg": (1, 1, 1, 1),
                "input_fg": (0, 0, 0, 1)
            }
        else:
            return {
                "button_bg": (0, 0, 0, 1),
                "button_fg": (0, 0.3, 0.5, 1),
                "input_bg": (0, 0, 0, 1),
                "input_fg": (0, 0, 0.7, 1)
            }


#from kivy.uix.boxlayout import BoxLayout
#from kivy.uix.gridlayout import GridLayout
#from kivy.uix.button import Button
#from kivy.uix.label import Label
#from kivy.uix.textinput import TextInput
#from kivy.uix.spinner import Spinner
#from kivy.uix.popup import Popup
#from kivy.clock import Clock
#import threading
#from pathlib import Path

#from core.text_processor import TextProcessor
#from ui.popups import EditWordPopup, ExtraButtonsPopup


#class MainLayout(BoxLayout):
#    """Головний layout додатку."""
#    
#    def __init__(self, main_app, **kwargs):
#        super().__init__(orientation="vertical", spacing=5, padding=22, **kwargs)
#        self.main_app = main_app
#        self.config = main_app.config_manager
#        self.text_processor = TextProcessor()
#        
#        # UI елементи
#        self.text_widget = None
#        self.voice_buttons = []
#        self.current_speed = "normal"
#        self.current_file = self.config.input_text_file
#        
#        # Контекст виділеного слова
#        self._current_word_context = None
#        
#        self.build_ui()
#        self.apply_theme(self.main_app.theme_mode)

#    def build_ui(self):
#        """Побудова інтерфейсу."""
#        # Верхня панель
#        top_row = BoxLayout(
#            orientation='horizontal', 
#            size_hint_y=None, 
#            height=self.config.bbtn_height, 
#            spacing=8
#        )
#        
#        self.speed_spinner = Spinner(
#            text="normal",
#            values=("slow", "normal", "fast"),
#            font_size=self.config.bbtn_font_size,
#            size_hint_x=None, 
#            width=self.config.bbtn_height,
#        )
#        self.speed_spinner.bind(text=self.set_speed_mode)

#        self.btn_listen = Button(text="Слухати", font_size=self.config.bbtn_font_size)
#        self.btn_pause = Button(text="Пауза", font_size=self.config.bbtn_font_size)
#        self.btn_edit = Button(text="Правити", font_size=self.config.bbtn_font_size, disabled=True)
#        self.btn_extra = Button(text=". . .", font_size=self.config.bbtn_font_size)

#        for b in (self.speed_spinner, self.btn_listen, self.btn_pause, self.btn_edit, self.btn_extra):
#            top_row.add_widget(b)

#        # Панель голосів
#        gvoices = list(self.config.voice_dict.keys())
#        rows = max(1, (len(gvoices) + 2) // 3)
#        self.voice_grid = GridLayout(
#            cols=3, 
#            size_hint_y=None, 
#            height=rows * self.config.bbtn_height, 
#            spacing=8
#        )
#        
#        if gvoices:
#            for tag in gvoices:
#                display = f"{self.config.voice_dict.get(tag, '')} {tag}"
#                b = Button(text=display, font_size=self.config.bbtn_font_size)
#                b.bind(on_release=lambda inst, t=tag: self.add_voice_tag(t))
#                self.voice_grid.add_widget(b)
#                self.voice_buttons.append(b)
#        else:
#            self.voice_grid.add_widget(Label(text="Голосів немає", font_size=self.config.bbtn_font_size))

#        # Текстове поле
#        self.text_widget = TextInput(text="", multiline=True, font_size=58)
#        self.text_widget.bind(on_touch_down=self.on_text_touch)

#        self.add_widget(top_row)
#        self.add_widget(self.voice_grid)
#        self.add_widget(self.text_widget)

#        # Прив'язки кнопок
#        self.btn_listen.bind(on_press=self.listen_tagged_fragment)
#        self.btn_pause.bind(on_press=lambda *_: self.main_app.tts_manager.stop())
#        self.btn_edit.bind(on_press=self.open_edit_popup)
#        self.btn_extra.bind(on_press=lambda *_: ExtraButtonsPopup(self.main_app).open())

#    def set_speed_mode(self, spinner, value):
#        self.current_speed = value

#    def add_voice_tag(self, tag):
#        speed = self.current_speed
#        full_tag = f"\n#{tag}: " if speed.lower() == "normal" else f"\n#{tag}_{speed.lower()}: "
#        
#        if not self.text_widget:
#            return
#            
#        try:
#            cursor = self.text_widget.cursor_index()
#        except Exception:
#            cursor = len(self.text_widget.text)
#            
#        self.text_widget.text = self.text_widget.text[:cursor] + full_tag + self.text_widget.text[cursor:]
#        Clock.schedule_once(lambda dt: self._set_cursor_by_index(cursor + len(full_tag)), 0)

#    def listen_tagged_fragment(self, *args):
#        if not self.text_widget:
#            return
#            
#        try:
#            idx = self.text_widget.cursor_index()
#        except Exception:
#            idx = 0
#            
#        text = self.text_widget.text or ""
#        fragment, speed, _ = self.text_processor.find_tagged_fragment(text, idx)
#        
#        if fragment:
#            self.main_app.tts_manager.speak(fragment, speed)
#        else:
#            self.show_status("Текст між тегами не знайдено")

#    def on_text_touch(self, instance, touch):
#        if not instance.collide_point(*touch.pos):
#            return False
#        Clock.schedule_once(lambda *_: self.detect_word_at_cursor(), 0.03)
#        return False

#    def detect_word_at_cursor(self):
#        if not self.text_widget:
#            return
#            
#        try:
#            idx = self.text_widget.cursor_index()
#        except Exception:
#            idx = len(self.text_widget.text) if self.text_widget.text else 0
#            
#        text = self.text_widget.text or ""
#        word, before, after = self.text_processor.detect_word_at_cursor(text, idx)
#        
#        if word:
#            self.btn_edit.disabled = False
#            # Зберігаємо контекст для подальшої заміни
#            self._current_word_context = (word, before, after)
#        else:
#            self.btn_edit.disabled = True
#            self._current_word_context = None

#    def open_edit_popup(self, *_):
#        if self._current_word_context:
#            word, _, _ = self._current_word_context
#            self.main_app.tts_manager.stop()
#            EditWordPopup(self.main_app, word).open()

#    def replace_current_word(self, new_word: str):
#        """Замінює поточне слово на нове."""
#        if not self._current_word_context:
#            return
#            
#        old_word, before, after = self._current_word_context
#        replaced = self.text_processor.match_casing(old_word, new_word)
#        new_txt = before + replaced + after
#        self.text_widget.text = new_txt
#        
#        # Ставимо курсор після вставленого слова
#        new_pos = len(before) + len(replaced)
#        Clock.schedule_once(lambda dt: self._set_cursor_by_index(new_pos), 0)

#    def _set_cursor_by_index(self, idx: int):
#        if not self.text_widget:
#            return
#        try:
#            self.text_widget.cursor = self.text_widget.get_cursor_from_index(idx)
#        except Exception:
#            try:
#                self.text_widget.cursor_index = idx
#            except Exception:
#                pass

#    def _set_cursor_and_scroll(self, cursor_idx: int, scroll_y: float):
#        """Встановлює курсор і прокрутку (scroll_y)."""
#        if not self.text_widget:
#            return
#        try:
#            # курсор
#            self._set_cursor_by_index(int(cursor_idx))
#        except Exception:
#            pass
#        try:
#            # scroll_y: TextInput використовує значення від 0..1 (1 - top)
#            self.text_widget.scroll_y = float(scroll_y)
#        except Exception:
#            pass

#    def open_file_async(self, *args):
#        """Асинхронне відкриття файлу."""
#        def load_file(path):
#            try:
#                with open(path, "r", encoding="utf-8") as f:
#                    content = f.read()
#                Clock.schedule_once(lambda dt: self.set_text(content), 0)
#            except Exception as e:
#                Clock.schedule_once(lambda dt: self.show_error_popup(str(e)), 0)

#        if not self.current_file or not Path(self.current_file).exists():
#            self.show_error_popup("Файл не вказаний або не існує")
#            return
#            
#        t = threading.Thread(target=load_file, args=(self.current_file,), daemon=True)
#        t.start()

#def set_text(self, text):
#    """Встановлює текст у віджет та відновлює позицію."""
#    if self.text_widget:
#        self.text_widget.text = text
#        self.open_bookmark()
#        
#    def set_stext(self, text):
#        """Встановлює текст у віджет та відновлює позицію."""
#        if self.text_widget:
#            self.text_widget.text = text

#            # Відновлюємо позицію з закладки
#            bk = getattr(self.config, "bookmark", {"cursor": 0, "scroll": 1.0})
#            cursor_pos = int(bk.get("cursor", 0))
#            scroll_pos = float(bk.get("scroll", 1.0))
#            
#            if cursor_pos > 0:
#                Clock.schedule_once(lambda dt: self._set_cursor_and_scroll(cursor_pos, scroll_pos), 0.08)
#            else:
#                Clock.schedule_once(lambda dt: self._set_cursor_and_scroll(0, 1.0), 0.05)

#    def save_sfile(self, *args):
#        """Зберігає файл та закладку."""
#        if not self.current_file:
#            self.show_error_popup("Файл не вказаний")
#            return
#            
#        try:
#            if not self.text_widget or self.text_widget.text == "":
#                self.show_error_popup("Текстове поле порожнє")
#                return

#            # Записуємо текст у файл
#            with open(self.current_file, "w", encoding="utf-8") as f:
#                f.write(self.text_widget.text if self.text_widget else "")

#            # Зберігаємо закладку
#            try:
#                cursor_idx = self.text_widget.cursor_index()
#            except Exception:
#                cursor_idx = 0
#                
#            try:
#                scroll_y = float(getattr(self.text_widget, "scroll_y", 1.0))
#            except Exception:
#                scroll_y = 1.0

#            self.config.save_bookmark(int(cursor_idx), float(scroll_y))

#            popup_text = f"Файл збережено:\n{self.current_file}"
#            Popup(title="Збережено", content=Label(text=popup_text), size_hint=(0.9, 0.35)).open()
#        except Exception as e:
#            self.show_error_popup(f"Помилка збереження: {str(e)}")

#    def show_error_popup(self, message):
#        """Показує popup з помилкою."""
#        Popup(title="Помилка", content=Label(text=message), size_hint=(0.9, 0.35)).open()

#    def show_status(self, txt: str):
#        """Показує статусне повідомлення."""
#        Popup(title="Повідомлення", content=Label(text=txt), size_hint=(0.9, 0.35)).open()

#    def apply_theme(self, theme_mode):
#        """Застосовує тему до всіх віджетів."""
#        colors = self.get_theme_colors(theme_mode)
#        
#        # Застосування кольорів до всіх віджетів
#        widgets = [self.speed_spinner, self.btn_listen, self.btn_pause, self.btn_edit, self.btn_extra]
#        widgets.extend(self.voice_buttons)
#        
#        for widget in widgets:
#            if widget:
#                widget.background_normal = ""
#                widget.background_color = colors["button_bg"]
#                widget.color = colors["button_fg"]
#                
#        if self.text_widget:
#            self.text_widget.background_color = colors["input_bg"]
#            self.text_widget.foreground_color = colors["input_fg"]
#            self.text_widget.cursor_color = (0.03, 0.85, 0.53, 1)

#    def get_theme_colors(self, theme_mode):
#        """Повертає кольори для теми."""
#        if theme_mode == "day":
#            return {
#                "button_bg": (0.5, 0.5, 0.5, 1),
#                "button_fg": (1, 1, 1, 1),
#                "input_bg": (1, 1, 1, 1),
#                "input_fg": (0, 0, 0, 1)
#            }
#        else:
#            return {
#                "button_bg": (0, 0, 0, 1),
#                "button_fg": (0, 0.3, 0.5, 1),
#                "input_bg": (0, 0, 0, 1),
#                "input_fg": (0, 0, 0.7, 1)
#            }

#            
#                        
#zp
#def set_text(self, text):
#    """Встановлює текст у віджет та відновлює позицію."""
#    if self.text_widget:
#        self.text_widget.text = text
#        self.open_bookmark()

#def open_bookmark(self):
#    """Відновлює позиції із конфіга.нов"""
#    try:
#        scroll_y = self.config.tags_editor_scroll_y
#        cursor_pos = self.config.tags_editor_cursor_pos
#        
#        # Встановлюємо прокрутку
#        self.text_widget.scroll_y = float(scroll_y)
#        
#        # Встановлюємо курсор
#        if cursor_pos > 0:
#            Clock.schedule_once(lambda dt: self._set_cursor_by_index(cursor_pos), 0.08)
#        else:
#            Clock.schedule_once(lambda dt: self._set_cursor_by_index(0), 0.05)
#            
#    except Exception as e:
#        print(f"⚠️ Не вдалося відновити закладку: {e}")
#        # Резервний варіант - відкрити з початку
#        self.text_widget.scroll_y = 1.0
#        self._set_cursor_by_index(0)

#def save_file(self, *args):
#    """Зберігає файл та закладку.нов"""
#    if not self.current_file:
#        self.show_error_popup("Файл не вказаний")
#        return
#        
#    try:
#        if not self.text_widget or self.text_widget.text == "":
#            self.show_error_popup("Текстове поле порожнє")
#            return

#        # Записуємо текст у файл
#        with open(self.current_file, "w", encoding="utf-8") as f:
#            f.write(self.text_widget.text if self.text_widget else "")

#        # Зберігаємо закладку з новою структурою
#        try:
#            cursor_idx = self.text_widget.cursor_index()
#        except Exception:
#            cursor_idx = 0
#            
#        try:
#            scroll_y = float(getattr(self.text_widget, "scroll_y", 1.0))
#        except Exception:
#            scroll_y = 1.0

#        self.config.save_bookmark(int(cursor_idx), float(scroll_y))

#        popup_text = f"Файл збережено:\n{self.current_file}"
#        Popup(title="Збережено", content=Label(text=popup_text), size_hint=(0.9, 0.35)).open()
#    except Exception as e:
#        self.show_error_popup(f"Помилка збереження: {str(e)}")

#def reset_bookmark(self):
#    """Скидає закладку в конфіг — відкривати буде з початку."""
#    try:
#        self.config.reset_bookmark()
#        # Оновлюємо UI
#        self.text_widget.scroll_y = 1.0
#        self._set_cursor_by_index(0)
#        
#        Popup(title="Закладка скинута", 
#              content=Label(text="Відкриття з початку тексту буде активне."), 
#              size_hint=(0.9, 0.35)).open()
#    except Exception as e:
#        self.show_error_popup(f"Помилка скидання закладки: {str(e)}")
#zk                                                #                                                