from kivy.uix.popup import Popup
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.core.window import Window

from utils.helpers import get_clock_str, get_battery_percent


class EditWordPopup(Popup):
    """Вікно редагування слова."""

    def __init__(self, main_app, original_word: str, **kwargs):
        super().__init__(**kwargs)
        self.main_app = main_app
        self.config = main_app.config_manager
        self.original_word = original_word
        self.accent_char = '\u0301'
        self.title = f"Редагування: {original_word}"
        self.size_hint = (0.98, 0.88)
        Window.softinput_mode = "below_target"

        self.bbtn_font_size = getattr(self.config, "bbtn_font_size", 40)
        self.bbtn_height = getattr(self.config, "bbtn_height", 120)

        self.build_ui()

    def build_ui(self):
        root = BoxLayout(orientation='vertical', spacing=8, padding=22)
        
        # Кнопки
        btn_row = BoxLayout(size_hint_y=None, height=self.bbtn_height, spacing=8)
        self.btn_listen = Button(text="Слухати", font_size=self.bbtn_font_size)
        self.btn_insert = Button(text="Наголос", font_size=self.bbtn_font_size)
        self.btn_save_text = Button(text="В текст", font_size=self.bbtn_font_size)
        self.btn_cancel = Button(text="Назад", font_size=self.bbtn_font_size)
        
        for b in (self.btn_listen, self.btn_insert, self.btn_save_text, self.btn_cancel):
            btn_row.add_widget(b)

        root.add_widget(btn_row)

        # Поле вводу
        self.edit_input = TextInput(text=self.original_word, font_size=100, multiline=False)
        root.add_widget(self.edit_input)

        # Інформаційний рядок
        info_row = BoxLayout(orientation='horizontal', size_hint_y=None, height=self.bbtn_height, spacing=12)
        self.clock_label = Label(text=f"Час: {get_clock_str()}", font_size=self.bbtn_font_size)
        batt = get_battery_percent()
        batt_txt = f"{batt}%" if batt >= 0 else "—"
        self.batt_label = Label(text=f"Заряд: {batt_txt}", font_size=self.bbtn_font_size)
        info_row.add_widget(self.clock_label)
        info_row.add_widget(self.batt_label)
        root.add_widget(info_row)

        # Прив'язки подій
        self.btn_listen.bind(on_press=self.on_listen_word)
        self.btn_insert.bind(on_press=self.on_insert_accent)
        self.btn_save_text.bind(on_press=self.on_save_text_only)
        self.btn_cancel.bind(on_press=lambda *_: self.dismiss())

        self.content = root
        self.update_input_bg_color()

    def on_insert_accent(self, *_):
        from core.text_processor import TextProcessor
        processor = TextProcessor()
        txt = processor.strip_combining_acute(self.edit_input.text)
        try:
            pos = self.edit_input.cursor_index()
        except Exception:
            pos = len(txt)
        new = txt[:pos] + self.accent_char + txt[pos:]
        self.edit_input.text = new
        try:
            self.edit_input.cursor = self.edit_input.get_cursor_from_index(pos + 1)
        except Exception:
            pass

    def on_save_text_only(self, *_):
        new_word = self.edit_input.text.strip()
        if not new_word:
            self.dismiss()
            return
        self.main_app.main_layout.replace_current_word(new_word)
        self.dismiss()

    def on_listen_word(self, *_):
        try:
            self.main_app.tts_manager.speak(self.edit_input.text, "normal")
        except Exception:
            pass

    def update_input_bg_color(self, *_):
        batt = get_battery_percent()
        colors = self.main_app.main_layout.get_theme_colors(self.main_app.theme_mode)
        
        if batt >= 0:
            self.edit_input.cursor_color = (0.03, 0.85, 0.53, 1)
            if batt < 25:
                self.edit_input.background_color = (1, 0.2, 0.2, 1)
            elif batt < 30:
                self.edit_input.background_color = (1, 0.6, 0.6, 1)
            else:                
                self.edit_input.background_color = colors["input_bg"]
                self.edit_input.foreground_color = colors["input_fg"]
        
        for b in (self.btn_listen, self.btn_insert, self.btn_save_text, self.btn_cancel, 
                  self.batt_label, self.clock_label):
            b.background_normal = ""
            b.background_color = colors["button_bg"]
            b.color = colors["button_fg"]


class ExtraButtonsPopup(Popup):
    """Вікно додаткових кнопок."""

    def __init__(self, main_app, **kwargs):
        super().__init__(**kwargs)
        self.main_app = main_app
        self.config = main_app.config_manager
        self.title = "Додаткові кнопки"
        self.size_hint = (0.95, 0.5)
        Window.softinput_mode = "below_target"

        self.bbtn_font_size = getattr(self.config, "bbtn_font_size", 40)
        self.bbtn_height = getattr(self.config, "bbtn_height", 120)

        self.build_ui()

    def build_ui(self):
        root = BoxLayout(orientation='vertical', spacing=8, padding=22)
        btn_row = BoxLayout(size_hint_y=None, height=self.bbtn_height, spacing=8)
        
        self.btn_open = Button(text="Відкрити", font_size=self.bbtn_font_size)
        self.btn_save_txt = Button(text="До txt", font_size=self.bbtn_font_size)
        self.btn_theme = Button(text="День-ніч", font_size=self.bbtn_font_size)
        self.btn_reset_bm = Button(text="Закладку 0", font_size=self.bbtn_font_size)
        self.btn_back = Button(text="Назад", font_size=self.bbtn_font_size)
        
        for b in (self.btn_open, self.btn_save_txt, self.btn_theme, self.btn_reset_bm, self.btn_back):
            btn_row.add_widget(b)
            
        root.add_widget(btn_row)
        root.add_widget(Label())
        self.content = root

        # Прив'язки подій
        self.btn_open.bind(on_press=lambda *_: (self.open_file_async(), self.dismiss()))
        self.btn_save_txt.bind(on_press=lambda *_: (self.save_file(), self.dismiss()))
        self.btn_theme.bind(on_press=lambda *_: (self.main_app.toggle_theme(), self.dismiss()))
        self.btn_reset_bm.bind(on_press=lambda *_: (self.reset_bookmark(), self.dismiss()))
        self.btn_back.bind(on_press=lambda *_: self.dismiss())

    def open_file_async(self):
        """Відкриває файл асинхронно."""
        self.main_app.main_layout.open_file_async()

    def save_file(self):
        """Зберігає файл."""
        self.main_app.main_layout.save_file()

    def reset_bookmark(self):
        """Скидає закладку."""
        self.main_app.config_manager.reset_bookmark()
        # Оновлюємо UI
        if hasattr(self.main_app, 'main_layout') and self.main_app.main_layout.text_widget:
            self.main_app.main_layout.text_widget.scroll_y = 1.0
            self.main_app.main_layout._set_cursor_by_index(0)
            
        from kivy.uix.popup import Popup
        from kivy.uix.label import Label
        Popup(title="Закладка скинута", 
              content=Label(text="Відкриття з початку тексту буде активне."), 
              size_hint=(0.9, 0.35)).open()



#from kivy.uix.popup import Popup
#from kivy.uix.boxlayout import BoxLayout
#from kivy.uix.button import Button
#from kivy.uix.label import Label
#from kivy.uix.textinput import TextInput
#from kivy.core.window import Window

#from utils.helpers import get_clock_str, get_battery_percent


#class EditWordPopup(Popup):
#    """Вікно редагування слова."""

#    def __init__(self, main_app, original_word: str, **kwargs):
#        super().__init__(**kwargs)
#        self.main_app = main_app
#        self.config = main_app.config_manager
#        self.original_word = original_word
#        self.accent_char = '\u0301'
#        self.title = f"Редагування: {original_word}"
#        self.size_hint = (0.98, 0.88)
#        Window.softinput_mode = "below_target"

#        self.bbtn_font_size = getattr(self.config, "bbtn_font_size", 40)
#        self.bbtn_height = getattr(self.config, "bbtn_height", 120)

#        self.build_ui()

#    def build_ui(self):
#        root = BoxLayout(orientation='vertical', spacing=8, padding=22)
#        
#        # Кнопки
#        btn_row = BoxLayout(size_hint_y=None, height=self.bbtn_height, spacing=8)
#        self.btn_listen = Button(text="Слухати", font_size=self.bbtn_font_size)
#        self.btn_insert = Button(text="Наголос", font_size=self.bbtn_font_size)
#        self.btn_save_text = Button(text="В текст", font_size=self.bbtn_font_size)
#        self.btn_cancel = Button(text="Назад", font_size=self.bbtn_font_size)
#        
#        for b in (self.btn_listen, self.btn_insert, self.btn_save_text, self.btn_cancel):
#            btn_row.add_widget(b)

#        root.add_widget(btn_row)

#        # Поле вводу
#        self.edit_input = TextInput(text=self.original_word, font_size=100, multiline=False)
#        root.add_widget(self.edit_input)

#        # Інформаційний рядок
#        info_row = BoxLayout(orientation='horizontal', size_hint_y=None, height=self.bbtn_height, spacing=12)
#        self.clock_label = Label(text=f"Час: {get_clock_str()}", font_size=self.bbtn_font_size)
#        batt = get_battery_percent()
#        batt_txt = f"{batt}%" if batt >= 0 else "—"
#        self.batt_label = Label(text=f"Заряд: {batt_txt}", font_size=self.bbtn_font_size)
#        info_row.add_widget(self.clock_label)
#        info_row.add_widget(self.batt_label)
#        root.add_widget(info_row)

#        # Прив'язки подій
#        self.btn_listen.bind(on_press=self.on_listen_word)
#        self.btn_insert.bind(on_press=self.on_insert_accent)
#        self.btn_save_text.bind(on_press=self.on_save_text_only)
#        self.btn_cancel.bind(on_press=lambda *_: self.dismiss())

#        self.content = root
#        self.update_input_bg_color()

#    def on_insert_accent(self, *_):
#        from core.text_processor import TextProcessor
#        processor = TextProcessor()
#        txt = processor.strip_combining_acute(self.edit_input.text)
#        try:
#            pos = self.edit_input.cursor_index()
#        except Exception:
#            pos = len(txt)
#        new = txt[:pos] + self.accent_char + txt[pos:]
#        self.edit_input.text = new
#        try:
#            self.edit_input.cursor = self.edit_input.get_cursor_from_index(pos + 1)
#        except Exception:
#            pass

#    def on_save_text_only(self, *_):
#        new_word = self.edit_input.text.strip()
#        if not new_word:
#            self.dismiss()
#            return
#        self.main_app.main_layout.replace_current_word(new_word)
#        self.dismiss()

#    def on_listen_word(self, *_):
#        try:
#            self.main_app.tts_manager.speak(self.edit_input.text, "normal")
#        except Exception:
#            pass

#    def update_input_bg_color(self, *_):
#        batt = get_battery_percent()
#        colors = self.main_app.main_layout.get_theme_colors(self.main_app.theme_mode)
#        
#        if batt >= 0:
#            self.edit_input.cursor_color = (0.03, 0.85, 0.53, 1)
#            if batt < 25:
#                self.edit_input.background_color = (1, 0.2, 0.2, 1)
#            elif batt < 30:
#                self.edit_input.background_color = (1, 0.6, 0.6, 1)
#            else:                
#                self.edit_input.background_color = colors["input_bg"]
#                self.edit_input.foreground_color = colors["input_fg"]
#        
#        for b in (self.btn_listen, self.btn_insert, self.btn_save_text, self.btn_cancel, 
#                  self.batt_label, self.clock_label):
#            b.background_normal = ""
#            b.background_color = colors["button_bg"]
#            b.color = colors["button_fg"]


#class ExtraButtonsPopup(Popup):
#    """Вікно додаткових кнопок."""

#    def __init__(self, main_app, **kwargs):
#        super().__init__(**kwargs)
#        self.main_app = main_app
#        self.config = main_app.config_manager
#        self.title = "Додаткові кнопки"
#        self.size_hint = (0.95, 0.5)
#        Window.softinput_mode = "below_target"

#        self.bbtn_font_size = getattr(self.config, "bbtn_font_size", 40)
#        self.bbtn_height = getattr(self.config, "bbtn_height", 120)

#        self.build_ui()

#    def build_ui(self):
#        root = BoxLayout(orientation='vertical', spacing=8, padding=22)
#        btn_row = BoxLayout(size_hint_y=None, height=self.bbtn_height, spacing=8)
#        
#        self.btn_open = Button(text="Відкрити", font_size=self.bbtn_font_size)
#        self.btn_save_txt = Button(text="До txt", font_size=self.bbtn_font_size)
#        self.btn_theme = Button(text="День-ніч", font_size=self.bbtn_font_size)
#        self.btn_reset_bm = Button(text="Закладку 0", font_size=self.bbtn_font_size)
#        self.btn_back = Button(text="Назад", font_size=self.bbtn_font_size)
#        
#        for b in (self.btn_open, self.btn_save_txt, self.btn_theme, self.btn_reset_bm, self.btn_back):
#            btn_row.add_widget(b)
#            
#        root.add_widget(btn_row)
#        root.add_widget(Label())
#        self.content = root

#        # Прив'язки подій
#        self.btn_open.bind(on_press=lambda *_: (self.open_file_async(), self.dismiss()))
#        self.btn_save_txt.bind(on_press=lambda *_: (self.save_file(), self.dismiss()))
#        self.btn_theme.bind(on_press=lambda *_: (self.main_app.toggle_theme(), self.dismiss()))
#        self.btn_reset_bm.bind(on_press=lambda *_: (self.reset_bookmark(), self.dismiss()))
#        self.btn_back.bind(on_press=lambda *_: self.dismiss())

#    def open_file_async(self):
#        """Відкриває файл асинхронно."""
#        self.main_app.main_layout.open_file_async()

#    def save_file(self):
#        """Зберігає файл."""
#        self.main_app.main_layout.save_file()

#    def reset_sbookmark(self):
#        """Скидає закладку."""
#        self.main_app.config_manager.reset_bookmark()
#        from kivy.uix.popup import Popup
#        from kivy.uix.label import Label
#        Popup(title="Закладка скинута", 
#              content=Label(text="Відкриття з початку титулу буде активне."), 
#              size_hint=(0.9, 0.35)).open()

#              
#zp
#def reset_bookmark(self):
#    """Скидає закладку."""
#    self.main_app.config_manager.reset_bookmark()
#    # Оновлюємо UI
#    if hasattr(self.main_app, 'main_layout') and self.main_app.main_layout.text_widget:
#        self.main_app.main_layout.text_widget.scroll_y = 1.0
#        self.main_app.main_layout._set_cursor_by_index(0)
#        
#    from kivy.uix.popup import Popup
#    from kivy.uix.label import Label
#    Popup(title="Закладка скинута", 
#          content=Label(text="Відкриття з початку тексту буде активне."), 
#          size_hint=(0.9, 0.35)).open()
#zk                                                                                    