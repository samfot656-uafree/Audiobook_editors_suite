from datetime import datetime

try:
    from jnius import autoclass
    PythonActivity = autoclass('org.kivy.android.PythonActivity')
    Context = autoclass('android.content.Context')
    BatteryManager = autoclass('android.os.BatteryManager')
except Exception:
    PythonActivity = Context = BatteryManager = None


def get_clock_str() -> str:
    """Поточний час ГГ:ХХ"""
    try:
        return datetime.now().strftime("%H:%M")
    except Exception:
        return "--:--"


def get_battery_percent() -> int:
    """
    Повертає заряд батареї у %.
    Якщо Android API доступне, використовує BatteryManager, інакше повертає -1.
    """
    try:
        if BatteryManager and PythonActivity:
            ctx = PythonActivity.mActivity.getSystemService(Context.BATTERY_SERVICE)
            if ctx:
                val = ctx.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                return int(val)
    except Exception:
        pass
    return -1