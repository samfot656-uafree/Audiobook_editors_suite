import re

# Регулярні вирази
WORD_RE = re.compile(r"(?:[^\W\d_](?:\u0301)?)+(?:'(?:[^\W\d_](?:\u0301)?)+)*", flags=re.UNICODE)
TAG_OPEN_RE = re.compile(r"#g\d+(?:_(slow|fast))?: ?", flags=re.IGNORECASE)

# Константи
ACCENT_CHAR = '\u0301'