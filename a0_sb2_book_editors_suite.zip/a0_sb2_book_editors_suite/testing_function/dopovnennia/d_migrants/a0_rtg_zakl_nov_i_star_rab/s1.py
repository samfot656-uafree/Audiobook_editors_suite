voice_editor/
├── main.py
├── core/
│   ├── __init__.py
│   ├── config_manager.py
│   ├── text_processor.py
│   └── tts_manager.py
├── ui/
│   ├── __init__.py
│   ├── popups.py
│   └── widgets.py
└── utils/
    ├── __init__.py
    ├── helpers.py
    └── constants.py