from kivy.app import App
from kivy.clock import Clock
from kivy.core.window import Window

from core.config_manager import ConfigManager
from core.tts_manager import TTSManager
from ui.widgets import MainLayout


class VoiceTagEditor(App):
    """Основний клас застосунку."""

    def __init__(self, config_file="config_json", **kwargs):
        super().__init__(**kwargs)
        self.config_manager = ConfigManager(config_file)
        self.config_manager.ensure_config()  # Гарантуємо наявність конфіга
        self.config_manager.load()  # Завантажуємо конфіг
        
        self.tts_manager = TTSManager()
        
        # UI та стан
        self.main_layout = None
        self.theme_mode = "day"

    def build(self):
        Window.softinput_mode = "below_target"
        self.main_layout = MainLayout(self)
        self.apply_theme()
        Clock.schedule_once(lambda *_: self.tts_manager.init_tts(), 0.1)
        
        # Завантажуємо файл при старті, якщо вказаний у конфігурації
        if self.config_manager.input_text_file and self.config_manager.input_text_file.exists():
            Clock.schedule_once(lambda *_: self.main_layout.open_file_async(), 0.5)
            
        return self.main_layout

    def toggle_theme(self):
        self.theme_mode = "night" if self.theme_mode == "day" else "day"
        self.apply_theme()

    def apply_theme(self):
        if self.main_layout:
            self.main_layout.apply_theme(self.theme_mode)


if __name__ == "__main__":
    cfg_path = "/storage/emulated/0/Documents/pidgotovka_knigi/jsons/config_migration.json"
#    cfg_path = "/storage/emulated/0/Documents/Json/config_zakl.json"
    app = VoiceTagEditor(cfg_path)
    app.run()

#from kivy.app import App
#from kivy.clock import Clock
#from kivy.core.window import Window

#from core.config_manager import ConfigManager
#from core.tts_manager import TTSManager
#from ui.widgets import MainLayout


#class VoiceTagEditor(App):
#    """Основний клас застосунку."""

#    def __init__(self, config_file="config_json", **kwargs):
#        super().__init__(**kwargs)
#        self.config_manager = ConfigManager(config_file)
#        self.config_manager.ensure_config()  # Гарантуємо наявність конфіга
#        self.config_manager.load()  # Завантажуємо конфіг
#        
#        self.tts_manager = TTSManager()
#        
#        # UI та стан
#        self.main_layout = None
#        self.theme_mode = "day"

#    def build(self):
#        Window.softinput_mode = "below_target"
#        self.main_layout = MainLayout(self)
#        self.apply_theme()
#        Clock.schedule_once(lambda *_: self.tts_manager.init_tts(), 0.1)
#        
#        # Завантажуємо файл при старті, якщо вказаний у конфігурації
#        if self.config_manager.input_text_file and self.config_manager.input_text_file.exists():
#            Clock.schedule_once(lambda *_: self.main_layout.open_file_async(), 0.5)
#            
#        return self.main_layout

#    def toggle_theme(self):
#        self.theme_mode = "night" if self.theme_mode == "day" else "day"
#        self.apply_theme()

#    def apply_theme(self):
#        if self.main_layout:
#            self.main_layout.apply_theme(self.theme_mode)


#if __name__ == "__main__":
#    cfg_path = "/storage/emulated/0/Documents/Json/config_zakl.json"
#    app = VoiceTagEditor(cfg_path)
#    app.run()

#from kivy.app import App
#from kivy.clock import Clock
#from kivy.core.window import Window

#from core.config_manager import ConfigManager
#from core.tts_manager import TTSManager
#from ui.widgets import MainLayout


#class VoiceTagEditor(App):
#    """Основний клас застосунку."""

#    def __init__(self, config_file="config_json", **kwargs):
#        super().__init__(**kwargs)
#        self.config_manager = ConfigManager(config_file).load()
#        self.tts_manager = TTSManager()
#        
#        # UI та стан
#        self.main_layout = None
#        self.theme_mode = "day"

#    def build(self):
#        Window.softinput_mode = "below_target"
#        self.main_layout = MainLayout(self)
#        self.apply_theme()
#        Clock.schedule_once(lambda *_: self.tts_manager.init_tts(), 0.1)
#        
#        # Завантажуємо файл при старті, якщо вказаний у конфігурації
#        if self.config_manager.input_text_file and self.config_manager.input_text_file.exists():
#            Clock.schedule_once(lambda *_: self.main_layout.open_file_async(), 0.5)
#            
#        return self.main_layout

#    def toggle_theme(self):
#        self.theme_mode = "night" if self.theme_mode == "day" else "day"
#        self.apply_theme()

#    def apply_theme(self):
#        if self.main_layout:
#            self.main_layout.apply_theme(self.theme_mode)


#if __name__ == "__main__":
#    cfg_path = "/storage/emulated/0/Documents/Json/config_zakl.json"
#    app = VoiceTagEditor(cfg_path)
#    app.run()