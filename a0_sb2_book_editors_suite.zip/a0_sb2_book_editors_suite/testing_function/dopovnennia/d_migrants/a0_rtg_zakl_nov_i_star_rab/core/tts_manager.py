try:
    from jnius import autoclass
    PythonActivity = autoclass('org.kivy.android.PythonActivity')
    TextToSpeech = autoclass('android.speech.tts.TextToSpeech')
    Locale = autoclass('java.util.Locale')
    HashMap = autoclass('java.util.HashMap')
except Exception:
    PythonActivity = TextToSpeech = Locale = HashMap = None


class TTSManager:
    """Керування Text-to-Speech функціоналом."""
    
    def __init__(self):
        self.tts = None

    def init_tts(self):
        """Ініціалізація TTS."""
        if not TextToSpeech or not PythonActivity:
            return None
            
        try:
            tts = TextToSpeech(PythonActivity.mActivity, None)
            try:
                tts.setLanguage(Locale.forLanguageTag("uk-UA"))
            except Exception:
                try:
                    tts.setLanguage(Locale("uk"))
                except Exception:
                    pass
            self.tts = tts
            return tts
        except Exception:
            return None

    def speak(self, text: str, speed_tag: str = "normal"):
        """Озвучення тексту з налаштуванням швидкості."""
        if not text or not self.tts:
            return
            
        try:
            params = HashMap() if HashMap else None
            if params:
                params.put("volume", "1.0")
                
            # Визначення швидкості
            st = (speed_tag or "normal").lower()
            try:
                if st == "slow":
                    self.tts.setSpeechRate(0.8)
                elif st == "fast":
                    self.tts.setSpeechRate(1.2)
                else:
                    self.tts.setSpeechRate(1.0)
            except Exception:
                pass
                
            if params:
                self.tts.speak(text, TextToSpeech.QUEUE_FLUSH, params)
            else:
                self.tts.speak(text, TextToSpeech.QUEUE_FLUSH, None)
        except Exception:
            pass

    def stop(self):
        """Зупинка відтворення."""
        if self.tts:
            try:
                self.tts.stop()
            except Exception:
                pass