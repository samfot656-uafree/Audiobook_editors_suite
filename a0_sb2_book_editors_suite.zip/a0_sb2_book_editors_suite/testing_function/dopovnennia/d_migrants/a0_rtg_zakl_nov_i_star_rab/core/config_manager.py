import json
import re
import os
from pathlib import Path
from typing import Dict, Optional, List


class ConfigManager:
    """Клас для завантаження і зберігання параметрів конфігурації."""
    
    def __init__(self, config_file: str):
        self.config_file = Path(config_file)
        self.config_data: Optional[Dict] = None
        
        # дефолти
        self.config_version = "0_0_0_1"
        self.input_text_file: Path = Path("")
        self.output_folder: Path = Path("")
        self.voice_dict: Dict[str, str] = {}
        self.bbtn_font_size = 38
        self.bbtn_height = 120
        self.TEMP_FOLDER_NAME = "TEMP_MULTISPEAKERS"
        self.project_root: Optional[Path] = None
        self.temp_folder: Optional[Path] = None
        self.current_block_text: List[str] = []
        self.current_voice_tag: str = 'g1'
        
        # Нова структура закладки
        self.tags_editor_scroll_y = 1.0
        self.tags_editor_cursor_pos = 0

    def ensure_config(self):
        """Створює конфіг ТІЛЬКИ якщо його нема. Не перезаписує існуючий!"""
        if not self.config_file.exists():
            self.config_file.parent.mkdir(parents=True, exist_ok=True)
            
            # Шлях за замовчуванням для текстового файлу
            default_txt_path = self.config_file.parent / "test_text.txt"
            
            cfg = {
                "CONFIG_VERSION": self.config_version,
                "INPUT_TEXT_FILE": str(default_txt_path),
                "OUTPUT_FOLDER": "",
                "voice_dict": {},
                "TAGS_EDITOR_SCROLL_Y": 1.0,
                "TAGS_EDITOR_CURSOR_POS": 0
            }
            
            with open(self.config_file, "w", encoding="utf-8") as f:
                json.dump(cfg, f, indent=4, ensure_ascii=False)
            
            # Створюємо порожній текстовий файл, якщо його нема
            if not default_txt_path.exists():
                default_txt_path.parent.mkdir(parents=True, exist_ok=True)
                with open(default_txt_path, "w", encoding="utf-8") as f:
                    f.write("")
            print(f"✅ Створено новий конфіг: {self.config_file}")
        else:
            print(f"✅ Використовується існуючий конфіг: {self.config_file}")

    def load(self):
        """Завантажує конфіг та встановлює атрибути. НЕ перезаписує існуючий!"""
        self.ensure_config()  # Тільки перевіряє наявність, не перезаписує
        
        try:
            with open(self.config_file, encoding='utf-8') as f:
                cfg = json.load(f)
        except Exception as e:
            print(f"⚠️ Помилка завантаження конфігу {self.config_file}: {e}")
            # Повертаємо порожній словник, але НЕ створюємо новий конфіг
            cfg = {}

        self.config_data = cfg
        self.config_version = cfg.get("CONFIG_VERSION", self.config_version)
        
        # основні шляхи та словники
        self.input_text_file = Path(cfg.get("INPUT_TEXT_FILE", "")) if cfg.get("INPUT_TEXT_FILE") else Path("")
        self.output_folder = Path(cfg.get("OUTPUT_FOLDER", "")) if cfg.get("OUTPUT_FOLDER") else Path("")
        self.voice_dict = cfg.get("voice_dict", {}) or {}
                
        # Нова структура закладки
        self.tags_editor_scroll_y = float(cfg.get("TAGS_EDITOR_SCROLL_Y", 1.0))
        self.tags_editor_cursor_pos = int(cfg.get("TAGS_EDITOR_CURSOR_POS", 0))

        # Стара структура для сумісності
        self.bookmark = {
            "cursor": self.tags_editor_cursor_pos, 
            "scroll": self.tags_editor_scroll_y
        }

        self.project_root = Path(cfg.get("PROJECT_ROOT", self.config_file.parent))
        
        print(f"✅ Завантажено конфіг: {len(self.voice_dict)} голосів, закладка: {self.tags_editor_cursor_pos}")
        return self

    def save_config(self, cfg_data: Dict = None):
        """Зберігає конфігурацію у файл. Оновлює тільки передані значення!"""
        if cfg_data is None:
            cfg_data = {}
            
        # Спочатку завантажуємо поточний конфіг
        current_cfg = self.load_config_dict()
        
        # Оновлюємо тільки ті поля, які передані в cfg_data
        for key, value in cfg_data.items():
            current_cfg[key] = value
            
        try:
            self.config_file.parent.mkdir(parents=True, exist_ok=True)
            with open(self.config_file, "w", encoding="utf-8") as f:
                json.dump(current_cfg, f, ensure_ascii=False, indent=4)
            print(f"✅ Конфіг оновлено: {list(cfg_data.keys())}")
        except Exception as e:
            print(f"❌ Помилка збереження конфігурації: {e}")

    def save_bookmark(self, cursor_idx: int, scroll_y: float):
        """Зберігає позицію курсора і прокрутки в конфіг. Не чіпає інші поля!"""
        # Оновлюємо тільки поля закладки
        cfg_updates = {
            "TAGS_EDITOR_SCROLL_Y": float(scroll_y),
            "TAGS_EDITOR_CURSOR_POS": int(cursor_idx),
            "RTG_BOOKMARK": {"cursor": int(cursor_idx), "scroll": float(scroll_y)}
        }
        
        self.save_config(cfg_updates)
        
        # Оновлюємо runtime-значення
        self.tags_editor_scroll_y = float(scroll_y)
        self.tags_editor_cursor_pos = int(cursor_idx)
        self.bookmark = {"cursor": int(cursor_idx), "scroll": float(scroll_y)}

    def reset_bookmark(self):
        """Скидає закладку. Не чіпає інші поля конфігу!"""
        # Оновлюємо тільки поля закладки
        cfg_updates = {
            "TAGS_EDITOR_SCROLL_Y": 1.0,
            "TAGS_EDITOR_CURSOR_POS": 0,
            "RTG_BOOKMARK": {"cursor": 0, "scroll": 1.0}
        }
        
        self.save_config(cfg_updates)
        
        # Оновлюємо runtime-значення
        self.tags_editor_scroll_y = 1.0
        self.tags_editor_cursor_pos = 0
        self.bookmark = {"cursor": 0, "scroll": 1.0}

    def load_config_dict(self) -> Dict:
        """Завантажує конфіг як словник. Не створює новий!"""
        if self.config_file.exists():
            try:
                with open(self.config_file, "r", encoding="utf-8") as f:
                    return json.load(f) or {}
            except Exception as e:
                print(f"❌ Помилка читання конфігу: {e}")
                return {}
        return {}

    def update_voice_dict(self, voice_dict: Dict[str, str]):
        """Оновлює словник голосів. Не чіпає інші поля!"""
        cfg_updates = {"voice_dict": voice_dict}
        self.save_config(cfg_updates)
        self.voice_dict = voice_dict

    def update_paths(self, input_file: str = None, output_folder: str = None):
        """Оновлює шляхи. Не чіпає інші поля!"""
        cfg_updates = {}
        if input_file:
            cfg_updates["INPUT_TEXT_FILE"] = input_file
        if output_folder:
            cfg_updates["OUTPUT_FOLDER"] = output_folder
            
        self.save_config(cfg_updates)
        
        if input_file:
            self.input_text_file = Path(input_file)

    # ---------- utility methods ----------
    def ensure_folder(self, path: Path):
        path.mkdir(parents=True, exist_ok=True)

    def sanitize_name(self, s: str, for_filename: bool = True) -> str:
        s2 = re.sub(r"^##\s* ", "", s)
        s2 = re.sub(r"#g\d+: ? ", "", s2)
        s2 = s2.strip()
        if for_filename:
            s2 = re.sub(r"[^\w\d_-]", "_", s2)
            if not s2:
                s2 = "Глава"
        return s2


#import json
#import re
#import os
#from pathlib import Path
#from typing import Dict, Optional, List


#class ConfigManager:
#    """Клас для завантаження і зберігання параметрів конфігурації."""
#    
#    def __init__(self, config_file: str):
#        self.config_file = Path(config_file)
#        self.config_data: Optional[Dict] = None
#        
#        # дефолти
#        self.config_version = "0_0_0_1"
#        self.input_text_file: Path = Path("")
#        self.output_folder: Path = Path("")
#        self.voice_dict: Dict[str, str] = {}
#        self.bbtn_font_size = 38
#        self.bbtn_height = 120
#        self.TEMP_FOLDER_NAME = "TEMP_MULTISPEAKERS"
#        self.project_root: Optional[Path] = None
#        self.temp_folder: Optional[Path] = None
#        self.current_block_text: List[str] = []
#        self.current_voice_tag: str = 'g1'
#        
#        # Нова структура закладки
#        self.tags_editor_scroll_y = 1.0
#        self.tags_editor_cursor_pos = 0

#    def ensure_config(self):
#        """Створює конфіг, якщо його нема."""
#        if not self.config_file.exists():
#            self.config_file.parent.mkdir(parents=True, exist_ok=True)
#            
#            # Шлях за замовчуванням для текстового файлу
#            default_txt_path = self.config_file.parent / "test_text.txt"
#            
#            cfg = {
#                "CONFIG_VERSION": self.config_version,
#                "INPUT_TEXT_FILE": str(default_txt_path),
#                "OUTPUT_FOLDER": "",
#                "voice_dict": {},
#                "TAGS_EDITOR_SCROLL_Y": 1.0,
#                "TAGS_EDITOR_CURSOR_POS": 0
#            }
#            
#            with open(self.config_file, "w", encoding="utf-8") as f:
#                json.dump(cfg, f, indent=4, ensure_ascii=False)
#            
#            # Створюємо порожній текстовий файл, якщо його нема
#            if not default_txt_path.exists():
#                default_txt_path.parent.mkdir(parents=True, exist_ok=True)
#                with open(default_txt_path, "w", encoding="utf-8") as f:
#                    f.write("")

#    def load(self):
#        """Завантажує конфіг та встановлює атрибути."""
#        self.ensure_config()
#        
#        try:
#            with open(self.config_file, encoding='utf-8') as f:
#                cfg = json.load(f)
#        except Exception:
#            cfg = {}

#        self.config_data = cfg
#        self.config_version = cfg.get("CONFIG_VERSION", self.config_version)
#        
#        # основні шляхи та словники
#        self.input_text_file = Path(cfg.get("INPUT_TEXT_FILE", "")) if cfg.get("INPUT_TEXT_FILE") else Path("")
#        self.output_folder = Path(cfg.get("OUTPUT_FOLDER", "")) if cfg.get("OUTPUT_FOLDER") else Path("")
#        self.voice_dict = cfg.get("voice_dict", {}) or {}
#                
#        # Нова структура закладки
#        self.tags_editor_scroll_y = float(cfg.get("TAGS_EDITOR_SCROLL_Y", 1.0))
#        self.tags_editor_cursor_pos = int(cfg.get("TAGS_EDITOR_CURSOR_POS", 0))

#        # Стара структура для сумісності
#        self.bookmark = {
#            "cursor": self.tags_editor_cursor_pos, 
#            "scroll": self.tags_editor_scroll_y
#        }

#        self.project_root = Path(cfg.get("PROJECT_ROOT", self.config_file.parent))
#        return self

#    def save_config(self, cfg_data: Dict = None):
#        """Зберігає конфігурацію у файл."""
#        if cfg_data is None:
#            cfg_data = self.config_data or {}
#            
#        try:
#            self.config_file.parent.mkdir(parents=True, exist_ok=True)
#            with open(self.config_file, "w", encoding="utf-8") as f:
#                json.dump(cfg_data, f, ensure_ascii=False, indent=4)
#        except Exception as e:
#            print(f"Помилка збереження конфігурації: {e}")

#    def save_bookmark(self, cursor_idx: int, scroll_y: float):
#        """Зберігає позицію курсора і прокрутки в конфіг."""
#        cfg = self.load_config_dict()
#        
#        # Оновлюємо обидві структури для сумісності
#        cfg["TAGS_EDITOR_SCROLL_Y"] = float(scroll_y)
#        cfg["TAGS_EDITOR_CURSOR_POS"] = int(cursor_idx)
#        cfg["RTG_BOOKMARK"] = {"cursor": int(cursor_idx), "scroll": float(scroll_y)}
#        
#        self.save_config(cfg)
#        
#        # Оновлюємо runtime-значення
#        self.tags_editor_scroll_y = float(scroll_y)
#        self.tags_editor_cursor_pos = int(cursor_idx)
#        self.bookmark = {"cursor": int(cursor_idx), "scroll": float(scroll_y)}

#    def reset_bookmark(self):
#        """Скидає закладку (встановлює відкриття з початку)."""
#        cfg = self.load_config_dict()
#        
#        cfg["TAGS_EDITOR_SCROLL_Y"] = 1.0
#        cfg["TAGS_EDITOR_CURSOR_POS"] = 0
#        cfg["RTG_BOOKMARK"] = {"cursor": 0, "scroll": 1.0}
#        
#        self.save_config(cfg)
#        
#        # Оновлюємо runtime-значення
#        self.tags_editor_scroll_y = 1.0
#        self.tags_editor_cursor_pos = 0
#        self.bookmark = {"cursor": 0, "scroll": 1.0}

#    def load_config_dict(self) -> Dict:
#        """Завантажує конфіг як словник."""
#        if self.config_file.exists():
#            try:
#                with open(self.config_file, "r", encoding="utf-8") as f:
#                    return json.load(f) or {}
#            except Exception:
#                return {}
#        return {}

#    # ---------- utility methods ----------
#    def ensure_folder(self, path: Path):
#        path.mkdir(parents=True, exist_ok=True)

#    def sanitize_name(self, s: str, for_filename: bool = True) -> str:
#        s2 = re.sub(r"^##\s* ", "", s)
#        s2 = re.sub(r"#g\d+: ? ", "", s2)
#        s2 = s2.strip()
#        if for_filename:
#            s2 = re.sub(r"[^\w\d_-]", "_", s2)
#            if not s2:
#                s2 = "Глава"
#        return s2


#import json
#import re
#import os
#from pathlib import Path
#from typing import Dict, Optional, List


#class ConfigManager:
#    """Клас для завантаження і зберігання параметрів конфігурації."""
#    
#    def __init__(self, config_file: str):
#        self.config_file = Path(config_file)
#        self.config_data: Optional[Dict] = None
#        
#        # дефолти
#        self.config_version = "0_0_0_1"
#        self.input_text_file: Path = Path("")
#        self.output_folder: Path = Path("")
#        self.voice_dict: Dict[str, str] = {}
#        self.bbtn_font_size = 38
#        self.bbtn_height = 120
#        self.TEMP_FOLDER_NAME = "TEMP_MULTISPEAKERS"
#        self.project_root: Optional[Path] = None
#        self.temp_folder: Optional[Path] = None
#        self.current_block_text: List[str] = []
#        self.current_voice_tag: str = 'g1'
#        
#        # Нова структура закладки
#        self.tags_editor_scroll_y = 1.0
#        self.tags_editor_cursor_pos = 0

#    def ensure_config(self):
#        """Створює конфіг, якщо його нема."""
#        if not self.config_file.exists():
#            self.config_file.parent.mkdir(parents=True, exist_ok=True)
#            
#            # Шлях за замовчуванням для текстового файлу
#            default_txt_path = self.config_file.parent / "test_text.txt"
#            
#            cfg = {
#                "CONFIG_VERSION": self.config_version,
#                "INPUT_TEXT_FILE": str(default_txt_path),
#                "OUTPUT_FOLDER": "",
#                "voice_dict": {},
#                "TAGS_EDITOR_SCROLL_Y": 1.0,
#                "TAGS_EDITOR_CURSOR_POS": 0
#            }
#            
#            with open(self.config_file, "w", encoding="utf-8") as f:
#                json.dump(cfg, f, indent=4, ensure_ascii=False)
#            
#            # Створюємо порожній текстовий файл, якщо його нема
#            if not default_txt_path.exists():
#                default_txt_path.parent.mkdir(parents=True, exist_ok=True)
#                with open(default_txt_path, "w", encoding="utf-8") as f:
#                    f.write("")

#    def load(self):
#        """Завантажує конфіг та встановлює атрибути."""
#        self.ensure_config()
#        
#        try:
#            with open(self.config_file, encoding='utf-8') as f:
#                cfg = json.load(f)
#        except Exception:
#            cfg = {}

#        self.config_data = cfg
#        self.config_version = cfg.get("CONFIG_VERSION", self.config_version)
#        
#        # основні шляхи та словники
#        self.input_text_file = Path(cfg.get("INPUT_TEXT_FILE", "")) if cfg.get("INPUT_TEXT_FILE") else Path("")
#        self.output_folder = Path(cfg.get("OUTPUT_FOLDER", "")) if cfg.get("OUTPUT_FOLDER") else Path("")
#        self.voice_dict = cfg.get("voice_dict", {}) or {}
#                
#        # Нова структура закладки
#        self.tags_editor_scroll_y = float(cfg.get("TAGS_EDITOR_SCROLL_Y", 1.0))
#        self.tags_editor_cursor_pos = int(cfg.get("TAGS_EDITOR_CURSOR_POS", 0))

#        # Стара структура для сумісності
#        self.bookmark = {
#            "cursor": self.tags_editor_cursor_pos, 
#            "scroll": self.tags_editor_scroll_y
#        }

#        self.project_root = Path(cfg.get("PROJECT_ROOT", self.config_file.parent))
#        return self

#    def save_config(self, cfg_data: Dict = None):
#        """Зберігає конфігурацію у файл."""
#        if cfg_data is None:
#            cfg_data = self.config_data or {}
#            
#        try:
#            self.config_file.parent.mkdir(parents=True, exist_ok=True)
#            with open(self.config_file, "w", encoding="utf-8") as f:
#                json.dump(cfg_data, f, ensure_ascii=False, indent=4)
#        except Exception as e:
#            print(f"Помилка збереження конфігурації: {e}")

#    def save_bookmark(self, cursor_idx: int, scroll_y: float):
#        """Зберігає позицію курсора і прокрутки в конфіг."""
#        cfg = self.load_config_dict()
#        
#        # Оновлюємо обидві структури для сумісності
#        cfg["TAGS_EDITOR_SCROLL_Y"] = float(scroll_y)
#        cfg["TAGS_EDITOR_CURSOR_POS"] = int(cursor_idx)
#        cfg["RTG_BOOKMARK"] = {"cursor": int(cursor_idx), "scroll": float(scroll_y)}
#        
#        self.save_config(cfg)
#        
#        # Оновлюємо runtime-значення
#        self.tags_editor_scroll_y = float(scroll_y)
#        self.tags_editor_cursor_pos = int(cursor_idx)
#        self.bookmark = {"cursor": int(cursor_idx), "scroll": float(scroll_y)}

#    def reset_bookmark(self):
#        """Скидає закладку (встановлює відкриття з початку)."""
#        cfg = self.load_config_dict()
#        
#        cfg["TAGS_EDITOR_SCROLL_Y"] = 1.0
#        cfg["TAGS_EDITOR_CURSOR_POS"] = 0
#        cfg["RTG_BOOKMARK"] = {"cursor": 0, "scroll": 1.0}
#        
#        self.save_config(cfg)
#        
#        # Оновлюємо runtime-значення
#        self.tags_editor_scroll_y = 1.0
#        self.tags_editor_cursor_pos = 0
#        self.bookmark = {"cursor": 0, "scroll": 1.0}

#    def load_config_dict(self) -> Dict:
#        """Завантажує конфіг як словник."""
#        if self.config_file.exists():
#            try:
#                with open(self.config_file, "r", encoding="utf-8") as f:
#                    return json.load(f) or {}
#            except Exception:
#                return {}
#        return {}

#    # ---------- utility methods ----------
#    def ensure_folder(self, path: Path):
#        path.mkdir(parents=True, exist_ok=True)

#    def sanitize_name(self, s: str, for_filename: bool = True) -> str:
#        s2 = re.sub(r"^##\s* ", "", s)
#        s2 = re.sub(r"#g\d+: ? ", "", s2)
#        s2 = s2.strip()
#        if for_filename:
#            s2 = re.sub(r"[^\w\d_-]", "_", s2)
#            if not s2:
#                s2 = "Глава"
#        return s2

#import json
#import re
#from pathlib import Path
#from typing import Dict, Optional


#class ConfigManager:
#    """Клас для завантаження і зберігання параметрів конфігурації."""
#    
#    def __init__(self, config_file: str):
#        self.config_file = Path(config_file)
#        self.config_data: Optional[Dict] = None
#        
#        # дефолти
#        self.config_version = "0_0_0_1"
#        self.input_text_file: Path = Path("")
#        self.output_folder: Path = Path("")
#        self.voice_dict: Dict[str, str] = {}
#        self.bbtn_font_size = 38
#        self.bbtn_height = 120
#        self.TEMP_FOLDER_NAME = "TEMP_MULTISPEAKERS"
#        self.project_root: Optional[Path] = None
#        self.temp_folder: Optional[Path] = None
#        self.current_block_text: List[str] = []
#        self.current_voice_tag: str = 'g1'
#        self.bookmark = {"cursor": 0, "scroll": 1.0}

#    def load(self):
#        """Завантажує конфіг та встановлює атрибути."""
#        if not self.config_file.exists():
#            self.config_data = {}
#            self.config_data["CONFIG_VERSION"] = self.config_version
#            self.config_data["INPUT_TEXT_FILE"] = str(self.input_text_file)
#            self.config_data["OUTPUT_FOLDER"] = str(self.output_folder)
#            self.config_data["voice_dict"] = self.voice_dict
#            return self

#        try:
#            with open(self.config_file, encoding='utf-8') as f:
#                cfg = json.load(f)
#        except Exception:
#            cfg = {}

#        self.config_data = cfg
#        self.config_version = cfg.get("CONFIG_VERSION", self.config_version)
#        self.input_text_file = Path(cfg.get("INPUT_TEXT_FILE", "")) if cfg.get("INPUT_TEXT_FILE") else Path("")
#        self.output_folder = Path(cfg.get("OUTPUT_FOLDER", "")) if cfg.get("OUTPUT_FOLDER") else Path("")
#        self.voice_dict = cfg.get("voice_dict", {}) or {}
#        
#        # bookmark
#        bk = cfg.get("RTG_BOOKMARK", None)
#        if isinstance(bk, dict):
#            try:
#                c = int(bk.get("cursor", 0))
#                s = float(bk.get("scroll", 1.0))
#                self.bookmark = {"cursor": max(0, c), "scroll": max(0.0, min(1.0, s))}
#            except Exception:
#                self.bookmark = {"cursor": 0, "scroll": 1.0}
#        else:
#            self.bookmark = {"cursor": 0, "scroll": 1.0}

#        self.project_root = Path(cfg.get("PROJECT_ROOT", self.config_file.parent))
#        return self

#    def ensure_folder(self, path: Path):
#        path.mkdir(parents=True, exist_ok=True)

#    def sanitize_name(self, s: str, for_filename: bool = True) -> str:
#        s2 = re.sub(r"^##\s* ", "", s)
#        s2 = re.sub(r"#g\d+: ? ", "", s2)
#        s2 = s2.strip()
#        if for_filename:
#            s2 = re.sub(r"[^\w\d_-]", "_", s2)
#            if not s2:
#                s2 = "Глава"
#        return s2

#    def save_bookmark(self, cursor_idx: int, scroll_y: float):
#        """Зберігає позицію курсора і прокрутки в конфіг."""
#        cfg = {}
#        if self.config_file.exists():
#            try:
#                with open(self.config_file, "r", encoding="utf-8") as f:
#                    cfg = json.load(f) or {}
#            except Exception:
#                cfg = {}
#                
#        cfg["RTG_BOOKMARK"] = {"cursor": int(max(0, cursor_idx)), "scroll": float(scroll_y)}
#        try:
#            self.config_file.parent.mkdir(parents=True, exist_ok=True)
#            with open(self.config_file, "w", encoding="utf-8") as f:
#                json.dump(cfg, f, ensure_ascii=False, indent=2)
#            self.bookmark = {"cursor": int(max(0, cursor_idx)), "scroll": float(scroll_y)}
#        except Exception:
#            pass

#    def reset_bookmark(self):
#        """Скидає закладку (встановлює відкриття з початку)."""
#        cfg = {}
#        if self.config_file.exists():
#            try:
#                with open(self.config_file, "r", encoding="utf-8") as f:
#                    cfg = json.load(f) or {}
#            except Exception:
#                cfg = {}
#                
#        cfg["RTG_BOOKMARK"] = {"cursor": 0, "scroll": 1.0}
#        try:
#            self.config_file.parent.mkdir(parents=True, exist_ok=True)
#            with open(self.config_file, "w", encoding="utf-8") as f:
#                json.dump(cfg, f, ensure_ascii=False, indent=2)
#            self.bookmark = {"cursor": 0, "scroll": 1.0}
#        except Exception:
#            pass