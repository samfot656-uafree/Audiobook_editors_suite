import re
from typing import Tuple, Optional

WORD_RE = re.compile(r"(?:[^\W\d_](?:\u0301)?)+(?:'(?:[^\W\d_](?:\u0301)?)+)*", flags=re.UNICODE)
TAG_OPEN_RE = re.compile(r"#g\d+(?:_(slow|fast))?: ?", flags=re.IGNORECASE)


class TextProcessor:
    """Клас для роботи з текстом: пошук слів, тегів, заміна."""
    
    def __init__(self):
        self.accent_char = '\u0301'

    def match_casing(self, original: str, replacement: str) -> str:
        """Підбирає регістр replacement під оригінал."""
        if not original:
            return replacement
        if original.isupper():
            return replacement.upper()
        if original[0].isupper():
            return replacement.capitalize()
        return replacement.lower()

    def detect_word_at_cursor(self, text: str, cursor_index: int) -> Tuple[Optional[str], str, str]:
        """Знаходить слово під курсором та контекст."""
        start, end = cursor_index, cursor_index
        
        # рух ліворуч
        while start > 0 and (self._is_letter(text[start - 1]) or text[start - 1] == self.accent_char):
            start -= 1
            
        # рух праворуч
        while end < len(text) and (self._is_letter(text[end]) or text[end] == self.accent_char):
            end += 1
            
        word = text[start:end]
        if WORD_RE.fullmatch(word):
            return word, text[:start], text[end:]
        return None, "", ""

    def find_tagged_fragment(self, text: str, cursor_index: int) -> Tuple[str, str, str]:
        """Знаходить фрагмент тексту між тегами."""
        opens = list(TAG_OPEN_RE.finditer(text))
        start_pos, start_speed = 0, "normal"
        
        for m in opens:
            if m.start() <= cursor_index:
                start_pos = m.end()
                grp = m.group(1)
                start_speed = grp if grp else "normal"
            else:
                break

        end_pos = len(text)
        for m in opens:
            if m.start() > cursor_index:
                end_pos = m.start()
                break

        fragment = text[start_pos:end_pos].strip()
        return fragment, start_speed, text[start_pos:end_pos]

    def _is_letter(self, ch: str) -> bool:
        return bool(re.match(r"[^\W\d_]", ch, flags=re.UNICODE))

    def strip_combining_acute(self, s: str) -> str:
        """Видаляє комбінований наголос"""
        if not s:
            return s
        return s.replace('\u0301', '')