# /storage/emulated/0/a0_sb2_book_editors_suite/testing_function/test_config_manager.py
import sys
import os
import shutil
from pathlib import Path

# Додаємо шлях до кореня проекту
project_root = '/storage/emulated/0/a0_sb2_book_editors_suite'
sys.path.insert(0, project_root)

try:
    from book_editors_suite.core.config_manager import get_config_manager, reset_config_manager
    print("✅ Модуль config_manager успішно імпортовано\n")
except ImportError as e:
    print(f"❌ Помилка імпорту: {e}\n")
    print("📂 Перевірте наявність файлів:\n")
    print("   - /storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite/__init__.py\n")
    print("   - /storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite/core/__init__.py\n")
    print("   - /storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite/core/config_manager.py\n")
    sys.exit(1)

def test_config_manager():
    """Тестуємо всі функції нового конфіг менеджера"""
    
    # Шлях для тестового конфігу
    TEST_CONFIG_PATH = "/storage/emulated/0/a0_sb2_book_editors_suite/testing_function/testing_config8.json"
    
    print("🔧 ТЕСТУВАННЯ CONFIG MANAGER")
    print("=" * 60)
    
    # Скидаємо синглтон перед тестом
    reset_config_manager()
    
    # 1. Тестуємо ініціалізацію через синглтон
    print("\n1. 📝 ІНІЦІАЛІЗАЦІЯ ЧЕРЕЗ СИНГЛТОН\n")
    try:
        config = get_config_manager(TEST_CONFIG_PATH)
        print("✅ Конфіг менеджер успішно створений через синглтон\n")
        print(f"📁 Шлях до конфігу: {TEST_CONFIG_PATH}\n")
    except Exception as e:
        print(f"❌ Помилка ініціалізації: {e}\n")
        return None
    
    # 2. Тестуємо завантаження повного конфігу
    print("\n2. 📥 ЗАВАНТАЖЕННЯ ПОВНОГО КОНФІГУ")
    try:
        full_config = config.load_full_config()
        print(f"✅ Завантажено {len(full_config)} параметрів\n")
        print("📊 Стан конфігу:\n")
        print(f"   - CONFIG_VERSION: {full_config.get('COMMON_CONFIG_VERSION')}\n")
        print(f"   - INPUT_TEXT_FILE: {full_config.get('COMMON_INPUT_TEXT_FILE')}\n")
        print(f"   - ACCENT_CHAR: {full_config.get('COMMON_ACCENT_CHAR')}\n")
        print(f"   - ACCENT_CHAR у слові: наголо{full_config.get('COMMON_ACCENT_CHAR')}шено\n")
        print(f"   - Параметрів у конфігу: {len(full_config)}\n")
    except Exception as e:
        print(f"❌ Помилка завантаження: {e}\n")
    
    # 3. Тестуємо завантаження конфігу для кожного редактора
    print("\n3. 🎯 ЗАВАНТАЖЕННЯ КОНФІГУ ДЛЯ РЕДАКТОРІВ")
    editors = config.list_editors()
    for editor in editors:
        try:
            editor_config = config.load_for_editor(editor)
            print(f"✅ {editor}: {len(editor_config)} параметрів\n")
            # Показуємо ключі параметрів
            print(f"   Параметри: {list(editor_config.keys())[:3]}...\n")
        except Exception as e:
            print(f"❌ {editor}: {e}\n")
    
    # 4. Тестуємо роботу з закладками
    print("\n4. 📍 ТЕСТУВАННЯ ЗАКЛАДОК")
    test_positions = [
        ('accent_editor', 100, 0.5),
        ('voice_tags_editor', 200, 0.75),
        ('sound_effects_editor', 150, 0.25),
        ('multispeaker_tts', 180, 0.6)
    ]
    
    for editor, cursor, scroll in test_positions:
        try:
            # Оновлюємо закладку
            config.update_bookmark(editor, cursor, scroll)
            
            # Отримуємо закладку
            bookmark = config.get_bookmark(editor)
            print(f"\n✅ {editor}: cursor={bookmark['cursor_pos']}, scroll={bookmark['scroll_y']}\n")
        except Exception as e:
            print(f"❌ {editor}: {e}")
    
    # 5. Тестуємо роботу зі спільними параметрами (тільки читання)
    print("\n5. 🔗 ТЕСТУВАННЯ СПІЛЬНИХ ПАРАМЕТРІВ (READ-ONLY)\n")
    common_params = config.common_params['params']
    for param in common_params:
        try:
            value = config.get_common_param(param)
            print(f"✅ {param}: {value}\n")
        except Exception as e:
            print(f"❌ {param}: {e}\n")
    
    # 6. Тестуємо роботу з особистими параметрами
    print("\n6. 👤 ТЕСТУВАННЯ ОСОБИСТИХ ПАРАМЕТРІВ\n")
    test_cases = [
        ('accent_editor', 'TTS_MODE', 'gTTS'),
        ('multispeaker_tts', 'FRAGMENT_SOFT_LIMIT', 950),
    ]
    
    for editor, param, new_value in test_cases:
        try:
            # Отримуємо поточне значення
            current = config.get_personal_param(editor, param)
            print(f"🔍 {editor}.{param}: поточне = {current}\n")
            
            # Встановлюємо нове значення
            success = config.set_personal_param(editor, param, new_value)
            if success:
                updated = config.get_personal_param(editor, param)
                print(f"✅ {editor}.{param} оновлено: {current} → {updated}\n")
            else:
                print(f"❌ {editor}.{param} не вдалось оновити\n")
                
        except Exception as e:
            print(f"❌ {editor}.{param}: {e}\n")
    
    # 7. Тестуємо синглтон
    print("\n7. 🔄 ТЕСТУВАННЯ СИНГЛТОНУ\n")
    try:
        # Отримуємо другий екземпляр через синглтон
        config2 = get_config_manager(TEST_CONFIG_PATH)
        
        # Перевіряємо що це той самий екземпляр
        if config is config2:
            print("✅ Синглтон працює правильно - один екземпляр\n")
            
            # Перевіряємо що дані синхронізовані
            test_value1 = config.get_personal_param('accent_editor', 'TTS_MODE')
            test_value2 = config2.get_personal_param('accent_editor', 'TTS_MODE')
            if test_value1 == test_value2:
                print(f"✅ Дані синхронізовані: TTS_MODE = {test_value1}\n")
            else:
                print(f"❌ Дані не синхронізовані: {test_value1} != {test_value2}\n")
        else:
            print("❌ Проблема з синглтоном - різні екземпляри\n")
            
    except Exception as e:
        print(f"❌ Помилка синглтона: {e}\n")
    
    # 8. Фінальне збереження та перевірка
    print("\n8. 💾 ФІНАЛЬНЕ ЗБЕРЕЖЕННЯ ТА ПЕРЕВІРКА\n")
    try:
        # Створюємо резервну копію
        backup_path = TEST_CONFIG_PATH + ".backup"
        if os.path.exists(TEST_CONFIG_PATH):
            shutil.copy2(TEST_CONFIG_PATH, backup_path)
            print(f"✅ Створено резервну копію: {backup_path}\n")
        
        # Зберігаємо конфіг
        success = config.save_full_config()
        if success:
            print("✅ Конфіг успішно збережено\n")
            
            # Перевіряємо розмір файлу
            file_size = os.path.getsize(TEST_CONFIG_PATH)
            print(f"✅ Розмір конфіг файлу: {file_size} байт\n")
        else:
            print("❌ Помилка збереження конфігу\n")
            
    except Exception as e:
        print(f"❌ Помилка фінального збереження: {e}\n")
    
    print("\n" + "=" * 60)
    print("🎉 ТЕСТУВАННЯ ЗАВЕРШЕНО!\n")
    
    # Фінальна статистика
    final_data = config.load_full_config()
    print(f"\n📊 ПІДСУМОК:\n")
    print(f"   - Редакторів: {len(config.list_editors())}\n")
    print(f"   - Спільних параметрів: {len(config.common_params['params'])}\n")
    print(f"   - Загальна кількість параметрів у конфігу: {len(final_data)}\n")
    
    return config

if __name__ == "__main__":
    print("🚀 ЗАПУСК ТЕСТІВ CONFIG MANAGER\n")
    print("=" * 60)
    
    try:
        config = test_config_manager()
        
        if config:
            print("\n🎊 ТЕСТИ ПРОЙДЕНІ УСПІШНО!\n")
        else:
            print("\n⚠️ Тестування завершено з помилками\n")
            
    except Exception as e:
        print(f"❌ ПОМИЛКА ПРИ ЗАПУСКУ ТЕСТІВ: {e}\n")
        import traceback
        traceback.print_exc()




# /storage/emulated/0/a0_sb2_book_editors_suite/testing_function/test_config_manager.py
#import sys
#import os
#import shutil
#from pathlib import Path

# Додаємо шляхи для імпорту модулів
#project_root = '/storage/emulated/0/a0_sb2_book_editors_suite'
#sys.path.insert(0, project_root)

#try:
#    from book_editors_suite.core.config_manager import get_config_manager, reset_config_manager
#    print("✅ Модуль config_manager успішно імпортовано")
#except ImportError as e:
#    print(f"❌ Помилка імпорту: {e}")
#    print("📂 Перевірте структуру проектів:")
#    print("   - /storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite/")
#    print("   - /storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite/core/")
#    print("   - /storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite/core/config_manager.py")
#    sys.exit(1)

#def test_config_manager():
#    """Тестуємо всі функції нового конфіг менеджера"""
#    
#    # Шлях для тестового конфігу
#    TEST_CONFIG_PATH = "/storage/emulated/0/a0_sb2_book_editors_suite/testing_function/testing_config1.json"
#    
#    print("🔧 ТЕСТУВАННЯ CONFIG MANAGER")
#    print("=" * 60)
#    
#    # Скидаємо синглтон перед тестом
#    reset_config_manager()
#    
#    # 1. Тестуємо ініціалізацію через синглтон
#    print("\n1. 📝 ІНІЦІАЛІЗАЦІЯ ЧЕРЕЗ СИНГЛТОН")
#    try:
#        config = get_config_manager(TEST_CONFIG_PATH)
#        print("✅ Конфіг менеджер успішно створений через синглтон")
#        print(f"📁 Шлях до конфігу: {TEST_CONFIG_PATH}")
#    except Exception as e:
#        print(f"❌ Помилка ініціалізації: {e}")
#        return None
#    
#    # 2. Тестуємо завантаження повного конфігу
#    print("\n2. 📥 ЗАВАНТАЖЕННЯ ПОВНОГО КОНФІГУ")
#    try:
#        full_config = config.load_full_config()
#        print(f"✅ Завантажено {len(full_config)} параметрів")
#        print("📊 Стан конфігу:")
#        print(f"   - CONFIG_VERSION: {full_config.get('CONFIG_VERSION')}")
#        print(f"   - INPUT_TEXT_FILE: {full_config.get('INPUT_TEXT_FILE')}")
#        print(f"   - Параметрів у конфігу: {len(full_config)}")
#    except Exception as e:
#        print(f"❌ Помилка завантаження: {e}")
#    
#    # 3. Тестуємо завантаження конфігу для кожного редактора
#    print("\n3. 🎯 ЗАВАНТАЖЕННЯ КОНФІГУ ДЛЯ РЕДАКТОРІВ")
#    editors = config.list_editors()
#    for editor in editors:
#        try:
#            editor_config = config.load_for_editor(editor)
#            print(f"✅ {editor}: {len(editor_config)} параметрів")
#            # Показуємо ключі параметрів
#            print(f"   Параметри: {list(editor_config.keys())[:3]}...")
#        except Exception as e:
#            print(f"❌ {editor}: {e}")
#    
#    # 4. Тестуємо роботу з закладками
#    print("\n4. 📍 ТЕСТУВАННЯ ЗАКЛАДОК")
#    test_positions = [
#        ('accent_editor', 100, 0.5),
#        ('voice_tags_editor', 200, 0.75),
#        ('sound_effects_editor', 150, 0.25),
#        ('multispeaker_tts', 180, 0.6)
#    ]
#    
#    for editor, cursor, scroll in test_positions:
#        try:
#            # Оновлюємо закладку
#            config.update_bookmark(editor, cursor, scroll)
#            
#            # Отримуємо закладку
#            bookmark = config.get_bookmark(editor)
#            print(f"✅ {editor}: cursor={bookmark['cursor_pos']}, scroll={bookmark['scroll_y']}")
#        except Exception as e:
#            print(f"❌ {editor}: {e}")
#    
#    # 5. Тестуємо роботу зі спільними параметрами (тільки читання)
#    print("\n5. 🔗 ТЕСТУВАННЯ СПІЛЬНИХ ПАРАМЕТРІВ (READ-ONLY)")
#    common_params = config.common_params['params']
#    for param in common_params:
#        try:
#            value = config.get_common_param(param)
#            print(f"✅ {param}: {value}")
#        except Exception as e:
#            print(f"❌ {param}: {e}")
#    
#    # 6. Тестуємо роботу з особистими параметрами
#    print("\n6. 👤 ТЕСТУВАННЯ ОСОБИСТИХ ПАРАМЕТРІВ")
#    test_cases = [
#        ('accent_editor', 'TTS_MODE', 'gTTS'),
#        ('multispeaker_tts', 'FRAGMENT_SOFT_LIMIT', 950),
#    ]
#    
#    for editor, param, new_value in test_cases:
#        try:
#            # Отримуємо поточне значення
#            current = config.get_personal_param(editor, param)
#            print(f"🔍 {editor}.{param}: поточне = {current}")
#            
#            # Встановлюємо нове значення
#            success = config.set_personal_param(editor, param, new_value)
#            if success:
#                updated = config.get_personal_param(editor, param)
#                print(f"✅ {editor}.{param} оновлено: {current} → {updated}")
#            else:
#                print(f"❌ {editor}.{param} не вдалось оновити")
#                
#        except Exception as e:
#            print(f"❌ {editor}.{param}: {e}")
#    
#    # 7. Тестуємо синглтон
#    print("\n7. 🔄 ТЕСТУВАННЯ СИНГЛТОНУ")
#    try:
#        # Отримуємо другий екземпляр через синглтон
#        config2 = get_config_manager(TEST_CONFIG_PATH)
#        
#        # Перевіряємо що це той самий екземпляр
#        if config is config2:
#            print("✅ Синглтон працює правильно - один екземпляр")
#            
#            # Перевіряємо що дані синхронізовані
#            test_value1 = config.get_personal_param('accent_editor', 'TTS_MODE')
#            test_value2 = config2.get_personal_param('accent_editor', 'TTS_MODE')
#            if test_value1 == test_value2:
#                print(f"✅ Дані синхронізовані: TTS_MODE = {test_value1}")
#            else:
#                print(f"❌ Дані не синхронізовані: {test_value1} != {test_value2}")
#        else:
#            print("❌ Проблема з синглтоном - різні екземпляри")
#            
#    except Exception as e:
#        print(f"❌ Помилка синглтона: {e}")
#    
#    # 8. Фінальне збереження та перевірка
#    print("\n8. 💾 ФІНАЛЬНЕ ЗБЕРЕЖЕННЯ ТА ПЕРЕВІРКА")
#    try:
#        # Створюємо резервну копію
#        backup_path = TEST_CONFIG_PATH + ".backup"
#        if os.path.exists(TEST_CONFIG_PATH):
#            shutil.copy2(TEST_CONFIG_PATH, backup_path)
#            print(f"✅ Створено резервну копію: {backup_path}")
#        
#        # Зберігаємо конфіг
#        success = config.save_full_config()
#        if success:
#            print("✅ Конфіг успішно збережено")
#            
#            # Перевіряємо розмір файлу
#            file_size = os.path.getsize(TEST_CONFIG_PATH)
#            print(f"✅ Розмір конфіг файлу: {file_size} байт")
#        else:
#            print("❌ Помилка збереження конфігу")
#            
#    except Exception as e:
#        print(f"❌ Помилка фінального збереження: {e}")
#    
#    print("\n" + "=" * 60)
#    print("🎉 ТЕСТУВАННЯ ЗАВЕРШЕНО!")
#    
#    # Фінальна статистика
#    final_data = config.load_full_config()
#    print(f"\n📊 ПІДСУМОК:")
#    print(f"   - Редакторів: {len(config.list_editors())}")
#    print(f"   - Спільних параметрів: {len(config.common_params['params'])}")
#    print(f"   - Загальна кількість параметрів у конфігу: {len(final_data)}")
#    
#    return config

#def main():
#    """Головна функція для запуску тестів"""
#    print("🚀 ЗАПУСК ТЕСТІВ CONFIG MANAGER")
#    print("=" * 60)
#    
#    try:
#        config = test_config_manager()
#        
#        if config:
#            print("\n🎊 ТЕСТИ ПРОЙДЕНІ УСПІШНО!")
#            print("\n📋 РЕКОМЕНДАЦІЇ:")
#            print("   - Конфіг менеджер готовий до використання")
#            print("   - Можна інтегрувати з редакторами")
#        else:
#            print("\n⚠️ Тестування завершено з помилками")
#            
#    except Exception as e:
#        print(f"❌ ПОМИЛКА ПРИ ЗАПУСКУ ТЕСТІВ: {e}")
#        import traceback
#        traceback.print_exc()

#if __name__ == "__main__":
#    main()



# /storage/emulated/0/a0_sb2_book_editors_suite/testing_function/test_config_manager.py
#import sys
#import os
#import shutil
#from pathlib import Path

# Додаємо шлях до кореня проекту для імпорту модулів
#project_root = '/storage/emulated/0/a0_sb2_book_editors_suite'
#sys.path.insert(0, project_root)

# Імпортуємо з book_editors_suite
#from book_editors_suite.core.config_manager import get_config_manager, reset_config_manager

#def test_config_manager():
#    """Тестуємо всі функції нового конфіг менеджера"""
#    
#    # Шлях для тестового конфігу
#    TEST_CONFIG_PATH = "/storage/emulated/0/a0_sb2_book_editors_suite/testing_function/testing_config1.json"
#    
#    print("🔧 ТЕСТУВАННЯ CONFIG MANAGER")
#    print("=" * 60)
#    
#    # Скидаємо синглтон перед тестом
#    reset_config_manager()
#    
#    # 1. Тестуємо ініціалізацію через синглтон
#    print("\n1. 📝 ІНІЦІАЛІЗАЦІЯ ЧЕРЕЗ СИНГЛТОН")
#    try:
#        config = get_config_manager(TEST_CONFIG_PATH)
#        print("✅ Конфіг менеджер успішно створений через синглтон")
#        print(f"📁 Шлях до конфігу: {TEST_CONFIG_PATH}")
#    except Exception as e:
#        print(f"❌ Помилка ініціалізації: {e}")
#        return None
#    
#    # [решта тестового коду залишається без змін...]






# /storage/emulated/0/a0_sb2_book_editors_suite/testing_function/test_config_manager.py
#import sys
#import os
#import shutil
#from pathlib import Path

# Додаємо шлях до кореня проекту для імпорту модулів
#project_root = '/storage/emulated/0/a0_sb2_book_editors_suite'
#sys.path.insert(0, project_root)

# Тепер імпортуємо через book_editors_suite
#try:
#    from book_editors_suite.core.config_manager import get_config_manager, reset_config_manager
#    print("✅ Модуль config_manager успішно імпортовано")
#except ImportError as e:
#    print(f"❌ Помилка імпорту: {e}")
#    print("📂 Перевірте структуру проектів:")
#    print("   - /storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite/")
#    print("   - /storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite/core/")
#    print("   - /storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite/core/config_manager.py")
#    sys.exit(1)

#def test_config_manager():
#    """Тестуємо всі функції нового конфіг менеджера"""
#    
#    # Шлях для тестового конфігу
#    TEST_CONFIG_PATH = "/storage/emulated/0/a0_sb2_book_editors_suite/testing_function/testing_config1.json"
#    
#    print("🔧 ТЕСТУВАННЯ CONFIG MANAGER")
#    print("=" * 60)
#    
#    # Скидаємо синглтон перед тестом
#    reset_config_manager()
#    
#    # 1. Тестуємо ініціалізацію через синглтон
#    print("\n1. 📝 ІНІЦІАЛІЗАЦІЯ ЧЕРЕЗ СИНГЛТОН")
#    try:
#        config = get_config_manager(TEST_CONFIG_PATH)
#        print("✅ Конфіг менеджер успішно створений через синглтон")
#        print(f"📁 Шлях до конфігу: {TEST_CONFIG_PATH}")
#    except Exception as e:
#        print(f"❌ Помилка ініціалізації: {e}")
#        return None
#    
#    # 2. Тестуємо завантаження повного конфігу
#    print("\n2. 📥 ЗАВАНТАЖЕННЯ ПОВНОГО КОНФІГУ")
#    try:
#        full_config = config.load_full_config()
#        print(f"✅ Завантажено {len(full_config)} параметрів")
#        print("📊 Стан конфігу:")
#        print(f"   - CONFIG_VERSION: {full_config.get('CONFIG_VERSION')}")
#        print(f"   - INPUT_TEXT_FILE: {full_config.get('INPUT_TEXT_FILE')}")
#        print(f"   - Параметрів у конфігу: {len(full_config)}")
#    except Exception as e:
#        print(f"❌ Помилка завантаження: {e}")
#    
#    # 3. Тестуємо завантаження конфігу для кожного редактора
#    print("\n3. 🎯 ЗАВАНТАЖЕННЯ КОНФІГУ ДЛЯ РЕДАКТОРІВ")
#    editors = config.list_editors()
#    for editor in editors:
#        try:
#            editor_config = config.load_for_editor(editor)
#            print(f"✅ {editor}: {len(editor_config)} параметрів")
#            # Показуємо ключі параметрів
#            print(f"   Параметри: {list(editor_config.keys())[:3]}...")
#        except Exception as e:
#            print(f"❌ {editor}: {e}")
#    
#    # 4. Тестуємо роботу з закладками
#    print("\n4. 📍 ТЕСТУВАННЯ ЗАКЛАДОК")
#    test_positions = [
#        ('accent_editor', 100, 0.5),
#        ('voice_tags_editor', 200, 0.75),
#        ('sound_effects_editor', 150, 0.25),
#        ('multispeaker_tts', 180, 0.6)
#    ]
#    
#    for editor, cursor, scroll in test_positions:
#        try:
#            # Оновлюємо закладку
#            config.update_bookmark(editor, cursor, scroll)
#            
#            # Отримуємо закладку
#            bookmark = config.get_bookmark(editor)
#            print(f"✅ {editor}: cursor={bookmark['cursor_pos']}, scroll={bookmark['scroll_y']}")
#        except Exception as e:
#            print(f"❌ {editor}: {e}")
#    
#    # 5. Тестуємо роботу зі спільними параметрами (тільки читання)
#    print("\n5. 🔗 ТЕСТУВАННЯ СПІЛЬНИХ ПАРАМЕТРІВ (READ-ONLY)")
#    common_params = config.common_params['params']
#    for param in common_params:
#        try:
#            value = config.get_common_param(param)
#            print(f"✅ {param}: {value}")
#        except Exception as e:
#            print(f"❌ {param}: {e}")
#    
#    # 6. Тестуємо роботу з особистими параметрами
#    print("\n6. 👤 ТЕСТУВАННЯ ОСОБИСТИХ ПАРАМЕТРІВ")
#    test_cases = [
#        ('accent_editor', 'TTS_MODE', 'gTTS'),
#        ('multispeaker_tts', 'FRAGMENT_SOFT_LIMIT', 950),
#    ]
#    
#    for editor, param, new_value in test_cases:
#        try:
#            # Отримуємо поточне значення
#            current = config.get_personal_param(editor, param)
#            print(f"🔍 {editor}.{param}: поточне = {current}")
#            
#            # Встановлюємо нове значення
#            success = config.set_personal_param(editor, param, new_value)
#            if success:
#                updated = config.get_personal_param(editor, param)
#                print(f"✅ {editor}.{param} оновлено: {current} → {updated}")
#            else:
#                print(f"❌ {editor}.{param} не вдалось оновити")
#                
#        except Exception as e:
#            print(f"❌ {editor}.{param}: {e}")
#    
#    # 7. Тестуємо синглтон
#    print("\n7. 🔄 ТЕСТУВАННЯ СИНГЛТОНУ")
#    try:
#        # Отримуємо другий екземпляр через синглтон
#        config2 = get_config_manager(TEST_CONFIG_PATH)
#        
#        # Перевіряємо що це той самий екземпляр
#        if config is config2:
#            print("✅ Синглтон працює правильно - один екземпляр")
#            
#            # Перевіряємо що дані синхронізовані
#            test_value1 = config.get_personal_param('accent_editor', 'TTS_MODE')
#            test_value2 = config2.get_personal_param('accent_editor', 'TTS_MODE')
#            if test_value1 == test_value2:
#                print(f"✅ Дані синхронізовані: TTS_MODE = {test_value1}")
#            else:
#                print(f"❌ Дані не синхронізовані: {test_value1} != {test_value2}")
#        else:
#            print("❌ Проблема з синглтоном - різні екземпляри")
#            
#    except Exception as e:
#        print(f"❌ Помилка синглтона: {e}")
#    
#    # 8. Фінальне збереження та перевірка
#    print("\n8. 💾 ФІНАЛЬНЕ ЗБЕРЕЖЕННЯ ТА ПЕРЕВІРКА")
#    try:
#        # Створюємо резервну копію
#        backup_path = TEST_CONFIG_PATH + ".backup"
#        if os.path.exists(TEST_CONFIG_PATH):
#            shutil.copy2(TEST_CONFIG_PATH, backup_path)
#            print(f"✅ Створено резервну копію: {backup_path}")
#        
#        # Зберігаємо конфіг
#        success = config.save_full_config()
#        if success:
#            print("✅ Конфіг успішно збережено")
#            
#            # Перевіряємо розмір файлу
#            file_size = os.path.getsize(TEST_CONFIG_PATH)
#            print(f"✅ Розмір конфіг файлу: {file_size} байт")
#        else:
#            print("❌ Помилка збереження конфігу")
#            
#    except Exception as e:
#        print(f"❌ Помилка фінального збереження: {e}")
#    
#    print("\n" + "=" * 60)
#    print("🎉 ТЕСТУВАННЯ ЗАВЕРШЕНО!")
#    
#    # Фінальна статистика
#    final_data = config.load_full_config()
#    print(f"\n📊 ПІДСУМОК:")
#    print(f"   - Редакторів: {len(config.list_editors())}")
#    print(f"   - Спільних параметрів: {len(config.common_params['params'])}")
#    print(f"   - Загальна кількість параметрів у конфігу: {len(final_data)}")
#    
#    return config

#def main():
#    """Головна функція для запуску тестів"""
#    print("🚀 ЗАПУСК ТЕСТІВ CONFIG MANAGER")
#    print("=" * 60)
#    
#    try:
#        config = test_config_manager()
#        
#        if config:
#            print("\n🎊 ТЕСТИ ПРОЙДЕНІ УСПІШНО!")
#            print("\n📋 РЕКОМЕНДАЦІЇ:")
#            print("   - Конфіг менеджер готовий до використання")
#            print("   - Можна інтегрувати з редакторами")
#        else:
#            print("\n⚠️ Тестування завершено з помилками")
#            
#    except Exception as e:
#        print(f"❌ ПОМИЛКА ПРИ ЗАПУСКУ ТЕСТІВ: {e}")
#        import traceback
#        traceback.print_exc()

#if __name__ == "__main__":
#    main()