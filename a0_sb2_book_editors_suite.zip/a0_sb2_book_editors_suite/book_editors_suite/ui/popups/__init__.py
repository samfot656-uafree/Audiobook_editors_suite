# -*- coding: utf-8 -*-
"""
/storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite/ui/popups/__init__.py

Пакет попапів.
"""

from .edit_word_popup import EditWordPopup
from .extra_buttons_popup import ExtraButtonsPopup

__all__ = [
    'EditWordPopup',
    'ExtraButtonsPopup'
]



# book_editors_suite/ui/popups/__init__.py
#"""
#Popups module - діалогові вікна та спливаючі меню
#"""

#from .edit_word_popup import EditWordPopup
#from .extra_buttons_popup import ExtraButtonsPopup

#__all__ = [
#    'EditWordPopup',
#    'ExtraButtonsPopup'
#]




# book_editors_suite/ui/popups/__init__.py
#"""
#Popups module - діалогові вікна та спливаючі меню
#"""

#from .edit_word_popup import EditWordPopup
#from .extra_buttons_popup import ExtraButtonsPopup

#__all__ = [
#    'EditWordPopup',
#    'ExtraButtonsPopup'
#]

#"""
#Popups module - діалогові вікна та спливаючі меню
#"""

#from .edit_word_popup import EditWordPopup
#from .extra_buttons_popup import ExtraButtonsPopup

#__all__ = [
#    'EditWordPopup',
#    'ExtraButtonsPopup'
#]