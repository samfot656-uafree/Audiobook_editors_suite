# -*- coding: utf-8 -*-
"""
Спільні компоненти для всіх редакторів.
"""


# -*- coding: utf-8 -*-
"""
/storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite/core/__init__.py

Пакет основних компонентів.
"""

from .config_manager import get_config_manager, ModularConfigManager
from .tts_manager import TTSManager

__all__ = [
    'get_config_manager',
    'ModularConfigManager',
    'TTSManager'
]


# book_editors_suite/core/__init__.py
#"""
#Core module - спільні компоненти для всіх редакторів
#"""

#from .config_manager import ModularConfigManager, get_config_manager, reset_config_manager

#__all__ = [
#    'ModularConfigManager',
#    'get_config_manager', 
#    'reset_config_manager'
#]



# book_editors_suite/core/__init__.py
#"""
#Core module - спільні компоненти для всіх редакторів
#"""

#from .config_manager import ModularConfigManager, get_config_manager, reset_config_manager
#from .tts_manager import TTSManager
#from .text_processor import TextProcessor
#from .file_manager import FileManager

#__all__ = [
#    'ModularConfigManager',
#    'get_config_manager', 
#    'reset_config_manager',
#    'TTSManager',
#    'TextProcessor',
#    'FileManager'
#]




# book_editors_suite/core/__init__.py
#"""
#Core module - спільні компоненти для всіх редакторів
#"""

#from .config_manager import ModularConfigManager, get_config_manager, reset_config_manager
#from .tts_manager import TTSManager
#from .text_processor import TextProcessor
#from .file_manager import FileManager

#__all__ = [
#    'ModularConfigManager',
#    'get_config_manager', 
#    'reset_config_manager',
#    'TTSManager',
#    'TextProcessor',
#    'FileManager'
#]

# book_editors_suite/core/__init__.py
#"""
#Core module - спільні компоненти для всіх редакторів
#"""

#from .config_manager import ModularConfigManager, get_config_manager
#from .tts_manager import TTSManager
#from .text_processor import TextProcessor
#from .file_manager import FileManager

#__all__ = [
#    'ModularConfigManager',
#    'get_config_manager', 
#    'TTSManager',
#    'TextProcessor',
#    'FileManager'
#]


#"""
#Core module - спільні компоненти для всіх редакторів
#"""

#from .config_manager import ModularConfigManager, get_config_manager
#from .tts_manager import TTSManager
#from .text_processor import TextProcessor
#from .file_manager import FileManager

#__all__ = [
#    'ModularConfigManager',
#    'get_config_manager', 
#    'TTSManager',
#    'TextProcessor',
#    'FileManager'
#]