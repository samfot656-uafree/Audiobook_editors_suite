# book_editors_suite/editors/sound_effects_editor/__init__.py
"""
Sound Effects Editor - редактор звукових ефектів
"""

from .main import SoundEffectsEditor

__all__ = ['SoundEffectsEditor']

# book_editors_suite/editors/sound_effects_editor/__init__.py
#"""
#Sound Effects Editor - редактор звукових ефектів
#"""

#from .main import SoundEffectsEditor

#__all__ = ['SoundEffectsEditor']

#"""
#Sound Effects Editor - редактор звукових ефектів
#"""

#from .main import SoundEffectsEditor

#__all__ = ['SoundEffectsEditor']