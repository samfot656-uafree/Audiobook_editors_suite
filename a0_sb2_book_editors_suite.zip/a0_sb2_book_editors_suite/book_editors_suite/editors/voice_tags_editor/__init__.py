# book_editors_suite/editors/voice_tags_editor/__init__.py
"""
Voice Tags Editor - редактор тегів голосів та пауз
"""

from .main import VoiceTagsEditor

__all__ = ['VoiceTagsEditor']


# book_editors_suite/editors/voice_tags_editor/__init__.py
#"""
#Voice Tags Editor - редактор тегів голосів та пауз
#"""

#from .main import VoiceTagsEditor

#__all__ = ['VoiceTagsEditor']

#"""
#Voice Tags Editor - редактор тегів голосів та пауз
#"""

#from .main import VoiceTagsEditor

#__all__ = ['VoiceTagsEditor']