# book_editors_suite/editors/multispeaker_tts/__init__.py
"""
Multispeaker TTS - мультиспікерне синтезування мовлення
"""

from .main import MultispeakerTTS

__all__ = ['MultispeakerTTS']


# book_editors_suite/editors/multispeaker_tts/__init__.py
#"""
#Multispeaker TTS - мультиспікерне синтезування мовлення
#"""

#from .main import MultispeakerTTS

#__all__ = ['MultispeakerTTS']

#"""
#Multispeaker TTS - мультиспікерне синтезування мовлення
#"""

#from .main import MultispeakerTTS

#__all__ = ['MultispeakerTTS']