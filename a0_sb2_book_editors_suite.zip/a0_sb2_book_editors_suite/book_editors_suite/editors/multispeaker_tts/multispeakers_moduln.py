#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Мультиспікер TTS - модульна версія з використанням спільного конфігу
Підтримує:
- Повні теги голосів з швидкістю (#g1_slow:, #g2_fast:, #g3:)
- Теги звукових ефектів (#S01:, #S02:, ...)
- Роботу зі спільним конфігом
"""

import os
import sys
import json
import re
import logging
import shutil
from pathlib import Path
from typing import Dict, List, Optional, Tuple

sys.path.insert(0, '/storage/emulated/0/a0_sb2_book_editors_suite')
sys.path.insert(0, '/storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite')


from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.popup import Popup
from kivy.uix.label import Label
from kivy.core.window import Window
from kivy.clock import Clock

from book_editors_suite.core.base_editor import BaseEditor
from book_editors_suite.ui.popups.edit_word_popup import EditWordPopup
from book_editors_suite.ui.popups.extra_buttons_popup import ExtraButtonsPopup


# Імпорт спільних модулів
from core.config_manager import ModularConfigManager
from core.file_manager import FileManager
#from utils.helpers import timestamp

# TTS
try:
    from gtts import gTTS
except:
    gTTS = None

try:
    from pydub import AudioSegment
except:
    AudioSegment = None

# Шлях до спільного конфігу
SHARED_CONFIG_PATH = "/storage/emulated/0/Documents/Json/config_zakl.json"

class MultispeakerTTS:
 #zp=====
 
    def __init__(self, book_project_name: str, input_text_file: str = None, **kwargs):
        super().__init__(**kwargs)
        self.book_project_name = book_project_name
        self.input_text_file = input_text_file
        self.app_name = "multispeaker_tts"
        
        # Використовуємо BaseEditor
        self.base_editor = BaseEditor(book_project_name, input_text_file, "multispeaker_tts")
 #zk=====
       
    
  #  
#    def __init__(self):
#        # Ініціалізація менеджерів
#        self.config_manager = ModularConfigManager(SHARED_CONFIG_PATH)
  #      self.file_manager = self.base_editor.FileManager()
        
        # Завантаження конфігурації для мультиспікера
        self.config = self.base_editor.config_manager.load_for_editor('multispeaker_tts')
        
        # Отримуємо параметри з конфігу
        self.INPUT_FILE = Path(self.config.get('INPUT_TEXT_FILE', ''))
        self.OUTPUT_FOLDER = Path(self.config.get('OUTPUT_FOLDER', ''))
        self.INPUT_SOUNDS_FOLDER = Path(self.config.get('INPUT_SOUNDS_FOLDER', ''))
        self.INPUT_SOUNDS_EFFECTS_FOLDER = Path(self.config.get('SOUNDS_EFFECTS_INPUT_FOLDER', ''))
        
        # Словники
        self.voice_dict = self.config.get('voice_dict', {})
        self.pause_dict = self.config.get('pause_dict', {})
        self.sound_dict = self.config.get('sound_dict', {})
        
        # Параметри обробки
        self.TTS_MODE = self.config.get('TTS_MODE', 'TFile')
        self.DO_SPLIT = self.config.get('DO_SPLIT', True)
        self.DO_MERGE = self.config.get('DO_MERGE', True)
        self.FRAGMENT_SOFT_LIMIT = self.config.get('FRAGMENT_SOFT_LIMIT', 900)
        self.FRAGMENT_HARD_LIMIT = self.config.get('FRAGMENT_HARD_LIMIT', 1000)
        self.SOUNDS_MODE = "mp3" if self.TTS_MODE == "gTTS" else "wav"
        
        # Завантажуємо додаткові дані звукових ефектів
        self.scenarios = self.load_scenarios_json()
        
        # Тимчасові та іменні константи
        self.TEMP_FOLDER_NAME = "temp_multispeakers"
        self.INP_MELODY_SUBFOLDER = "Input_melodu"
        
        # Внутрішні змінні
        self._project_root = None
        self._temp_folder = None
        self._current_fragment_counter = 0
        self._current_block_text = []
        self._current_voice_tag = None
        self._current_voice_speed = "normal"
        self._current_chapter_folder = None
        self._current_text_folder = None
        self._current_audio_folder = None
        self._current_chapter_name_for_files = None

    # ---------- Завантаження додаткових даних ----------
    def load_scenarios_json(self) -> dict:
        """Завантажує JSON зі сценаріями звукових ефектів"""
        sounds_effects_list = self.config.get('SOUNDS_EFFECTS_LIST', '')
        if not sounds_effects_list or not os.path.exists(sounds_effects_list):
            return {}
        try:
            with open(sounds_effects_list, 'r', encoding='utf-8') as f:
                data = json.load(f)
            scenarios = data.get('scenarios_dict', {}) if isinstance(data, dict) else {}
            return {str(k): str(v) for k, v in scenarios.items()}
        except Exception as e:
            print('Помилка завантаження JSON звукових ефектів:', e)
            return {}

    # ---------- Утиліти ----------
    def ensure_folder(self, path):
        Path(path).mkdir(parents=True, exist_ok=True)

    def ensure_dir(self, path: Path):
        path.mkdir(parents=True, exist_ok=True)

    def sanitize_chapter_folder_name(self, s: str) -> str:
        s2 = re.sub(r"^##\s* ", "", s)
        s2 = re.sub(r"#g\d+(?:_(slow|fast))?: ", "", s2)  # Оновлено для нових тегів
        s2 = re.sub(r"#S\d+: ", "", s2)  # Видаляємо теги звукових ефектів
        s2 = s2.strip()
        s2 = s2.replace('\u0301', '')
        s2 = s2.replace("'", '')
        s2 = s2.replace(' ', '_')
        s2 = s2.replace(',', '')
        s2 = s2.replace('.', '')
        s2 = s2.replace('+', '')
        s2 = re.sub(r"[\\/:*?\"<>|]", "_", s2)
        logging.info(f"Назва глави: '{s2}'")
        if not s2:
            s2 = "Глава"
        return s2

    def sanitize_chapter_fragment_title(self, s: str) -> str:
        s2 = re.sub(r"^##\s* ", "", s)
        s2 = re.sub(r"#g\d+(?:_(slow|fast))?: ", "", s2)  # Оновлено для нових тегів
        s2 = re.sub(r"#S\d+: ", "", s2)  # Видаляємо теги звукових ефектів
        logging.info(f"Назва глави для фрагменту: '{s2}'")
        return s2.strip()

    def format_fragment_filename(self, chapter_name: str, num: int, ext: str) -> str:
        return f"{chapter_name}_фр_{num:04d}.{ext}"

    # ---------- Логування ----------
    def setup_logging(self, project_root: Path):
        log_path = project_root / self.TEMP_FOLDER_NAME / "Лог_збереження.txt"
        logging.basicConfig(
            level=logging.INFO,
            handlers=[logging.FileHandler(log_path, encoding="utf-8"), logging.StreamHandler(sys.stdout)],
            format='\n%(asctime)s | %(levelname)s | %(message)s\n',
            datefmt='%Y-%m-%d %H:%M:%S'
        )

    # ---------- Робота з мелодіями та звуками ----------
    def ensure_melodies_copied(self):
        """Копіює мелодії та паузи у TEMP/Inp_melodu"""
        if self._temp_folder is None:
            logging.warning("_temp_folder не встановлено")
            return
            
        f_i_s = self._temp_folder / self.INP_MELODY_SUBFOLDER
        self.ensure_folder(f_i_s)
        
        # Отримуємо шляхи з конфігу
        melody_map = [
            (self.config.get('MELODY_START_wav'), f_i_s / "MELODY_START.wav"),
            (self.config.get('MELODY_END_wav'), f_i_s / "MELODY_END.wav"),
            (self.config.get('MELODY_START_mp3'), f_i_s / "MELODY_START.mp3"),
            (self.config.get('MELODY_END_mp3'), f_i_s / "MELODY_END.mp3"),
            (self.config.get('PAUSE_2_wav'), f_i_s / "PAUSE_2.wav"),
            (self.config.get('PAUSE_2_mp3'), f_i_s / "PAUSE_2.mp3"),
            (self.config.get('PAUSE_1_wav'), f_i_s / "PAUSE_1.wav"),
            (self.config.get('PAUSE_1_mp3'), f_i_s / "PAUSE_1.mp3"),
            (self.config.get('PAUSE_7_wav'), f_i_s / "PAUSE_7.wav"),
            (self.config.get('PAUSE_7_mp3'), f_i_s / "PAUSE_7.mp3"),
            (self.config.get('PAUSE_4_wav'), f_i_s / "PAUSE_4.wav"),
            (self.config.get('PAUSE_4_mp3'), f_i_s / "PAUSE_4.mp3"),
            (self.config.get('TEST_wav'), f_i_s / "TEST.wav")
        ]
        
        for src, dst in melody_map:
            try:
                if src and Path(src).exists():
                    shutil.copy2(src, dst)
                    logging.info(f"Копія мелодії: {src} -> {dst}")
                else:
                    logging.warning(f"Мелодія не знайдена: {src}")
            except Exception as e:
                logging.warning(f"Не вдалося скопіювати мелодію {src}: {e}")

    # ---------- TTS генерація ----------
    def tts_generate_gtts(self, text: str, out_path: Path, lang: str = 'uk') -> bool:
        if gTTS is None:
            logging.error("gTTS не встановлено")
            return False
        try:
            gTTS(text=text, lang=lang).save(str(out_path))
            return True
        except Exception as e:
            logging.exception(f"gTTS помилка: {e}")
            return False

    def tts_generate_tfile(self, text: str, out_path: Path, test_wav: Path) -> bool:
        try:
            shutil.copyfile(str(test_wav), str(out_path))
            return True
        except Exception as e:
            logging.exception(f"TFile помилка: {e}")
            return False

    def tts_generate_stylets2(self, text: str, out_path: Path, voice_tag: str) -> bool:
        logging.warning("StyleTTS2: потрібно реалізувати реальний TTS")
        return False

    # ---------- Збереження фрагмента ----------
    def save_fragment_and_tts(self, fragment_text: str, voice_tag: str, speed: str, 
                            chapter_folder_name: str, fragment_num: int) -> Tuple[bool, Optional[Path]]:
        if self._current_text_folder is None or self._current_audio_folder is None:
            logging.error(f"Папки не ініціалізовані")
            return False, None

        # Зберігаємо текст
        txt_name = self.format_fragment_filename(chapter_folder_name, fragment_num, 'txt')
        txt_path = self._current_text_folder / txt_name
        try:
            with txt_path.open('w', encoding='utf-8') as f:
                f.write(fragment_text)
            logging.info(f"Збережено текст: {txt_path}")
        except Exception as e:
            logging.exception(f"Помилка збереження txt: {e}")
            return False, None

        # Генеруємо аудіо
        audio_name = self.format_fragment_filename(chapter_folder_name, fragment_num, self.SOUNDS_MODE)
        audio_path = self._current_audio_folder / audio_name

        success = False
        if self.TTS_MODE == 'gTTS':
            success = self.tts_generate_gtts(fragment_text, audio_path)
        elif self.TTS_MODE == 'TFile':
            test_wav = Path(self.config.get('TEST_wav', ''))
            success = self.tts_generate_tfile(fragment_text, audio_path, test_wav)
        elif self.TTS_MODE == 'StyleTTS2':
            success = self.tts_generate_stylets2(fragment_text, audio_path, voice_tag)

        if success:
            logging.info(f"Фрагмент озвучено: {audio_path} (голос: {voice_tag}, швидкість: {speed})")
            self._current_fragment_counter += 1
            return True, audio_path
        else:
            logging.error(f"Не вдалося озвучити фрагмент #{fragment_num}")
            return False, None

    # ---------- Додавання пауз та звукових ефектів ----------
    def add_sound_or_pause(self, tag: str, chapter_folder: Path, frag_num: int) -> Optional[Path]:
        audio_folder = chapter_folder / "Звук"
        self.ensure_folder(audio_folder)
        
        folder_input_sound = self._temp_folder / self.INP_MELODY_SUBFOLDER
        out_path = audio_folder / self.format_fragment_filename(chapter_folder.name, frag_num, self.SOUNDS_MODE)
        
        if tag in self.pause_dict:
            # Пауза
            pause_name = f"{self.pause_dict[tag]}.{self.SOUNDS_MODE}"
            pause_path = folder_input_sound / pause_name
            if pause_path.exists():
                shutil.copy2(str(pause_path), str(out_path))
                logging.info(f"Додано паузу: {tag} -> {out_path}")
        elif tag.startswith('S') and tag[1:].isdigit():
            # Звуковий ефект з тегу S01, S02, etc.
            sound_effect_name = self.scenarios.get(tag, f"{tag}.{self.SOUNDS_MODE}")
            sound_inp_path = self.INPUT_SOUNDS_EFFECTS_FOLDER / sound_effect_name
            
            if not sound_inp_path.exists():
                # Спробуємо з розширенням
                sound_inp_path = Path(str(sound_inp_path) + f".{self.SOUNDS_MODE}")
            
            if sound_inp_path.exists():
                shutil.copyfile(str(sound_inp_path), str(out_path))
                logging.info(f"Додано звуковий ефект: {tag} -> {out_path}")
            else:
                logging.warning(f"Файл звукового ефекту не знайдено: {sound_inp_path}")
        elif tag in self.sound_dict:
            # Старий формат звукових ефектів
            sound_inp_path = self.INPUT_SOUNDS_FOLDER / f"{self.sound_dict[tag]}.{self.SOUNDS_MODE}"
            if sound_inp_path.exists():
                shutil.copyfile(str(sound_inp_path), str(out_path))
                logging.info(f"Додано звук: {tag} -> {out_path}")
        
        self._current_fragment_counter += 1
        return out_path

    def add_melody(self, chapter_folder: Path, frag_num: int, kind="START"):
        audio_folder = chapter_folder / "Звук"
        self.ensure_folder(audio_folder)
        
        melody_filename = f"MELODY_{kind}.{self.SOUNDS_MODE}"
        melody_inp_path = self._temp_folder / self.INP_MELODY_SUBFOLDER / melody_filename
        
        if not melody_inp_path.exists():
            # Резервний варіант
            melody_inp_path = self.INPUT_SOUNDS_FOLDER / melody_filename
        
        out_path = audio_folder / self.format_fragment_filename(chapter_folder.name, frag_num, self.SOUNDS_MODE)
        
        if melody_inp_path.exists():
            shutil.copyfile(str(melody_inp_path), str(out_path))
            logging.info(f"Додано мелодію {kind}: {out_path}")
        else:
            logging.warning(f"Файл мелодії не знайдено: {melody_inp_path}")
        
        self._current_fragment_counter += 1
        return out_path

    # ---------- Управління главами та блоками ----------
    def init_project_root(self, input_file: str, output_folder: str) -> Path:
        input_name = Path(input_file).stem
        project_root = Path(output_folder) / input_name
        self.ensure_folder(project_root)
        self._project_root = project_root
        self._temp_folder = project_root / self.TEMP_FOLDER_NAME
        self.ensure_folder(self._temp_folder)
        self.ensure_folder(self._temp_folder / self.INP_MELODY_SUBFOLDER)
        
        # Копіюємо вхідні файли
        try:
            shutil.copyfile(input_file, str(self._temp_folder / Path(input_file).name))
            shutil.copyfile(SHARED_CONFIG_PATH, str(self._temp_folder / Path(SHARED_CONFIG_PATH).name))
        except Exception as e:
            logging.warning(f"Не вдалося скопіювати вхідний файл у проект: {e}")
        
        self.setup_logging(project_root)
        logging.info(f"Ініціалізовано проєкт: {self._project_root}")
        return project_root

    def start_new_chapter(self, raw_chapter_line: str):
        chapter_folder_name = self.sanitize_chapter_folder_name(raw_chapter_line)
        chapter_fragment_title = self.sanitize_chapter_fragment_title(raw_chapter_line)

        self._current_chapter_folder = self._project_root / chapter_folder_name
        self.ensure_folder(self._current_chapter_folder)
        self._current_text_folder = self._current_chapter_folder / "Текст"
        self._current_audio_folder = self._current_chapter_folder / "Звук"
        self.ensure_folder(self._current_text_folder)
        self.ensure_folder(self._current_audio_folder)

        self._current_fragment_counter = 0
        self._current_block_text = []
        self._current_voice_tag = 'g1'  # голос за замовчуванням
        self._current_voice_speed = "normal"  # швидкість за замовчуванням

        # Шукаємо тег голосу з швидкістю
        voice_match = re.search(r"#g(\d+)(?:_(slow|fast))?:", raw_chapter_line)
        if voice_match:
            self._current_voice_tag = f"g{voice_match.group(1)}"
            self._current_voice_speed = voice_match.group(2) if voice_match.group(2) else "normal"

        self._current_chapter_name_for_files = chapter_folder_name
        
        # Додати мелодію початку
        self.add_melody(self._current_chapter_folder, self._current_fragment_counter, "START")
        
        # Перший фрагмент починається з назви глави
        if chapter_fragment_title:
            self._current_block_text.append(chapter_fragment_title)
        
        logging.info(f"Почато нову главу: {self._current_chapter_folder} (голос: {self._current_voice_tag}, швидкість: {self._current_voice_speed})")

    def start_new_voice_block(self, line_with_tag: str):
        # Зберегти поточний блок
        cur_text = '\n'.join(self._current_block_text).strip()
        if cur_text and self._current_voice_tag:
            self.save_fragment_and_tts(cur_text, self._current_voice_tag, self._current_voice_speed,
                                    self._current_chapter_name_for_files, self._current_fragment_counter)
        
        # Очистити поточний блок
        self._current_block_text = []
        
        # Шукаємо тег голосу з швидкістю
        voice_match = re.search(r"#g(\d+)(?:_(slow|fast))?:", line_with_tag)
        if voice_match:
            self._current_voice_tag = f"g{voice_match.group(1)}"
            self._current_voice_speed = voice_match.group(2) if voice_match.group(2) else "normal"
            
            # Додаємо текст після тегу
            after = re.sub(r"^.*#g\d+(?:_(slow|fast))?:", "", line_with_tag).strip()
            if after:
                self._current_block_text.append(after)
        else:
            logging.warning(f"Не знайдено тегу голосу в рядку: {line_with_tag}")

    def process_sound_effect_tag(self, line_with_tag: str):
        """Обробляє тег звукового ефекту (#S01:, #S02:, etc.)"""
        sound_match = re.search(r"#(S\d+):", line_with_tag)
        if sound_match:
            sound_tag = sound_match.group(1)
            # Додаємо звуковий ефект як окремий фрагмент
            self.add_sound_or_pause(sound_tag, self._current_chapter_folder, self._current_fragment_counter)
            
            # Можна додати текст після тегу звукового ефекту
            after = re.sub(r"^.*#S\d+:", "", line_with_tag).strip()
            if after:
                self._current_block_text.append(after)

    def append_line_to_block(self, line: str):
        stripped = line.rstrip('\n')
        
        # Перевіряємо на тег звукового ефекту
        if re.search(r"#S\d+:", stripped):
            self.process_sound_effect_tag(stripped)
            return
            
        # Порожній рядок - пауза
        if stripped.strip() == "":
            cur_text = '\n'.join(self._current_block_text).strip()
            if cur_text:
                self.save_fragment_and_tts(cur_text, self._current_voice_tag, self._current_voice_speed,
                                        self._current_chapter_name_for_files, self._current_fragment_counter)
                # Додати паузу
                self.add_sound_or_pause("P2", self._current_chapter_folder, self._current_fragment_counter)
            self._current_block_text = []
            return

        cur_text = '\n'.join(self._current_block_text)
        cur_len = len(cur_text)

        if cur_len + 1 + len(stripped) <= self.FRAGMENT_HARD_LIMIT:
            self._current_block_text.append(stripped)
            if len('\n'.join(self._current_block_text)) >= self.FRAGMENT_SOFT_LIMIT:
                self.save_fragment_and_tts('\n'.join(self._current_block_text).strip(), 
                                        self._current_voice_tag, self._current_voice_speed,
                                        self._current_chapter_name_for_files, self._current_fragment_counter)
                self._current_block_text = []
        else:
            if cur_text.strip():
                self.save_fragment_and_tts(cur_text.strip(), self._current_voice_tag, self._current_voice_speed,
                                        self._current_chapter_name_for_files, self._current_fragment_counter)
            self._current_block_text = [stripped]

    def finalize_chapter(self):
        if self._current_chapter_name_for_files is None:
            logging.debug("Нема відкритої глави")
            return
            
        if self._current_block_text and self._current_voice_tag:
            fragment_text = '\n'.join(self._current_block_text).strip()
            if fragment_text:
                self.save_fragment_and_tts(fragment_text, self._current_voice_tag, self._current_voice_speed,
                                        self._current_chapter_name_for_files, self._current_fragment_counter)
        
        # Додати мелодію завершення
        self.add_melody(self._current_chapter_folder, self._current_fragment_counter, "END")
        
        logging.info(f"Глава '{self._current_chapter_name_for_files}' завершена. Фрагментів: {self._current_fragment_counter}")
        self._current_block_text = []
        self._current_voice_tag = None

    def merge_chapter_audio(self, chapter_folder: Path):
        """Об'єднує всі звукові фрагменти глави в один файл"""
        if AudioSegment is None:
            logging.error("pydub не встановлено — не можу об'єднати аудіо.")
            return
            
        sound_folder = chapter_folder / "Звук"
        if not sound_folder.exists():
            logging.warning(f"Папки зі звуком немає: {sound_folder}")
            return
            
        fragments = sorted([f for f in os.listdir(sound_folder) if f.endswith(f".{self.SOUNDS_MODE}")])
        if not fragments:
            logging.warning("Немає фрагментів для об'єднання.")
            return
            
        combined = None
        for f in fragments:
            try:
                seg = AudioSegment.from_file(str(sound_folder / f))
                combined = seg if combined is None else combined + seg
            except Exception as e:
                logging.warning(f"Помилка завантаження фрагменту {f}: {e}")
                
        if combined:
            out_file = sound_folder / f"{chapter_folder.name}_повна.{self.SOUNDS_MODE}"
            combined.export(str(out_file), format=self.SOUNDS_MODE)
            logging.info(f"Об'єднано аудіо: {out_file}")

    # ---------- Основний процес ----------
    def process_input_file(self, input_file: str):
        project_root = self.init_project_root(input_file, self.OUTPUT_FOLDER)

        if not self.DO_SPLIT:
            logging.info("DO_SPLIT=False — розбиття відключено.")
            return

        # Копіюємо мелодії
        self.ensure_melodies_copied()

        with open(input_file, 'r', encoding='utf-8') as f:
            lines = f.readlines()

        in_chapter = False
        for raw_line in lines:
            line = raw_line.rstrip('\n')
            
            # Початок глави
            if line.strip().startswith('##'):
                if in_chapter:
                    self.finalize_chapter()
                self.start_new_chapter(line)
                in_chapter = True
                continue
                
            # Тег голосу
            if re.search(r"#g\d+(?:_(slow|fast))?:", line):
                self.start_new_voice_block(line)
                continue
                
            # Рядок поза главою
            if not in_chapter:
                logging.debug(f"Рядок поза главою ігнорується: {line}")
                continue
                
            # Додаємо рядок у блок
            self.append_line_to_block(line)

        if in_chapter:
            self.finalize_chapter()

        if self.DO_MERGE:
            for chapter_dir in self._project_root.iterdir():
                if chapter_dir.is_dir():
                    self.merge_chapter_audio(chapter_dir)

        logging.info("Обробка файлу завершена.")

    def run(self):
        """Головний метод запуску"""
        if not self.INPUT_FILE.exists():
            print(f"Вхідний файл не знайдено: {self.INPUT_FILE}")
            sys.exit(1)
            
        self.ensure_folder(self.OUTPUT_FOLDER)
        print(f"Запуск: TTS_MODE={self.TTS_MODE}, SOUNDS_MODE={self.SOUNDS_MODE}")
        
        try:
            self.process_input_file(str(self.INPUT_FILE))
        except Exception as e:
            logging.exception(f'Критична помилка при обробці: {e}')
            print(f'Критична помилка: {e}')
            sys.exit(1)
            
        print('--- Готово: обробка завершена. Перевірте лог у каталозі проєкту. ---')


# ------------------- Запуск -------------------
#if __name__ == '__main__':
#    multispeaker = MultispeakerTTS()
#    multispeaker.run()

# ========== Запуск ==========
if __name__ == "__main__":
    input_text_file = "/storage/emulated/0/Documents/Inp_txt/доповнення13_у_нас_гості.txt"
    book_project_name = "доповнення13_у_нас_гості2"

    multispeaker = MultispeakerTTS(
        book_project_name=book_project_name,
        input_text_file=input_text_file
    )
    multispeaker.run()    