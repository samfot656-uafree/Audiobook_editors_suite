# -*- coding: utf-8 -*-
"""
/storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite/editors/accent_editor/__init__.py

Пакет редактора наголосів.
"""

from .main import AccentEditorApp

__all__ = ['AccentEditorApp']



# book_editors_suite/editors/accent_editor/__init__.py
#"""
#Accent Editor - редактор наголосів та фонетичної розмітки
#"""

#from .main import AccentEditor

#__all__ = ['AccentEditor']


# book_editors_suite/editors/accent_editor/__init__.py
#"""
#Accent Editor - редактор наголосів та фонетичної розмітки
#"""

#from .main import AccentEditor

#__all__ = ['AccentEditor']

#"""
#Accent Editor - редактор наголосів та фонетичної розмітки
#"""

#from .main import AccentEditor

#__all__ = ['AccentEditor']