# -*- coding: utf-8 -*-
#/storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite/editors/accent_editor/main.py
"""
Головний модуль редактора наголосів.
"""
import sys
import os
from pathlib import Path

# Додаємо шляхи для імпортів
sys.path.insert(0, '/storage/emulated/0/a0_sb2_book_editors_suite')
sys.path.insert(0, '/storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite')

# Kivy imports
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.popup import Popup
from kivy.uix.label import Label
from kivy.core.window import Window
from kivy.clock import Clock

# Project imports
from book_editors_suite.core.config_manager import ModularConfigManager
from book_editors_suite.core.config_manager import get_config_manager
from book_editors_suite.core.tts_manager import TTSManager
from book_editors_suite.core.file_manager import FileManager
from book_editors_suite.core.text_processor import TextProcessor
from book_editors_suite.core.logging_manager import LoggingManager
from book_editors_suite.ui.popups.edit_word_popup import EditWordPopup
from book_editors_suite.ui.popups.add_sound_effect_file_popup import AddSoundEffectFilePopup
from book_editors_suite.ui.popups.extra_buttons_popup import ExtraButtonsPopup
from book_editors_suite.ui.themes import ThemeManager
from book_editors_suite.utils.helpers import WORD_RE


class AccentEditorApp(App):
    """Основний клас редактора наголосів."""
#-------------------------------------------    
    def __init__(self, config_path="config_json", **kwargs):
        super().__init__(**kwargs)
        
        self.app_name="accent_editor"
        self.config_path = config_path
        self.config_manager = ModularConfigManager(self.config_path)
        # Гарантуємо наявність конфіга
        self.config_manager.ensure_config()
        # Завантажуємо конфіг  
        self.config_manager.load_full_config()  
        
        self.config = {}
        self.accents = {}
        self.text_for_correction = []
        self.fixed_text = []
        self.current_idx = -1
        self.selected_word = None
        self.tts_manager = None
        self.file_manager = None
        self.text_processor = None
        self.logger = None
        self.theme_manager = None
        
        self.current_scroll_y = 0.0
        self.current_cursor_pos = 0
        self.current_paragraph_index = 0


#-------------------------------------------
    def build(self):
        """Побудова інтерфейсу додатку."""
        # Ініціалізація менеджерів
        self._init_managers()
        
        Window.softinput_mode = "below_target"
        return self._build_interface()

#-------------------------------------------
    def _init_managers(self):
        """Ініціалізація всіх менеджерів."""
        try:
            self.config_manager = get_config_manager(self.config_path)
            self.config = self.config_manager.load_for_editor('accent_editor')
            
            # Ініціалізація менеджерів
            self.logger = LoggingManager(
                log_dir="/storage/emulated/0/a0_sb2_book_editors_suite/testing_function/logs",
                app_name="accent_editor"
            )
            self.file_manager = FileManager(self.config_manager, 'accent_editor', self.logger)
            self.text_processor = TextProcessor(self.logger)
            self.tts_manager = TTSManager()
            self.theme_manager = ThemeManager()
            
            # Завантаження даних
            self.accents = self.file_manager.load_accents()
            
            self.logger.info("\n_init_managers: ✅ Всі менеджери ініціалізовані\n")
            
        except Exception as e:
            error_msg = f"\n_init_managers: ❌ Помилка ініціалізації менеджерів: {e}\n"
            if self.logger:
                self.logger.error(error_msg)
            else:
                print(error_msg)

#-------------------------------------------
    def _build_interface(self):
        """Побудова інтерфейсу."""
        self.logger.info("\n_build_interface: 🎨 Створення елементів інтерфейсу...\n")
   
        
        bbtn_font_size=self.config_manager.get_common_param('BBTN_FONT_SIZE', 38)
        text_widget_font_size=self.config_manager.get_common_param('TEXT_WIDGET_FONT_SIZE', 56)
        bbtn_height=self.config_manager.get_common_param('BBTN_HEIGHT', 120)
            
        root = BoxLayout(orientation='vertical', spacing=8, padding=22)

        # Верхній ряд кнопок
        top_row = BoxLayout(orientation='horizontal', size_hint_y=None, height=bbtn_height, spacing=8)
        self.btn_listen = Button(text="Слухати", font_size=bbtn_font_size)
        self.btn_pause = Button(text="Пауза", font_size=bbtn_font_size)
        self.btn_edit = Button(text="Правити", font_size=bbtn_font_size, disabled=True)
        self.btn_next = Button(text="Наступний", font_size=bbtn_font_size)
        self.btn_add_wav = Button(text="Додати wav", font_size=bbtn_font_size)
        
        self.btn_extra = Button(text=". . .", font_size=bbtn_font_size)
        
        for btn in (self.btn_listen, self.btn_pause, self.btn_edit, self.btn_next, self.btn_add_wav, self.btn_extra):
            top_row.add_widget(btn)

        # Текстове поле
        self.text_input = TextInput(
            font_size=text_widget_font_size,
            multiline=True
        )
        self.text_input.bind(on_touch_down=self.on_text_touch)

        # Додавання віджетів та прив'язка подій
        root.add_widget(top_row)
        root.add_widget(self.text_input)
        self._bind_events()

        # Автоматичні дії
        Clock.schedule_once(lambda *_: self.open_and_prepare_text(), 0.1)
        Clock.schedule_once(lambda *_: self.apply_theme(), 0)
        Clock.schedule_once(lambda *_: self.restore_bookmark(), 0.2)

        self.logger.info("\n_build_interface: ✅ Інтерфейс успішно побудовано\n")
        return root

#-------------------------------------------
    def _bind_events(self):
        """Прив'язка подій до кнопок."""
        self.btn_listen.bind(on_press=lambda *_: self.listen_current_paragraph())
        self.btn_pause.bind(on_press=lambda *_: self.stop_tts())
        self.btn_edit.bind(on_press=self.open_edit_popup)
        self.btn_add_wav.bind(on_press=self.open_add_wav_popup)
        self.btn_next.bind(on_press=lambda *_: self.go_next_paragraph())
        self.btn_extra.bind(on_press=lambda *_: ExtraButtonsPopup(main_app=self, editor_name=self.app_name).open())
#        self.btn_extra.bind(on_press=lambda *_: ExtraButtonsPopup(main_app=self, editor_name='accent_editor').open())
#self.app_name
#zp
# У accent_editor
#popup = ExtraButtonsPopup(main_app=self, editor_name='accent_editor')

# У voice_tags_editor  
#popup = ExtraButtonsPopup(main_app=self, editor_name='voice_tags_editor')

# У sound_effects_editor
#popup = ExtraButtonsPopup(main_app=self, editor_name='sound_effects_editor')

# У multispeaker_tts
#popup = ExtraButtonsPopup(main_app=self, editor_name='multispeaker_tts')
#zk


    # === Основні методи ===
 
 #-------------------------------------------   
    def save_bookmark(self):
        """Зберігає поточну позицію у конфіг з новими полями."""
        if self.text_input and hasattr(self, 'config_manager'):
            try:
                self.current_cursor_pos = self.text_input.cursor_index()
                self.current_scroll_y = self.text_input.scroll_y
                self.current_paragraph_index = self.current_idx
                
                self.config_manager.update_bookmark(
                    'accent_editor', 
                    self.current_cursor_pos, 
                    self.current_scroll_y,
                    self.current_paragraph_index
                )
                self.logger.debug(f"\nsave_bookmark: 🔖 Закладка збережена: абзац {self.current_paragraph_index}, позиція {self.current_cursor_pos}\n")
            except Exception as e:
                self.logger.error(f"\nsave_bookmark: Помилка збереження закладки: {e}\n")

 #-------------------------------------------
    def restore_bookmark(self):
        """Відновлює позицію з конфігу з новими полями."""
        try:
            if hasattr(self, 'config_manager'):
                bookmark = self.config_manager.get_bookmark('accent_editor')
                if self.text_input and bookmark:
                    # Встановлюємо позицію курсора і прокрутки
                    self.text_input.cursor = (bookmark['cursor_pos'], 0)
                    self.text_input.scroll_y = bookmark['scroll_y']
                    
                    # Встановлюємо індекс абзацу
                    self.current_paragraph_index = bookmark.get('paragraph_index', 0)
                    
                    self.logger.info(f"\nrestore_bookmark: 🔖 Закладку відновлено: абзац {self.current_paragraph_index}, позиція {bookmark['cursor_pos']}\n")
        except Exception as e:
            self.logger.error(f"\nrestore_bookmark: Помилка відновлення закладки: {e}\n")
 #------------------------------------------- 
        
               
 #-------------------------------------------                       
    def open_and_prepare_text(self):
        """Завантажує текст та автоматично додає наголоси, відновлює позицію."""
        try:
            # Завантаження тексту через FileManager
            raw_text = self.file_manager.load_input_text()
            if raw_text is None:
                return

            # Обробка тексту через TextProcessor
            accented_text = self.text_processor.add_accents_to_text(raw_text, self.accents)
            paragraphs = accented_text.split("\n")
            
            self.text_for_correction = paragraphs
            self.fixed_text = []

            # Відновлюємо закладку ДО встановлення поточного абзацу
            self.restore_bookmark()
            
            # Встановлюємо початковий абзац на основі закладки
            if 0 <= self.current_paragraph_index < len(paragraphs):
                self.current_idx = self.current_paragraph_index
                self.text_input.text = paragraphs[self.current_paragraph_index]
                self.logger.info(f"\nopen_and_prepare_text: 📖 Відкрито абзац {self.current_paragraph_index+1}/{len(paragraphs)} з закладки\n")
            else:
                # Якщо закладка некоректна, знаходимо перший непорожній абзац
                i = 0
                while i < len(paragraphs) and not paragraphs[i].strip():
                    self.fixed_text.append("")
                    i += 1
                    
                if i < len(paragraphs):
                    self.current_idx = i
                    self.text_input.text = paragraphs[i]
                    self.logger.info(f"\nopen_and_prepare_text: 📖 Відкрито перший абзац {i+1}/{len(paragraphs)}\n")
                else:
                    self.current_idx = len(paragraphs)
                    self.text_input.text = ""
                    self.logger.warning("\nopen_and_prepare_text: 📖 Текст порожній\n")
                    self.show_popup("Готово", "Текст порожній.")

            self.clear_selection_state()
            
        except Exception as e:
            self.logger.error(f"\nopen_and_prepare_text: ❌ Помилка підготовки тексту: {e}\n")
            self.show_popup("Помилка", f"Не вдалося підготувати текст:\n{e}")

#-------------------------------------------

    def go_next_paragraph(self):
        """Переходить до наступного абзацу та зберігає позицію."""
        self.logger.info("\ngo_next_paragraph: ➡️ Перехід до наступного абзацу\n")
        self.stop_tts()
        
        if self.current_idx < 0 or self.current_idx >= len(self.text_for_correction):
            self.logger.warning("\ngo_next_paragraph: ⚠️ Неможливо перейти: некоректний поточний індекс\n")
            return

        # Зберігаємо поточний абзац
        self.fixed_text.append(self.text_input.text)
        self.current_idx += 1
        
        # Пропускаємо порожні абзаци
        skipped_count = 0
        while (self.current_idx < len(self.text_for_correction) and 
               not self.text_for_correction[self.current_idx].strip()):
            self.fixed_text.append("")
            self.current_idx += 1
            skipped_count += 1

        if self.current_idx < len(self.text_for_correction):
            self.text_input.text = self.text_for_correction[self.current_idx]
            
            # Оновлюємо поточну позицію
            self.current_paragraph_index = self.current_idx
            self.current_cursor_pos = 0
            self.current_scroll_y = 0.0
            
            self.logger.info(f"\ngo_next_paragraph: ✅ Перехід до абзацу {self.current_idx+1}/{len(self.text_for_correction)} (пропущено {skipped_count} порожніх)\n")
        else:
            self.text_input.text = ""
            self.logger.info("\ngo_next_paragraph: 🏁 Досягнуто кінця тексту\n")
            self.show_popup("Кінець", "Досягнуто кінця тексту.")

        self.clear_selection_state()
        
        # Автоматично зберігаємо закладку при переході
        self.save_bookmark()

#-------------------------------------------
    def listen_current_paragraph(self):
        """Відтворює поточний абзац через TTS."""
        text = self.text_input.text.strip()
        if text:
            self.logger.info(f"\nlisten_current_paragraph: 🔊 Відтворення TTS: {len(text)} символів\n")
            self.tts_manager.safe_tts_speak(text)
        else:
            self.logger.warning("\nlisten_current_paragraph: 🔊 Спроба відтворення порожнього тексту\n")

#-------------------------------------------
    def stop_tts(self):
        """Зупиняє TTS відтворення."""
        if self.tts_manager:
            self.tts_manager.stop_tts()
            self.logger.info("\nstop_tts: ⏹️ TTS зупинено\n")

#-------------------------------------------
    def safe_tts_speak(self, text: str):
        """Безпечне відтворення тексту через TTS."""
        if self.tts_manager:
            self.logger.debug(f"\nsafe_tts_speak: 🔊 TTS: '{text[:50]}{'...' if len(text) > 50 else ''}'\n")
            self.tts_manager.safe_tts_speak(text)


    # === Робота з виділенням слів ===

#-------------------------------------------    
    def on_text_touch(self, instance, touch):
        """Обробка торкання текстового поля для виділення слова."""
        if not instance.collide_point(*touch.pos):
            return False
        Clock.schedule_once(lambda *_: self.detect_word_at_cursor(), 0.01)
        return False

#-------------------------------------------
    def detect_word_at_cursor(self):
        """Визначає слово під курсором."""
        try:
            cursor_idx = self.text_input.cursor_index()
        except Exception as e:
            self.logger.debug(f"\ndetect_word_at_cursor: ⚠️ Помилка отримання позиції курсора: {e}")
            self.clear_selection_state()
            return

        text = self.text_input.text
        if not text:
            self.clear_selection_state()
            return

        # Знаходимо межі слова
        start = cursor_idx
        while start > 0 and self.is_word_char(text[start - 1]):
            start -= 1

        end = cursor_idx
        while end < len(text) and self.is_word_char(text[end]):
            end += 1

        word = text[start:end]
        if WORD_RE.fullmatch(word):
            self.selected_word = word
            self.btn_edit.disabled = False
            self.logger.debug(f"\ndetect_word_at_cursor: 🔍 Виділено слово: '{word}'\n")
        else:
            self.clear_selection_state()

#-------------------------------------------
    def is_word_char(self, char: str) -> bool:
        """Перевіряє, чи символ є частиною слова."""
        return char.isalpha() or char == '\u0301' or char == "'"

#-------------------------------------------
    def save_accents(self):
        """Зберігає словник наголосів."""
        try:
            success = self.file_manager.save_accents(self.accents)
            if success:
                self.logger.info("\nsave_accents: 💾 Словник наголосів збережено\n")
            else:
                self.logger.error("\nsave_accents: ❌ Помилка збереження словника наголосів\n")
        except Exception as e:
            self.logger.error(f"\nsave_accents: ❌ Помилка збереження словника: {e}\n")

#-------------------------------------------
    def clear_selection_state(self):
        """Очищає стан виділення."""
        if self.selected_word:
            self.logger.debug("\nclear_selection_state: 🧹 Очищено виділення слова\n")
        self.selected_word = None
        self.btn_edit.disabled = True

#-------------------------------------------
    def open_edit_popup(self, *_):
        """Відкриває попап для редагування слова."""
        if self.selected_word:
            self.logger.info(f"\nopen_edit_popup: ✏️ Відкриття попапу редагування слова: '{self.selected_word}'\n")
            self.stop_tts()
            EditWordPopup(self, self.selected_word, self.app_name).open()
# У accent_editor
#popup = ExtraButtonsPopup(main_app=self, editor_name='accent_editor')
#        self.btn_edit.bind(on_press=self.open_edit_popup)

#        self.btn_extra.bind(on_press=lambda *_: ExtraButtonsPopup(main_app=self, editor_name='accent_editor').open())
#self.app_name

#-------------------------------------------
    def open_add_wav_popup(self, *_):
        """Відкриває попап для додавання wav."""
        self.tag = "S2"
        self.desc = "падіння великої  гілки"
        if self.tag:
            self.logger.info(f"\nopen_add_wav_popup: ✏️ Відкриття попапу додавання wav: #{self.tag}: {self.desc}\n")
            self.stop_tts()
            current_tag = "S23"
            current_desc = "падіння великої гілки"
                #    self.btn_extra.bind(on_press=lambda *_: ExtraButtonsPopup(main_app=self, editor_name=self.app_name).open())
            #(self, parent_app, current_tag, current_desc, editor_name, **kwargs)
            #self, self.selected_word, self.app_name
            AddSoundEffectFilePopup(parent_app=self, editor_name=self.app_name, current_tag = "S23", current_desc = "падіння великої гілки").open()
# У accent_editor
#popup = ExtraButtonsPopup(main_app=self, editor_name='accent_editor')
#        self.btn_edit.bind(on_press=self.open_edit_popup)

#        self.btn_extra.bind(on_press=lambda *_: ExtraButtonsPopup(main_app=self, editor_name='accent_editor').open())
#self.app_name

#AddSoundEffectFilePopup
#-------------------------------------------
    def replace_word_in_current_paragraph(self, old_word: str, new_word: str):
        """Замінює слово в поточному абзаці."""
        if self.current_idx < 0:
            return
            
        current_text = self.text_input.text
        replaced_text = current_text.replace(old_word, new_word, 1)
        self.text_input.text = replaced_text
        
        self.logger.info(f"\nreplace_word_in_current_paragraph: 🔄 Замінено слово: '{old_word}' -> '{new_word}'\n")


    # === Збереження даних ===

#-------------------------------------------

    def save_full_text(self):
        """Зберігає весь текст у TXT файл та оновлює закладку."""
        self.stop_tts()
        
        content = self.build_full_text()
        success = self.file_manager.save_output_text(content)
        
        # Автоматичне збереження закладки при збереженні тексту
        self.save_bookmark()
        
        if success:
            self.logger.info("\nsave_full_text:💾 Текст успішно збережено\n")
        else:
            self.logger.error("\nsave_full_text: ❌ Помилка збереження тексту\n")

#-------------------------------------------
    def build_full_text(self) -> str:
        """Побудова повного тексту з виправленими абзацами."""
        parts = list(self.fixed_text)
        if 0 <= self.current_idx < len(self.text_for_correction):
            parts.append(self.text_input.text)
            parts.extend(self.text_for_correction[self.current_idx + 1:])
        
        full_text = "\n".join(parts)
        self.logger.debug(f"\nbuild_full_text: 📊 Зібрано повний текст:\n{len(parts)} абзаців, \n{len(full_text)} символів")
        return full_text


    # === Тема інтерфейсу ===

#-------------------------------------------        
    def get_theme_colors(self):
        """Повертає кольори теми (для сумісності з попапами)."""
        return self.theme_manager.get_colors()

#-------------------------------------------    
    def apply_theme(self):
        """Застосовує поточну тему до інтерфейсу."""
        try:
            # Створюємо словник з віджетами для теми
            widgets_dict = {
                'buttons': [self.btn_listen, self.btn_pause, self.btn_edit, self.btn_next, self.btn_extra],
                'text_inputs': [self.text_input],
                'window': Window
            }
            
            # Використовуємо ThemeManager для застосування теми
            self.theme_manager.apply_theme_to_widgets(widgets_dict)
            self.logger.debug("\napply_theme: 🎨 Тема застосована\n")
        except Exception as e:
            self.logger.error(f"\napply_theme: ❌ Помилка застосування теми: {e}\n")

#-------------------------------------------
    def toggle_theme(self):
        """Перемикає тему день/ніч."""
        self.stop_tts()
        self.theme_manager.toggle_theme()
        self.apply_theme()
        self.logger.info(f"\ntoggle_theme :🎨 Переключено тему: {self.theme_manager.current_theme}\n")


    # === Утиліти ===

#-------------------------------------------    
    def show_popup(self, title: str, message: str):
        """Показує спливаюче повідомлення."""
        popup = Popup(
            title=title,
            content=Label(text=message),
            size_hint=(0.8, 0.4)
        )
        popup.open()
        self.logger.debug(f"\nshow_popup: 📢 Показано попап: {title} {content}\n")

#-------------------------------------------

    def on_stop(self):
        """Викликається при закритті додатку - зберігає закладку, зупиняє ттс."""
        self.save_bookmark()
        self.stop_tts()
        self.logger.info("\non_stop: 🔴 Редактор наголосів закрито\n ===========================")

#if __name__ == "__main__":
#    AccentEditorApp().run()
    
if __name__ == "__main__":
    cfg_path = "/storage/emulated/0/a0_sb2_book_editors_suite/config.json"

    app = AccentEditorApp(cfg_path)
    app.run()    