# -*- coding: utf-8 -*-
# робоча версія редактора наголосів 

import sys
import os
from pathlib import Path

sys.path.insert(0, '/storage/emulated/0/a0_sb2_book_editors_suite')
sys.path.insert(0, '/storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite')

from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.popup import Popup
from kivy.uix.label import Label
from kivy.core.window import Window
from kivy.clock import Clock

from book_editors_suite.core.config_manager import get_config_manager
from book_editors_suite.core.tts_manager import TTSManager
from book_editors_suite.core.file_manager import FileManager
from book_editors_suite.core.text_processor import TextProcessor
from book_editors_suite.core.logging_manager import LoggingManager
from book_editors_suite.ui.popups.edit_word_popup import EditWordPopup
from book_editors_suite.ui.popups.extra_buttons_popup import ExtraButtonsPopup
from book_editors_suite.ui.themes import ThemeManager
from book_editors_suite.utils.helpers import WORD_RE

class AccentEditorApp(App):
    """ НЕ ВИДАЛЯТИ МЕТОДИ"""

#----- -----
    def __init__(self, book_project_name: str, input_text_file: str = None, **kwargs):
        super().__init__(**kwargs)
        self.book_project_name = book_project_name
        self.input_text_file = input_text_file
        self.app_name = "accent_editor"
        
        # Властивості
        self.config_manager = None
        self.config = {}
        self.accents = {}
        self.text_for_correction = []
        self.fixed_text = []
        self.current_idx = -1
        self.selected_word = None
        self.text_before_selected_word = ""
        self.text_after_selected_word = ""
        self.tts_manager = None
        self.file_manager = None
        self.text_processor = None
        self.logger = None
        self.theme_manager = None
        
        # Закладка
        self.current_scroll_y = 0.0
        self.current_cursor_pos = 0
        self.current_paragraph_index = 0

#----- -----
    def build(self):
        self._init_managers()
        Window.softinput_mode = "below_target"
        return self._build_interface()

#----- -----
    def _init_managers(self):
        try:
            self.config_manager = get_config_manager(
                book_project_name=self.book_project_name,
                input_text_file=self.input_text_file
            )
            self.config = self.config_manager.load_for_editor('accent_editor')
            project_info = self.config_manager.get_project_info()
            
            self.logger = LoggingManager(
                log_dir=project_info['base_path'] + f"/{self.book_project_name}/temp_folder/logs",
                app_name="accent_editor"
            )
            self.file_manager = FileManager(self.config_manager, 'accent_editor', self.logger)
            self.text_processor = TextProcessor(self.logger)
            self.tts_manager = TTSManager()
            self.theme_manager = ThemeManager()
            
            self.accents = self.file_manager.load_accents()
            self.logger.info("Менеджери ініціалізовані")
            
        except Exception as e:
            self.show_popup("Помилка", f"Помилка ініціалізації:\n{e}")

#----- -----
    def _build_interface(self):
        bbtn_font_size = self.config_manager.get_common_param('BBTN_FONT_SIZE', 38)
        text_widget_font_size = self.config_manager.get_common_param('TEXT_WIDGET_FONT_SIZE', 56)
        bbtn_height = self.config_manager.get_common_param('BBTN_HEIGHT', 120)
            
        root = BoxLayout(orientation='vertical', spacing=8, padding=22)

        # Верхній ряд кнопок
        top_row = BoxLayout(orientation='horizontal', size_hint_y=None, height=bbtn_height, spacing=8)
        self.btn_listen = Button(text="Слухати", font_size=bbtn_font_size)
        self.btn_pause = Button(text="Пауза", font_size=bbtn_font_size)
        self.btn_edit = Button(text="Правити", font_size=bbtn_font_size, disabled=True)
        self.btn_next = Button(text="Наступний", font_size=bbtn_font_size)
        self.btn_extra = Button(text="  . . .  ", font_size=bbtn_font_size)
        
        for btn in (self.btn_listen, self.btn_pause, self.btn_edit, self.btn_next, self.btn_extra):
            top_row.add_widget(btn)

        # Текстове поле
        self.text_input = TextInput(font_size=text_widget_font_size, multiline=True)
        self.text_input.bind(on_touch_down=self.on_text_touch)

        root.add_widget(top_row)
        root.add_widget(self.text_input)
        self._bind_events()

        Clock.schedule_once(lambda *_: self.open_and_prepare_text(), 0.1)
        Clock.schedule_once(lambda *_: self.apply_theme(), 0)
        Clock.schedule_once(lambda *_: self.restore_bookmark(), 0.2)

        return root

#----- -----
    def _bind_events(self):
        self.btn_listen.bind(on_press=lambda *_: self.listen_current_paragraph())
        self.btn_pause.bind(on_press=lambda *_: self.stop_tts())
        self.btn_edit.bind(on_press=self.open_edit_popup)
        self.btn_next.bind(on_press=lambda *_: self.go_next_paragraph())
        self.btn_extra.bind(on_press=lambda *_: ExtraButtonsPopup(main_app=self, editor_name=self.app_name).open())

    # ========== КРИТИЧНІ МЕТОДИ - НЕ ВИДАЛЯТИ ==========

#----- -----
    def open_and_prepare_text(self):
        """Завантажує текст і відновлює закладку З ПРОПУСКОМ ПОРОЖНІХ АБЗАЦІВ"""
        try:
            raw_text = self.file_manager.load_input_text()
            if raw_text is None:
                self.logger.warning("Текст не знайдено")
                return

            accented_text = self.text_processor.add_accents_to_text(raw_text, self.accents)
            paragraphs = accented_text.split("\n")
            self.text_for_correction = paragraphs
            self.fixed_text = []

            self.restore_bookmark()
            target_index = self.current_paragraph_index

            # Додаємо абзаци до закладки
            for i in range(target_index):
                self.fixed_text.append(self.text_for_correction[i])

            # ПРОПУСК ПОРОЖНІХ АБЗАЦІВ - КРИТИЧНО ВАЖЛИВО
            while (target_index < len(paragraphs) and not paragraphs[target_index].strip()):
                self.fixed_text.append("")
                target_index += 1

            if target_index < len(paragraphs):
                self.text_input.text = paragraphs[target_index]
                self.current_paragraph_index = target_index
            else:
                self.text_input.text = ""
                self.current_paragraph_index = len(paragraphs)

            total_paragraphs = len(paragraphs)
            self.btn_extra.text = f"   . . .   \n{self.current_paragraph_index+1}/{total_paragraphs}"
            self.clear_selection_state()

        except Exception as e:
            self.logger.error(f"Помилка підготовки тексту: {e}")
            self.show_popup("Помилка", f"Не вдалося підготувати текст:\n{e}")

#----- -----
    def go_next_paragraph(self):
        """Перехід до наступного абзацу З ПРОПУСКОМ ПОРОЖНІХ"""
        self.stop_tts()

        current_text = self.text_input.text
        if self.current_paragraph_index < len(self.text_for_correction):
            self.fixed_text.append(current_text)
            self.current_paragraph_index += 1
            
            # ПРОПУСК ПОРОЖНІХ АБЗАЦІВ - КРИТИЧНО ВАЖЛИВО
            while (self.current_paragraph_index < len(self.text_for_correction) and 
                   not self.text_for_correction[self.current_paragraph_index].strip()):
                self.fixed_text.append("")
                self.current_paragraph_index += 1

            if self.current_paragraph_index < len(self.text_for_correction):
                self.text_input.text = self.text_for_correction[self.current_paragraph_index]
            else:
                self.text_input.text = ""
                self.show_popup("Кінець", "Досягнуто кінця тексту")

        self.btn_extra.text = f"   . . .   \n{self.current_paragraph_index+1}/{len(self.text_for_correction)}"
        self.move_bookmark()
        self.clear_selection_state()

#----- -----
    def move_bookmark(self):
        """Оновлює закладку у властивостях класу"""
        try:
            if self.text_input:
                self.current_cursor_pos = self.text_input.cursor_index()
                self.current_scroll_y = self.text_input.scroll_y
        except Exception as e:
            self.logger.error(f"Помилка оновлення закладки: {e}")

#----- -----
    def save_bookmark(self):
        """Зберігає закладку в конфіг"""
        try:
            if hasattr(self, 'config_manager'):
                self.config_manager.update_bookmark(
                    'accent_editor', 
                    self.current_cursor_pos, 
                    self.current_scroll_y,
                    self.current_paragraph_index
                )
        except Exception as e:
            self.logger.error(f"Помилка збереження закладки: {e}")

#----- -----
    def restore_bookmark(self):
        """Відновлює закладку з конфігу"""
        try:
            if hasattr(self, 'config_manager'):
                bookmark = self.config_manager.get_bookmark('accent_editor')
                if bookmark:
                    self.current_scroll_y = bookmark.get('scroll_y', 0.0)
                    self.current_cursor_pos = bookmark.get('cursor_pos', 0)
                    self.current_paragraph_index = bookmark.get('paragraph_index', 0)
        except Exception as e:
            self.logger.error(f"Помилка відновлення закладки: {e}")

#----- -----
    def build_full_text(self) -> str:
        """Побудова повного тексту - КРИТИЧНО ВАЖЛИВО"""
        parts = []
        parts.extend(self.fixed_text)
        
        if self.current_paragraph_index < len(self.text_for_correction):
            parts.append(self.text_input.text)
            if self.current_paragraph_index + 1 < len(self.text_for_correction):
                parts.extend(self.text_for_correction[self.current_paragraph_index + 1:])
        
        return "\n".join(parts)

#----- -----
    def save_full_text(self):
        """Збереження повного тексту"""
        self.stop_tts()
        content = self.build_full_text()
        success = self.file_manager.save_output_text(content)
        self.save_bookmark()
        
        if success:
            self.logger.info("Текст успішно збережено")
            self.show_popup("Успіх", "Текст збережено")
        else:
            self.logger.error("Помилка збереження тексту")
            self.show_popup("Помилка", "Не вдалося зберегти текст")

#def save_full_mp3(self):
#    """Збереження тексту в MP3 - ПРОСТА ВИПРАВЛЕНА ВЕРСІЯ"""
#    self.stop_tts()
#    content = self.build_full_text().strip()
#    if not content:
#        self.show_popup("Помилка", "Текст порожній")
#        return

#    try:
#        # ПРОСТІ ШЛЯХИ БЕЗ config_manager
#        project_name = self.book_project_name
#        base_path = "/storage/emulated/0/book_projects"
#        project_path = f"{base_path}/{project_name}"
#        
#        # Створюємо папку
#        mp3_folder = f"{project_path}/outputs/output_mp3"
#        os.makedirs(mp3_folder, exist_ok=True)
#        
#        # Шлях до файлу
#        out_f_path = f"{mp3_folder}/{project_name}.mp3"
#        
#        # Перевірка gTTS
#        try:
#            from gtts import gTTS
#        except ImportError:
#            self.show_popup("Помилка", "Встановіть gTTS: pip install gtts")
#            return
#            
#        # Конвертація
#        tts = gTTS(text=content, lang="uk")
#        tts.save(out_f_path)
#        
#        self.show_popup("MP3 збережено", f"Файл: {project_name}.mp3")
#        self.logger.info(f"MP3 збережено: {out_f_path}")
#        
#    except Exception as e:
#        self.logger.error(f"Помилка MP3: {str(e)}")
#        self.show_popup("Помилка", f"Не вдалося зберегти MP3:\n{str(e)}")


#----- -----
    def save_full_mp3(self):
    	"""Збереження тексту в MP3 - ВИПРАВЛЕНА ВЕРСІЯ"""
    	self.stop_tts()
    	content = self.build_full_text().strip()
    	if not content:
    	   self.show_popup("Помилка", "Текст порожній")
    	   return
    	
    	try:
    	   # Отримуємо інформацію про проект - ВИПРАВЛЕНА ВЕРСІЯ
    	   project_info = self.config_manager.get_project_info()
    	   # Використовуємо book_project_name як резервний варіант
    	   project_name = project_info.get('project_name', self.book_project_name)
    	   # Отримуємо base_path безпечним способом
    	   base_path = project_info.get('base_path', '/storage/emulated/0/book_projects')
    	   project_path = f"{base_path}/{project_name}"
    	   # Створюємо шлях для MP3 файлу
    	   mp3_folder = f"{project_path}/outputs/output_mp3"
    	   os.makedirs(mp3_folder, exist_ok=True)
    	   out_f_path = f"{mp3_folder}/{project_name}.mp3"
    	   # Конвертуємо текст в MP3
    	   from gtts import gTTS
    	   tts = gTTS(text=content, lang="uk")
    	   tts.save(out_f_path)
    	   
    	   self.show_popup("MP3 збережено", f"MP3 збережено:\n{out_f_path}")
    	   self.logger.info(f"MP3 збережено: {out_f_path}")
    	
    	except ImportError:
    	   error_msg = "Бібліотека gTTS не встановлена. pip install gtts"
    	   self.logger.error(error_msg)
    	   self.show_popup("Помилка gTTS", error_msg)
    	
    	except Exception as e:
    	   error_msg = f"Помилка MP3: \n{str(e)}"
    	   self.logger.error(error_msg)
    	   self.show_popup("Помилка", error_msg)

#----- -----

#    def save_full_mp3(self):
#        """Збереження тексту в MP3 - ПРАЦЮЮЧА ВЕРСІЯ"""
#        self.stop_tts()
#        content = self.build_full_text().strip()
#        if not content:
#            self.show_popup("Помилка", "Текст порожній")
#            return

#        try:
#            project_info = self.config_manager.get_project_info()
#            project_name = project_info['project_name']
#            project_path = project_info['base_path'] + f"/{project_name}"
#            
#            mp3_folder = f"{project_path}/outputs/output_mp3"
#            os.makedirs(mp3_folder, exist_ok=True)
#            
#            out_f_path = f"{mp3_folder}/{project_name}.mp3"
#            
#            from gtts import gTTS
#            tts = gTTS(text=content, lang="uk")
#            tts.save(out_f_path)
#            
#            self.show_popup("MP3 збережено", f"MP3 збережено:\n{out_f_path}")
#            self.logger.info(f"MP3 збережено: {out_f_path}")
#            
#        except ImportError:
#            error_msg = "Бібліотека gTTS не встановлена. pip install gtts"
#            self.logger.error(error_msg)
#            self.show_popup("Помилка gTTS", error_msg)
#        except Exception as e:
#            error_msg = f"Помилка MP3: {str(e)}"
#            self.logger.error(error_msg)
#            self.show_popup("Помилка", error_msg)

#----- -----
    def sort_dictionary(self):
        """Сортування словника - ПРАЦЮЮЧА ВЕРСІЯ"""
        try:
            self.accents = dict(sorted(self.accents.items()))
            self.save_accents()
            self.show_popup("Успіх", "Словник відсортовано")
            self.logger.info("Словник відсортовано")
        except Exception as e:
            self.logger.error(f"Помилка сортування: {e}")
            self.show_popup("Помилка", f"Не вдалося відсортувати словник:\n{e}")

#----- -----
    def save_accents(self):
        """Збереження словника"""
        try:
            success = self.file_manager.save_accents(self.accents)
            if success:
                self.logger.info("Словник наголосів збережено")
            else:
                self.logger.error("Помилка збереження словника")
        except Exception as e:
            self.logger.error(f"Помилка збереження словника: {e}")

    # ========== ІНШІ ОБОВ'ЯЗКОВІ МЕТОДИ ==========

#----- -----
    def on_text_touch(self, instance, touch):
        if not instance.collide_point(*touch.pos):
            return False
        Clock.schedule_once(lambda *_: self.detect_word_at_cursor(), 0.01)
        return False

##----- -----
#    def detect_word_at_cursor(self):
#        try:
#            cursor_idx = self.text_input.cursor_index()
#        except Exception:
#            self.clear_selection_state()
#            return

#        text = self.text_input.text
#        if not text:
#            self.clear_selection_state()
#            return

#        start = cursor_idx
#        while start > 0 and self.is_word_char(text[start - 1]):
#            start -= 1

#        end = cursor_idx
#        while end < len(text) and self.is_word_char(text[end]):
#            end += 1

#        word = text[start:end]
#        if WORD_RE.fullmatch(word):
#            self.selected_word = word
#            self.btn_edit.disabled = False
#        else:
#            self.clear_selection_state()
#z1p

#----- -----
    def detect_word_at_cursor(self):
        """Визначення слова під курсором"""
        try:
            cursor_idx = self.text_input.cursor_index()
        except Exception as e:
            self.clear_selection_state()
            return

        text = self.text_input.text
        if not text:
            self.clear_selection_state()
            return

        # Використовуємо TextProcessor для визначення слова
        word, start, end = self.text_processor.detect_word_at_cursor(text, cursor_idx)
        
        if word:
            self.text_before_selected_word = text[:start]
            self.text_after_selected_word = text[end:]
            self.selected_word = word
            self.btn_edit.disabled = False
            self.logger.debug(f"Виділено слово: '{word}'")
        else:
            self.clear_selection_state()

#z1k
#----- -----
    def is_word_char(self, char: str) -> bool:
        return char.isalpha() or char == '\u0301' or char == "'"

#----- -----
    def clear_selection_state(self):
        self.selected_word = None
        self.btn_edit.disabled = True

#----- -----
    def open_edit_popup(self, *_):
        if self.selected_word:
            self.stop_tts()
            EditWordPopup(self, self.selected_word, self.app_name).open()

#----- -----
  #  def replace_word_in_current_paragraph(self, old_word: str, new_word: str):
#        if self.current_paragraph_index < 0:
#            return
#            
#        current_text = self.text_input.text
#        replaced_text = current_text.replace(old_word, new_word, 1)
#        self.text_input.text = replaced_text

#z2p

#----- -----
    def replace_word_in_current_paragraph(self, old_word: str, new_word: str):
        """Заміна слова в тексті"""
        if self.current_paragraph_index < 0:
        	return
        	
        if not self.text_input:
            return
            
        # Використовуємо text_processor для заміни з правильним регістром
        replaced = self.text_processor.match_casing(old_word, new_word)
        
        new_txt = self.text_before_selected_word + replaced + self.text_after_selected_word
        self.text_input.text = new_txt
        new_pos = len(self.text_before_selected_word) + len(replaced)
        Clock.schedule_once(lambda dt: self._set_cursor_by_index(new_pos), 0)


#z2k
#----- -----

    def _set_cursor_by_index(self, idx: int):
        """Встановлення курсора за індексом"""
        if not self.text_input:
            return
        try:
            self.text_input.cursor = self.text_input.get_cursor_from_index(idx)
        except Exception:
            try:
                self.text_input.cursor_index = idx
            except Exception:
                pass

#----- -----
    def listen_current_paragraph(self):
        text = self.text_input.text.strip()
        if text:
            self.tts_manager.safe_tts_speak(text)

#----- -----
    def stop_tts(self):
        if self.tts_manager:
            self.tts_manager.stop_tts()

#----- -----
    def get_theme_colors(self):
        return self.theme_manager.get_colors()

#----- -----
    def apply_theme(self):
        try:
            widgets_dict = {
                'buttons': [self.btn_listen, self.btn_pause, self.btn_edit, self.btn_next, self.btn_extra],
                'text_inputs': [self.text_input],
                'window': Window
            }
            self.theme_manager.apply_theme_to_widgets(widgets_dict)
        except Exception as e:
            self.logger.error(f"Помилка теми: {e}")

#----- -----
    def toggle_theme(self):
        self.stop_tts()
        self.theme_manager.toggle_theme()
        self.apply_theme()

#----- -----
    def show_popup(self, title: str, message: str):
        popup = Popup(title=title, content=Label(text=message), size_hint=(0.8, 0.4))
        popup.open()
#----- -----
    def on_stop(self):
        self.save_bookmark()
        self.stop_tts()
        self.logger.info("Редактор закрито")

#============== Запуск =========
if __name__ == "__main__":
    input_text_file = "/storage/emulated/0/Documents/Inp_txt/Чекаючий_1_1.txt"
    book_project_name = "Чекаючий_1_1"
    
    app = AccentEditorApp(
        book_project_name=book_project_name,
        input_text_file=input_text_file
    )
    app.run()
    #========================