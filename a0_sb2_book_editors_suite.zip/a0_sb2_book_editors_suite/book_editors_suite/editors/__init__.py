# -*- coding: utf-8 -*-
"""
/storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite/editors/__init__.py

Пакет редакторів.




# -*- coding: utf-8 -*-
"""
#/storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite/editors/__init__.py

#Пакет редакторів.


# book_editors_suite/editors/__init__.py
#"""
#Editors module - пакет редакторів книг
#"""

# Імпорт основних редакторів
#from .accent_editor import AccentEditor
#from .voice_tags_editor import VoiceTagsEditor
#from .sound_effects_editor import SoundEffectsEditor
#from .multispeaker_tts import MultispeakerTTS

#__all__ = [
#    'AccentEditor',
#    'VoiceTagsEditor',
#    'SoundEffectsEditor', 
#    'MultispeakerTTS'
#]

# book_editors_suite/editors/__init__.py
#"""
#Editors module - пакет редакторів книг
#"""

# Імпорт основних редакторів
#from .accent_editor import AccentEditor
#from .voice_tags_editor import VoiceTagsEditor
#from .sound_effects_editor import SoundEffectsEditor
#from .multispeaker_tts import MultispeakerTTS

#__all__ = [
#    'AccentEditor',
#    'VoiceTagsEditor',
#    'SoundEffectsEditor', 
#    'MultispeakerTTS'
#]

#"""
#Editors module - пакет редакторів книг
#"""

# Імпорт основних редакторів
#from .accent_editor import AccentEditor
#from .voice_tags_editor import VoiceTagsEditor
#from .sound_effects_editor import SoundEffectsEditor
#from .multispeaker_tts import MultispeakerTTS

#__all__ = [
#    'AccentEditor',
#    'VoiceTagsEditor',
#    'SoundEffectsEditor', 
#    'MultispeakerTTS'
#]