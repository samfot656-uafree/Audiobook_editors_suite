# -*- coding: utf-8 -*-
"""
/storage/emulated/0/a0_sb2_book_editors_suite/book_editors_suite/utils/__init__.py

Пакет утиліт.
"""

from .helpers import (
    strip_combining_acute,
    match_casing,
    get_clock_str,
    get_battery_percent,
    sanitize_filename,
    WORD_RE
)

__all__ = [
    'strip_combining_acute',
    'match_casing', 
    'get_clock_str',
    'get_battery_percent',
    'sanitize_filename',
    'WORD_RE'
]


# book_editors_suite/utils/__init__.py
#"""
#Utils module - допоміжні функції та утиліти
#"""

#from .helpers import (
#    sanitize_filename,
#    format_time,
#    validate_path,
#    backup_file,
#    log_message
#)

#__all__ = [
#    'sanitize_filename',
#    'format_time', 
#    'validate_path',
#    'backup_file',
#    'log_message'
#]


# book_editors_suite/utils/__init__.py
#"""
#Utils module - допоміжні функції та утиліти
#"""

#from .helpers import (
#    sanitize_filename,
#    format_time,
#    validate_path,
#    backup_file,
#    log_message
#)

#__all__ = [
#    'sanitize_filename',
#    'format_time', 
#    'validate_path',
#    'backup_file',
#    'log_message'
#]

#"""
#Utils module - допоміжні функції та утиліти
#"""

#from .helpers import (
#    sanitize_filename,
#    format_time,
#    validate_path,
#    backup_file,
#    log_message
#)

#__all__ = [
#    'sanitize_filename',
#    'format_time', 
#    'validate_path',
#    'backup_file',
#    'log_message'
#]